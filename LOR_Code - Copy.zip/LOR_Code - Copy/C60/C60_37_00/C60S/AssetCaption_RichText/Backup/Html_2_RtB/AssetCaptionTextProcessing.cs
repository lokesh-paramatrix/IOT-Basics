using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using Html2Rtb;

namespace Html_2_Rtb
{
    /**
     * Method Name : AssetCaptionTextProcessing
     * Method Description : Handles transformation of asset captions
     * Creation Date : 25/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           25/11/2009      Siddharth Naik      First creation         
     */
    abstract class AssetCaptionTextProcessing
    {
        /**
         * Method Name : Transform
         * Method Description : Adds the assest caption texts.
         * Creation Date : 25/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           25/11/2009      Siddharth Naik      First creation
         */
        public static void Transform(DataTable srcTable, String textIDColName, String textTypeColName, String richTextTypeColName, String textColName, String lanIDColName, String comFamCdColName, String buCdColName, String brandCdColName, String cmcTextBlockType)
        {
            srcTable.DefaultView.Sort = textIDColName;
            // use max text def id to auto generate the id for dimension diagram
            int maxTextDefID = Convert.ToInt32(srcTable.DefaultView[srcTable.DefaultView.Count - 1].Row[textIDColName], Program.CultureInfo);

            SqlConnection con = new SqlConnection(Transformer.GetConnectionString());

            SqlCommand selectCommand = new SqlCommand(Transformer.assetCaptionTextStoredProcs.Get("AllAssetCaptionTexts"), con);
            selectCommand.CommandType = CommandType.StoredProcedure;
            selectCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;

            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = selectCommand;

            DataSet allCaptionTexts = new DataSet();
            allCaptionTexts.Locale = Program.CultureInfo;

            sda.Fill(allCaptionTexts);

            DataView allCaptionTextsDV = new DataView(allCaptionTexts.Tables[0], String.Empty, "com_fam_cd, brand_cd, bu_cd, lan_id", DataViewRowState.OriginalRows);

            for (int rowIndex = 0; rowIndex < allCaptionTextsDV.Count; rowIndex++)
            {
                DataRow dr = allCaptionTextsDV[rowIndex].Row;

                String com_fam_cd = Convert.ToString(dr["com_fam_cd"], Program.CultureInfo).Trim();
                String brand_cd = Convert.ToString(dr["brand_cd"], Program.CultureInfo).Trim();
                String bu_cd = Convert.ToString(dr["bu_cd"], Program.CultureInfo).Trim();
                String lan_id = Convert.ToString(dr["lan_id"], Program.CultureInfo).Trim();

                DataRowView[] captionTexts = allCaptionTextsDV.FindRows(new Object[] { com_fam_cd, brand_cd, bu_cd, lan_id });

                rowIndex = rowIndex + captionTexts.Length - 1;

                XmlDocument cmcContentDoc = new XmlDocument();
                XmlElement richTextBlock = cmcContentDoc.CreateElement("RichText");
                richTextBlock.Attributes.Append(cmcContentDoc.CreateAttribute("type"));
                richTextBlock.Attributes[0].Value = cmcTextBlockType.Trim(); ;
                
                // every drv is 1 item
                foreach (DataRowView drv in captionTexts)
                {
                    XmlElement itemNode = cmcContentDoc.CreateElement("Item");
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("docType"));

                    itemNode.Attributes[0].Value = "1";
                    itemNode.Attributes[1].Value = Convert.ToString(drv["cmc_doc_type"], Program.CultureInfo).Trim();

                    XmlElement labelNode = cmcContentDoc.CreateElement("Head");
                    labelNode.InnerText = Convert.ToString(drv["asset_text"], Program.CultureInfo).Trim();
                    itemNode.AppendChild(labelNode);

                    richTextBlock.AppendChild(itemNode);
                }

                if (richTextBlock.HasChildNodes)
                {
                    cmcContentDoc.AppendChild(richTextBlock);
                }

                DataRow newRow = srcTable.NewRow();

                newRow[textIDColName] = ++maxTextDefID;                
                newRow[richTextTypeColName] = cmcTextBlockType.Trim();
                newRow[textColName] = cmcContentDoc.OuterXml;
                newRow[lanIDColName] = lan_id;
                newRow[comFamCdColName] = com_fam_cd;
                newRow[buCdColName] = bu_cd;
                newRow[brandCdColName] = brand_cd;

                srcTable.Rows.Add(newRow);
            }
        }
    }
}
