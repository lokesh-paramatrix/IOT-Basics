using System;
using System.Xml;

namespace Html2Rtb
{
    /**
     * Class Name : BulletProcessing
     * Class Description : Will handle transformation of html texts whose vis_type_cd mapping is for Bullet Structure.
     * Creation Date : 16/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           16/11/2009      Siddharth Naik      First creation
     */
    abstract class BulletProcessing
    {
        /**
         * Method Name : Transform
         * Method Description : Transforms html texts to Bullet Structure.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static String Transform(System.Int32 textDefID, String htmlContent1, String cmcTextBlockType)
        {
            try
            {
                htmlContent1 = htmlContent1.Replace("<BR/>", String.Empty);
                htmlContent1 = htmlContent1.Replace("\n", String.Empty);

                htmlContent1 = "<ROOT>" + htmlContent1 + "</ROOT>";

                XmlDocument htmlContent = new XmlDocument();

                try
                {
                    htmlContent.LoadXml(htmlContent1);
                }
                catch (XmlException)
                {
                    try
                    {
                        htmlContent = WellFormedNessChecker.MakeWellFormed(htmlContent1);
                    }
                    catch (XmlException)
                    {
                        throw;
                    }
                }

                XmlDocument cmcContentDoc = new XmlDocument();
                
                XmlElement richTextBlock = cmcContentDoc.CreateElement("RichText");
                richTextBlock.Attributes.Append(cmcContentDoc.CreateAttribute("type"));
                richTextBlock.Attributes[0].Value = cmcTextBlockType.Trim();

                XmlNodeList headNodeList = htmlContent.SelectNodes("ROOT/H1");

                if (headNodeList.Count == 0)
                {
                    return String.Empty;
                }

                for (int headItemNodeRank = 0; headItemNodeRank < headNodeList.Count; headItemNodeRank++)
                {
                    XmlElement itemNode = cmcContentDoc.CreateElement("Item");

                    // Attributes : code, referenceName, rank
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("code"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("referenceName"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));

                    itemNode.Attributes[0].Value = textDefID.ToString(Program.CultureInfo).Trim() + "_" + ((int)(headItemNodeRank + 1)).ToString(Program.CultureInfo).Trim();
                    itemNode.Attributes[1].Value = textDefID.ToString(Program.CultureInfo).Trim() + "_" + ((int)(headItemNodeRank + 1)).ToString(Program.CultureInfo).Trim();
                    itemNode.Attributes[2].Value = ((int)(headItemNodeRank + 1)).ToString(Program.CultureInfo).Trim();

                    if (headNodeList[headItemNodeRank].NextSibling != null)
                    {
                        XmlNode bulletList = ProcessBulletsOnly(headNodeList[headItemNodeRank].NextSibling, cmcContentDoc);

                        if (bulletList.HasChildNodes)
                        {
                            itemNode.AppendChild(bulletList);
                        }
                    }

                    richTextBlock.AppendChild(itemNode);
                }

                if (richTextBlock.NodeType == XmlNodeType.EndElement)
                {
                    return String.Empty;
                }

                cmcContentDoc.AppendChild(richTextBlock);                

                return cmcContentDoc.OuterXml;
            }
            catch
            {
                throw;
            }
        }

        /**
         * Method Name : ProcessBulletsOnly
         * Method Description : The html texts that are inside the list tags in the html texts are
         *                      handled in this method.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static XmlNode ProcessBulletsOnly(XmlNode htmlContent, XmlDocument bulletDocument)
        {
            XmlElement bulletList = bulletDocument.CreateElement("BulletList");

            XmlNodeList bulletItemList = htmlContent.SelectNodes("LI");

            for (int bulletItemRank = 0; bulletItemRank < bulletItemList.Count; bulletItemRank++)
            {
                XmlElement bulletItem = bulletDocument.CreateElement("BulletItem");
                bulletItem.Attributes.Append(bulletDocument.CreateAttribute("rank"));
                bulletItem.Attributes[0].Value = ((int)(bulletItemRank + 1)).ToString(Program.CultureInfo);

                XmlElement bulletItemText = bulletDocument.CreateElement("Text");

                if (bulletItemList[bulletItemRank].SelectSingleNode("text()") != null)
                {
                    bulletItemText.InnerText = bulletItemList[bulletItemRank].SelectSingleNode("text()").InnerText.Trim();
                }
                else
                {
                    bulletItemText.InnerText = String.Empty;
                }

                bulletItem.AppendChild(bulletItemText);

                if (bulletItemList[bulletItemRank].ChildNodes.Count > 1)
                {
                    XmlNode subBulletList = ProcessSubBulletList(bulletItemList[bulletItemRank], bulletDocument);

                    if (subBulletList.HasChildNodes)
                    {
                        bulletItem.AppendChild(subBulletList);
                    }
                }

                bulletList.AppendChild(bulletItem);
            }

            return bulletList;
        }

        /**
         * Method Name : ProcessSubBulletList
         * Method Description : The nested list tags are handled here. All list tags that are insided the 
         *                      uppermost list tags are transformed to sub bullets.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         *      2           15/12/2009      Siddharth Naik      Only one level of sublist must exist.
         */
        private static XmlNode ProcessSubBulletList(XmlNode htmlContent, XmlDocument bulletDocument)
        {   
            XmlElement subBulletList = bulletDocument.CreateElement("SubList");

            XmlNodeList subBulletItemList = htmlContent.SelectNodes("UL/LI");

            for (int bulletItemRank = 0; bulletItemRank < subBulletItemList.Count; bulletItemRank++)
            {
                XmlElement subBulletItem = bulletDocument.CreateElement("SubItem");
                subBulletItem.Attributes.Append(bulletDocument.CreateAttribute("rank"));
                subBulletItem.Attributes[0].Value = ((int)(bulletItemRank + 1)).ToString(Program.CultureInfo);

                XmlElement bulletItemText = bulletDocument.CreateElement("Text");

                if (subBulletItemList[bulletItemRank].SelectSingleNode("text()") != null)
                {
                    bulletItemText.InnerText = subBulletItemList[bulletItemRank].SelectSingleNode("text()").InnerText.Trim();
                }
                else
                {
                    bulletItemText.InnerText = String.Empty;
                }

                subBulletItem.AppendChild(bulletItemText);

                if (subBulletItemList[bulletItemRank].ChildNodes.Count > 1)
                {
                    /* Siddharth Naik, 15/12/2009
                     * In this version 2 change, the assumption is that there is one more level of a SubList inside 
                     * the current SubItem, HOWEVER NOT MORE THAN THIS ONE !!!!!!
                     * 
                     * THE CODE CAN THROW EXCEPTIONS IN SUCH CASES.
                     */                    
                    #region CODE TO CANCEL OF MULTIPLE NESTING OF SUBLIST & SUBITEM
                    XmlNode subBulletListInner = ProcessSubBulletList(subBulletItemList[bulletItemRank], bulletDocument);

                    if (subBulletListInner.HasChildNodes)
                    {
                        // Append each text data in the SubItem nodes in this sublist and this collective to be appended to
                        // the current outer SubItem.

                        String subItemTextData = "(";

                        foreach (XmlNode subBulletListInnerChildNode in subBulletListInner.ChildNodes)
                        {
                            subItemTextData = subItemTextData + subBulletListInnerChildNode.InnerText + ";";   
                        }
                        
                        subItemTextData =  subItemTextData.TrimEnd(';');
                        subItemTextData = subItemTextData + ")";

                        bulletItemText.InnerText = bulletItemText.InnerText + subItemTextData;
                    }
                    #endregion

                    // Bellow region has been commented for version 2 change of this method.
                    #region CODE TO PROVIDE MULTIPLE NESTING OF SUBLIST & SUBITEM
                    //XmlNode subBulletListInner = ProcessSubBulletList(subBulletItemList[bulletItemRank], bulletDocument);

                    //if (subBulletListInner.HasChildNodes)
                    //{
                    //    subBulletItem.AppendChild(subBulletListInner);
                    //}
                    #endregion
                }
                                
                subBulletList.AppendChild(subBulletItem);
            }

            return subBulletList;
        }
    }
}
