using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using Html2Rtb;

namespace Html_2_Rtb
{
    /**
     * Method Name : DimensionDiagramsProcessing
     * Method Description : Handles transformation of dimension drawing data
     * Creation Date : 25/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           25/11/2009      Siddharth Naik      First creation         
     */
    abstract class DimensionDiagramsProcessing
    {
        /**
         * Method Name : Transform
         * Method Description : Adds the dimension diagrams texts.
         * Creation Date : 25/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           25/11/2009      Siddharth Naik      First creation
         */
        public static void Transform(DataTable srcTable, String textIDColName, String textTypeColName, String richTextTypeColName, String textColName, String lanIDColName, String comFamCdColName, String buCdColName, String brandCdColName, String cmcTextBlockType)
        {
            srcTable.DefaultView.Sort = textIDColName;
            // use max text def id to auto generate the id for dimension diagram
            int maxTextDefID = Convert.ToInt32(srcTable.DefaultView[srcTable.DefaultView.Count - 1].Row[textIDColName], Program.CultureInfo);
            
            SqlConnection con = new SqlConnection(Transformer.GetConnectionString());
                        
            SqlCommand selectCommand = new SqlCommand(Transformer.dimensionTableStoredProcs.Get("RequiredAllVisualElements"), con);
            selectCommand.CommandType = CommandType.StoredProcedure;
            selectCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;

            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = selectCommand;

            DataSet allVisualElements = new DataSet();
            allVisualElements.Locale = Program.CultureInfo;

            sda.Fill(allVisualElements);
            
            DataView allVisualElementsDV = new DataView(allVisualElements.Tables[0], String.Empty, "com_fam_cd, bu_cd, lan_id, brand_cd", DataViewRowState.OriginalRows);
            
            // will use the selectCommand for geting dimension data. Addition of these parameters is one time.
            // hence doing it now.
            sda.SelectCommand.Parameters.Add("@bu_cd", SqlDbType.NChar, 3);
            sda.SelectCommand.Parameters.Add("@fam_cd", SqlDbType.NChar, 8);
            sda.SelectCommand.Parameters.Add("@vis_elem_nr", SqlDbType.Int, 32);
            sda.SelectCommand.Parameters.Add("@ResultSetNo", SqlDbType.Int, 32);

            int rankCounter = 0;

            // 1. Loop over the visual elements found, call the dimension table SPs to get each ones data
            for( int rowIndex = 0; rowIndex < allVisualElementsDV.Count; rowIndex++ )
            {
                DataRow dr = allVisualElementsDV[rowIndex].Row;

                String com_fam_cd = Convert.ToString(dr["com_fam_cd"], Program.CultureInfo).Trim();                                
                String bu_cd = Convert.ToString(dr["bu_cd"], Program.CultureInfo).Trim();
                String lan_id = Convert.ToString(dr["lan_id"], Program.CultureInfo).Trim();
                String brand_cd = Convert.ToString(dr["brand_cd"], Program.CultureInfo).Trim();

                DataRowView[] visual_nrs_for_family_bu = allVisualElementsDV.FindRows(new Object[] { com_fam_cd, bu_cd, lan_id, brand_cd });

                // Skip rowIndex by the number of rows found.
                rowIndex = rowIndex + visual_nrs_for_family_bu.Length - 1;

                XmlDocument cmcContentDoc = new XmlDocument();
                XmlElement richTextBlock = cmcContentDoc.CreateElement("RichText");
                richTextBlock.Attributes.Append(cmcContentDoc.CreateAttribute("type"));
                richTextBlock.Attributes[0].Value = cmcTextBlockType.Trim();

                // 2. Each row is one item.
                foreach (DataRowView drv in visual_nrs_for_family_bu)
                {   
                    // 3.1 Get letters used in drawings
                    sda.SelectCommand.CommandText = Transformer.dimensionTableStoredProcs.Get("LettersInDrawing");
                    
                    sda.SelectCommand.Parameters[0].Value = bu_cd;
                    sda.SelectCommand.Parameters[1].Value = Convert.ToString(drv.Row["fam_cd"], Program.CultureInfo).Trim();
                    sda.SelectCommand.Parameters[2].Value = Convert.ToString(drv.Row["vis_elem_nr"], Program.CultureInfo).Trim();
                    sda.SelectCommand.Parameters[3].Value = "1";

                    DataSet lettersInDrawing = new DataSet();
                    lettersInDrawing.Locale = Program.CultureInfo;

                    sda.Fill(lettersInDrawing);
                    
                    // 3.2 Get tech prods assigned to the drawings                    
                    sda.SelectCommand.CommandText = Transformer.dimensionTableStoredProcs.Get("TechProducts");
                    sda.SelectCommand.Parameters[3].Value = "2";

                    DataSet techProducts = new DataSet();
                    techProducts.Locale = Program.CultureInfo;

                    sda.Fill(techProducts);

                    XmlElement itemNode = cmcContentDoc.CreateElement("Item");
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("referenceName"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("code"));

                    itemNode.Attributes[0].Value = ((int)(++rankCounter)).ToString(Program.CultureInfo);
                    itemNode.Attributes[1].Value = Convert.ToString(drv["vis_type_cd"], Program.CultureInfo).Trim() + " " + Convert.ToString(drv.Row["fam_cd"], Program.CultureInfo).Trim();
                    itemNode.Attributes[2].Value = "LP_RT_" + Convert.ToString(drv["vis_type_cd"], Program.CultureInfo).Trim() + Convert.ToString(drv.Row["vis_elem_nr"], Program.CultureInfo).Trim() + "_" + Convert.ToString(drv.Row["fam_cd"], Program.CultureInfo).Trim().ToUpper();

                    XmlElement labelNode = cmcContentDoc.CreateElement("Head");
                    labelNode.InnerText = Convert.ToString(drv["vis_type_cd"], Program.CultureInfo).Trim() + " " + Convert.ToString(drv.Row["fam_cd"], Program.CultureInfo).Trim();
                    itemNode.AppendChild(labelNode);

                    if ((lettersInDrawing.Tables[0].Rows.Count > 0) && (techProducts.Tables[0].Rows.Count > 0))
                    {
                        XmlElement bulletList = cmcContentDoc.CreateElement("BulletList");
                        
                        // 3.3 The first bullet item holds the letters used in drawings.
                        XmlElement letters_bulletItem = cmcContentDoc.CreateElement("BulletItem");
                        letters_bulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                        letters_bulletItem.Attributes[0].Value = "1";

                        XmlElement letters_bulletItemText = cmcContentDoc.CreateElement("Text");
                        letters_bulletItemText.InnerText = "Product";
                        letters_bulletItem.AppendChild(letters_bulletItemText);

                        // To choose the letters, take the disticnt letter names.
                        DataTable distinctLetterNames = SelectDistinct(lettersInDrawing.Tables[0], "letter_in_drawing");
                        
                        XmlElement letters_subBulletList = cmcContentDoc.CreateElement("SubList");

                        int subItemRank = 0;
                        foreach (DataRow letterRow in distinctLetterNames.Rows)
                        {
                            bool minExists = doesValidValueExistInColForLetter("NA", Convert.ToString(letterRow[0], Program.CultureInfo), lettersInDrawing.Tables[0], "min", "letter_in_drawing");
                            bool nomExists = doesValidValueExistInColForLetter("NA", Convert.ToString(letterRow[0], Program.CultureInfo), lettersInDrawing.Tables[0], "nom", "letter_in_drawing");
                            bool maxExists = doesValidValueExistInColForLetter("NA", Convert.ToString(letterRow[0], Program.CultureInfo), lettersInDrawing.Tables[0], "max", "letter_in_drawing");

                            if (minExists)
                            {
                                XmlElement subBulletItem = cmcContentDoc.CreateElement("SubItem");
                                subBulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                                subBulletItem.Attributes[0].Value = ((int)(++subItemRank)).ToString(Program.CultureInfo).Trim();

                                XmlElement subBulletItemText = cmcContentDoc.CreateElement("Text");
                                subBulletItemText.InnerText = Convert.ToString(letterRow[0], Program.CultureInfo).Trim() + " (Min)";

                                subBulletItem.AppendChild(subBulletItemText);
                                letters_subBulletList.AppendChild(subBulletItem);
                            }

                            if (nomExists)
                            {
                                XmlElement subBulletItem = cmcContentDoc.CreateElement("SubItem");
                                subBulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                                subBulletItem.Attributes[0].Value = ((int)(++subItemRank)).ToString(Program.CultureInfo).Trim();

                                XmlElement subBulletItemText = cmcContentDoc.CreateElement("Text");
                                subBulletItemText.InnerText = Convert.ToString(letterRow[0], Program.CultureInfo).Trim() + " (Norm)";

                                subBulletItem.AppendChild(subBulletItemText);
                                letters_subBulletList.AppendChild(subBulletItem);
                            }

                            if (maxExists)
                            {
                                XmlElement subBulletItem = cmcContentDoc.CreateElement("SubItem");
                                subBulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                                subBulletItem.Attributes[0].Value = ((int)(++subItemRank)).ToString(Program.CultureInfo).Trim();

                                XmlElement subBulletItemText = cmcContentDoc.CreateElement("Text");
                                subBulletItemText.InnerText = Convert.ToString(letterRow[0], Program.CultureInfo).Trim() + " (Max)";

                                subBulletItem.AppendChild(subBulletItemText);
                                letters_subBulletList.AppendChild(subBulletItem);
                            }
                        }

                        if (letters_subBulletList.HasChildNodes)
                        {
                            letters_bulletItem.AppendChild(letters_subBulletList);
                        }

                        if (letters_bulletItem.HasChildNodes)
                        {
                            bulletList.AppendChild(letters_bulletItem);
                        }

                        // Now add the techProducts
                        foreach (DataRow techProdRow in techProducts.Tables[0].Rows)
                        {
                            XmlElement bulletItem = cmcContentDoc.CreateElement("BulletItem");
                            bulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                            bulletItem.Attributes[0].Value = ((int)(techProducts.Tables[0].Rows.IndexOf(techProdRow) + 2)).ToString(Program.CultureInfo).Trim();

                            XmlElement bulletItemText = cmcContentDoc.CreateElement("Text");
                            bulletItemText.InnerText = Convert.ToString(techProdRow["tpd_nm"], Program.CultureInfo).Trim();
                            bulletItem.AppendChild(bulletItemText);

                            XmlElement subBulletList = cmcContentDoc.CreateElement("SubList");

                            subItemRank = 0;
                            foreach (DataRow letterRow in distinctLetterNames.Rows)
                            {
                                DataRow[] selectedValues = lettersInDrawing.Tables[0].Select("reference=" + Convert.ToString(techProdRow["reference"],Program.CultureInfo) + " AND letter_in_drawing='" + Convert.ToString(letterRow[0], Program.CultureInfo) + "'");

                                bool minExists = !Convert.ToString(selectedValues[0]["min"], Program.CultureInfo).Trim().Equals("NA");
                                bool nomExists = !Convert.ToString(selectedValues[0]["nom"], Program.CultureInfo).Trim().Equals("NA");
                                bool maxExists = !Convert.ToString(selectedValues[0]["max"], Program.CultureInfo).Trim().Equals("NA");

                                if (minExists)
                                {
                                    XmlElement subBulletItem = cmcContentDoc.CreateElement("SubItem");
                                    subBulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                                    subBulletItem.Attributes[0].Value = ((int)(++subItemRank)).ToString(Program.CultureInfo);

                                    XmlElement subBulletItemText = cmcContentDoc.CreateElement("Text");

                                    subBulletItemText.InnerText = Convert.ToString(selectedValues[0]["min"], Program.CultureInfo).Trim();

                                    subBulletItem.AppendChild(subBulletItemText);
                                    subBulletList.AppendChild(subBulletItem);
                                }

                                if (nomExists)
                                {
                                    XmlElement subBulletItem = cmcContentDoc.CreateElement("SubItem");
                                    subBulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                                    subBulletItem.Attributes[0].Value = ((int)(++subItemRank)).ToString(Program.CultureInfo).Trim();

                                    XmlElement subBulletItemText = cmcContentDoc.CreateElement("Text");
                                    subBulletItemText.InnerText = Convert.ToString(selectedValues[0]["nom"], Program.CultureInfo).Trim();

                                    subBulletItem.AppendChild(subBulletItemText);
                                    subBulletList.AppendChild(subBulletItem);
                                }

                                if (maxExists)
                                {
                                    XmlElement subBulletItem = cmcContentDoc.CreateElement("SubItem");
                                    subBulletItem.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                                    subBulletItem.Attributes[0].Value = ((int)(++subItemRank)).ToString(Program.CultureInfo).Trim();

                                    XmlElement subBulletItemText = cmcContentDoc.CreateElement("Text");
                                    subBulletItemText.InnerText = Convert.ToString(selectedValues[0]["max"], Program.CultureInfo).Trim();

                                    subBulletItem.AppendChild(subBulletItemText);
                                    subBulletList.AppendChild(subBulletItem);
                                }
                            }

                            if (subBulletList.HasChildNodes)
                            {
                                bulletItem.AppendChild(subBulletList);
                            }

                            if (bulletItem.HasChildNodes)
                            {
                                bulletList.AppendChild(bulletItem);
                            }
                        }

                        if (bulletList.HasChildNodes)
                        {
                            itemNode.AppendChild(bulletList);
                        }
                    }

                    if (itemNode.HasChildNodes)
                    {
                        richTextBlock.AppendChild(itemNode);
                    }
                }

                if (richTextBlock.HasChildNodes)
                {
                    cmcContentDoc.AppendChild(richTextBlock);
                }

                DataRow newRow = srcTable.NewRow();

                newRow[textIDColName] = ++maxTextDefID;
                newRow[textTypeColName] = dr["vis_type_cd"];
                newRow[richTextTypeColName] = cmcTextBlockType;
                newRow[textColName] = cmcContentDoc.OuterXml;
                newRow[lanIDColName] = dr["lan_id"];
                newRow[comFamCdColName] = dr["com_fam_cd"];
                newRow[buCdColName] = dr["bu_cd"];
                newRow[brandCdColName] = dr["brand_cd"];

                srcTable.Rows.Add(newRow);
            }            
        }

        /**
         * Method Name : ColumnEqual
         * Method Description : Determine two values are equal or not
         * Creation Date : 25/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           25/11/2009      Siddharth Naik      First creation
         */
        private static bool ColumnEqual(Object A, Object B)
        {
            // Compares two values to see if they are equal. 
            if (A == DBNull.Value && B == DBNull.Value) //  both are DBNull.Value
                return true;
            if (A == DBNull.Value || B == DBNull.Value) //  only one is DBNull.Value
                return false;
            return (A.Equals(B));  // value type standard comparison
        }

        /**
         * Method Name : SelectDistinct
         * Method Description : Get only distinct values from given datatable in a field.
         * Creation Date : 25/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           25/11/2009      Siddharth Naik      First creation
         */
        private static DataTable SelectDistinct(DataTable SourceTable, String FieldName)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(FieldName, SourceTable.Columns[FieldName].DataType);

            object LastValue = null;
            foreach (DataRow dr in SourceTable.Select("", FieldName))
            {
                if (LastValue == null || !(ColumnEqual(LastValue, dr[FieldName])))
                {
                    LastValue = dr[FieldName];
                    dt.Rows.Add(new object[] { LastValue });
                }
            }
            
            return dt;
        }

        /**
         * Method Name : doesValidValueExistInColForLetter
         * Method Description : Checks if no invalid value exists in a given field for a letter.
         * Creation Date : 25/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           25/11/2009      Siddharth Naik      First creation
         */
        private static bool doesValidValueExistInColForLetter(String invalidValue, String letter, DataTable SourceTable, String FieldNameInvalidValue, String FieldNameLetter)
        {
            DataRow[] rows = SourceTable.Select(FieldNameLetter + "='" + letter + "' AND " + FieldNameInvalidValue + "='" + invalidValue + "'");

            return (rows.Length == 0);
        }
    }
}
