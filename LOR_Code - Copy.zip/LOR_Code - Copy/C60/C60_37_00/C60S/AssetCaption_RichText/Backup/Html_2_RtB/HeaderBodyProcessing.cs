using System;
using System.Xml;
using System.Collections.Generic;

namespace Html2Rtb
{
    /**
     * Class Name : HeaderBodyProcessing
     * Class Description : Will handle transformation of html texts whose vis_type_cd mapping is for WOW & MarketingTextHeader.
     *                     Both these texts are separated by '\;'
     * Creation Date : 16/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           16/11/2009      Siddharth Naik      First creation
     */
    abstract class HeaderBodyProcessing
    {
        /**
         * Method Name : Transform
         * Method Description : WOW & MarketingTextHeader is extracted from html texts.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static String Transform(String htmlContent)
        {
            try
            {
                String wowText = String.Empty;
                String marketingTextHeader = String.Empty;
                int startIndex, endIndex;

                htmlContent = htmlContent.Replace("\n", String.Empty);

                // Get headContent -- Get the first <H1> Tag
                if (htmlContent.Contains("<H1>"))
                {
                    startIndex = htmlContent.IndexOf("<H1>"); endIndex = htmlContent.IndexOf("</H1>");
                    wowText = htmlContent.Substring((startIndex + "<H1>".Length), endIndex - (startIndex + "<H1>".Length)).Trim();
                    
                    // Remove the processed head from htmlContent
                    endIndex = (endIndex + "</H1>".Length) >= htmlContent.Length ? (htmlContent.Length - startIndex) : (endIndex + "</H1>".Length);
                    htmlContent = htmlContent.Remove(startIndex, endIndex);
                }                
                
                // Remove all htmlTags
                List<String> htmlTags = GetAllHtmlTags(htmlContent);
                foreach (String tag in htmlTags)
                {
                    htmlContent = htmlContent.Replace(tag, String.Empty);
                }

                marketingTextHeader = htmlContent.Trim();

                return "WOW=" + wowText + "\\;" + "MarketingTextHeader=" + marketingTextHeader;
            }
            catch
            {
                throw;
            }
        }

        /**
         * Method Name : GetAllHtmlTags
         * Method Description : Gets all the html tags that exist in the given html content.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static List<String> GetAllHtmlTags(String htmlContent)
        {
            List<String> htmlTags = new List<String>();

            int startIndex = 0;
            int endIndex = 0;

            while (true)
            {
                startIndex = htmlContent.IndexOf('<', startIndex);

                if (startIndex == -1)
                {
                    break;
                }

                endIndex = htmlContent.IndexOf('>', startIndex);

                htmlTags.Add(htmlContent.Substring(startIndex, endIndex - startIndex + 1));

                startIndex = endIndex + 1;
            }

            return htmlTags;
        }
    }
}
