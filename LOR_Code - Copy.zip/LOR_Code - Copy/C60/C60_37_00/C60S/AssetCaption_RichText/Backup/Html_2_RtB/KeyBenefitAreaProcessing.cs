using System;
using System.Xml;

namespace Html2Rtb
{
    /**
     * Class Name : KeyBenefitAreaProcessing
     * Class Description : Will handle transformation of html texts whose vis_type_cd mapping is for KeyBenefitArea.
     *                     Both these texts are separated by '\;'
     * Creation Date : 16/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           16/11/2009      Siddharth Naik      First creation
     */
    abstract class KeyBenefitAreaProcessing
    {
        private static int keyBenefitAreaCodeNumber;
        private static int featureCodeNumber;

        /**
         * Method Name : Transform
         * Method Description : Transforms html texts to KeyBenefitArea Structure.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static String Transform(String htmlContent1)
        {
            try
            {
                htmlContent1 = htmlContent1.Replace("<BR/>", String.Empty);
                htmlContent1 = htmlContent1.Replace("\n", String.Empty);

                htmlContent1 = "<ROOT>" + htmlContent1 + "</ROOT>";

                XmlDocument htmlContent = new XmlDocument();

                try
                {
                    htmlContent.LoadXml(htmlContent1);
                }
                catch (XmlException)
                {
                    try
                    {
                        htmlContent = WellFormedNessChecker.MakeWellFormed(htmlContent1);
                    }
                    catch (XmlException)
                    {
                        throw;
                    }
                }

                XmlDocument cmcContentDoc = new XmlDocument();

                XmlElement keyBenefitAreasBlock = cmcContentDoc.CreateElement("KeyBenefitAreas");
                
                XmlNodeList headNodeList = htmlContent.SelectNodes("ROOT/H1");

                if (headNodeList.Count == 0)
                {
                    return String.Empty;
                }

                for (int headItemNodeRank = 0; headItemNodeRank < headNodeList.Count; headItemNodeRank++)
                {   
                    if (headNodeList[headItemNodeRank].NextSibling != null)
                    {
                        XmlNodeList bulletItemList = headNodeList[headItemNodeRank].NextSibling.SelectNodes("LI");

                        for (int bulletItemRank = 0; bulletItemRank < bulletItemList.Count; bulletItemRank++)
                        {
                            XmlElement keyBenefitAreaBlock = cmcContentDoc.CreateElement("KeyBenefitArea");
                            XmlElement keyBenefitAreaCodeBlock = cmcContentDoc.CreateElement("KeyBenefitAreaCode");
                            XmlElement keyBenefitAreaName = cmcContentDoc.CreateElement("KeyBenefitAreaName");
                            XmlElement keyBenefitAreaRank = cmcContentDoc.CreateElement("KeyBenefitAreaRank");

                            keyBenefitAreaCodeBlock.InnerText = "LP_K_" + ((int)(keyBenefitAreaCodeNumber++)).ToString("0000", Program.CultureInfo);
                            keyBenefitAreaRank.InnerText = ((int)(bulletItemRank + 1)).ToString(Program.CultureInfo);
                            
                            if (bulletItemList[bulletItemRank].SelectSingleNode("text()") != null)
                            {
                                keyBenefitAreaName.InnerText = bulletItemList[bulletItemRank].SelectSingleNode("text()").InnerText.Trim();
                            }
                            else
                            {
                                keyBenefitAreaName.InnerText = String.Empty;
                            }

                            keyBenefitAreaBlock.AppendChild(keyBenefitAreaCodeBlock);
                            keyBenefitAreaBlock.AppendChild(keyBenefitAreaName);
                            keyBenefitAreaBlock.AppendChild(keyBenefitAreaRank);

                            if (bulletItemList[bulletItemRank].ChildNodes.Count > 1)
                            {
                                XmlNode subKeyBenefitAreasBlock = ProcessSubBulletList(bulletItemList[bulletItemRank], cmcContentDoc);

                                if (subKeyBenefitAreasBlock.HasChildNodes)
                                {
                                    foreach (XmlNode childNode in subKeyBenefitAreasBlock.ChildNodes)
                                    {
                                        keyBenefitAreaBlock.AppendChild(childNode);
                                    }
                                }
                            }                           

                            keyBenefitAreasBlock.AppendChild(keyBenefitAreaBlock);
                        }                       
                    }
                }

                if (keyBenefitAreasBlock.NodeType == XmlNodeType.EndElement)
                {
                    return String.Empty;
                }

                cmcContentDoc.AppendChild(keyBenefitAreasBlock);

                return keyBenefitAreasBlock.InnerXml;
            }
            catch
            {
                throw;
            }
        }

        /**
         * Method Name : ProcessSubBulletList
         * Method Description : The nested list tags are handled here. All list tags that are insided the 
         *                      uppermost list tags are transformed to feature texts.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static XmlNode ProcessSubBulletList(XmlNode htmlContent, XmlDocument bulletDocument)
        {
            XmlElement subKeyBenefitAreasBlock = bulletDocument.CreateElement("SubKeyBenefitAreas");

            XmlNodeList subBulletItemList = htmlContent.SelectNodes("UL/LI");

            for (int bulletItemRank = 0; bulletItemRank < subBulletItemList.Count; bulletItemRank++)
            {
                XmlElement featureBlock = bulletDocument.CreateElement("Feature");
                XmlElement featureCodeBlock = bulletDocument.CreateElement("FeatureCode");
                XmlElement featureReferenceNameBlock = bulletDocument.CreateElement("FeatureReferenceName");
                XmlElement featureNameBlock = bulletDocument.CreateElement("FeatureName");
                XmlElement featureGlossaryBlock = bulletDocument.CreateElement("FeatureGlossary");
                XmlElement featureRankBlock = bulletDocument.CreateElement("FeatureRank");
                XmlElement featureTopRankBlock = bulletDocument.CreateElement("FeatureTopRank");

                featureCodeBlock.InnerText = "LP_F_" + ((int)(featureCodeNumber++)).ToString("0000", Program.CultureInfo);
                featureRankBlock.InnerText = ((int)(bulletItemRank + 1)).ToString(Program.CultureInfo);

                if (subBulletItemList[bulletItemRank].SelectSingleNode("text()") != null)
                {
                    featureGlossaryBlock.InnerText = subBulletItemList[bulletItemRank].SelectSingleNode("text()").InnerText.Trim();
                }
                else
                {
                    featureGlossaryBlock.InnerText = String.Empty;
                }

                featureBlock.AppendChild(featureCodeBlock);
                featureBlock.AppendChild(featureReferenceNameBlock);
                featureBlock.AppendChild(featureNameBlock);
                featureBlock.AppendChild(featureGlossaryBlock);
                featureBlock.AppendChild(featureRankBlock);
                featureBlock.AppendChild(featureTopRankBlock);
                
                if (subBulletItemList[bulletItemRank].ChildNodes.Count > 1)
                {
                    XmlNode subKeyBenefitAreasBlockInner = ProcessSubBulletList(subBulletItemList[bulletItemRank], bulletDocument);

                    if (subKeyBenefitAreasBlockInner.HasChildNodes)
                    {
                        foreach (XmlNode childNode in subKeyBenefitAreasBlockInner.ChildNodes)
                        {
                            featureBlock.AppendChild(childNode);
                        }
                    }
                }

                subKeyBenefitAreasBlock.AppendChild(featureBlock);
            }

            return subKeyBenefitAreasBlock;
        }
    }
}
