using System;
using System.Xml;

namespace Html2Rtb
{
    /**
     * Class Name : LabelBulletSubBulletProcessing
     * Class Description : Will handle transformation of html texts whose vis_type_cd mapping is for LabelBulletSubBullet Structure.
     * Creation Date : 16/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           16/11/2009      Siddharth Naik      First creation
     */
    abstract class LabelBulletSubBulletProcessing
    {
        /**
         * Method Name : Transform
         * Method Description : Transforms html texts to LabelBulletSubBullet structure
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static String Transform(int textDefID, String htmlContent1, String cmcTextBlockType)
        {
            try
            {
                htmlContent1 = htmlContent1.Replace("<BR/>", String.Empty);
                htmlContent1 = htmlContent1.Replace("\n", String.Empty);

                htmlContent1 = "<ROOT>" + htmlContent1 + "</ROOT>";

                XmlDocument htmlContent = new XmlDocument();

                try
                {
                    htmlContent.LoadXml(htmlContent1);
                }
                catch (XmlException)
                {
                    try
                    {
                        htmlContent = WellFormedNessChecker.MakeWellFormed(htmlContent1);
                    }
                    catch (XmlException)
                    {
                        throw;
                    }
                }

                XmlDocument cmcContentDoc = new XmlDocument();
                
                XmlElement richTextBlock = cmcContentDoc.CreateElement("RichText");
                richTextBlock.Attributes.Append(cmcContentDoc.CreateAttribute("type"));
                richTextBlock.Attributes[0].Value = cmcTextBlockType;

                XmlNodeList labelNodeList = htmlContent.SelectNodes("ROOT/P");


                if (labelNodeList.Count == 0)
                {
                    // check if <H1> tag exists , if yes directly give the html for bullet processing
                    if (htmlContent.SelectSingleNode("ROOT/H1") != null)
                    {
                        return BulletProcessing.Transform(textDefID, htmlContent1.Replace("<ROOT>", "").Replace("</ROOT>", ""), cmcTextBlockType);
                    }
                    else
                    {
                        return String.Empty;
                    }
                }

                for (int labelItemRank = 0; labelItemRank < labelNodeList.Count; labelItemRank++)
                {
                    XmlElement itemNode = cmcContentDoc.CreateElement("Item");

                    // Attributes : code, referenceName, rank
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("code"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("referenceName"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));

                    itemNode.Attributes[0].Value = textDefID.ToString(Program.CultureInfo) + "_" + ((int)(labelItemRank + 1)).ToString(Program.CultureInfo);
                    itemNode.Attributes[1].Value = textDefID.ToString(Program.CultureInfo) + "_" + ((int)(labelItemRank + 1)).ToString(Program.CultureInfo);
                    itemNode.Attributes[2].Value = ((int)(labelItemRank + 1)).ToString(Program.CultureInfo);

                    XmlElement labelNode = cmcContentDoc.CreateElement("Head");
                    labelNode.InnerText = labelNodeList[labelItemRank].InnerText.Trim();
                    itemNode.AppendChild(labelNode);
                    
                    if (labelNodeList[labelItemRank].NextSibling != null)
                    {
                        XmlNode bulletList = BulletProcessing.ProcessBulletsOnly(labelNodeList[labelItemRank].NextSibling, cmcContentDoc);

                        if (bulletList.HasChildNodes)
                        {
                            itemNode.AppendChild(bulletList);
                        }
                    }

                    richTextBlock.AppendChild(itemNode);
                }
                               
                cmcContentDoc.AppendChild(richTextBlock);

                return cmcContentDoc.OuterXml;
            }
            catch
            {
                throw;
            }
        }
    }
}
