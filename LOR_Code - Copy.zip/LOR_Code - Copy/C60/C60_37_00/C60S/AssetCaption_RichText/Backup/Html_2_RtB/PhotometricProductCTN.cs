using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using Html2Rtb;

namespace Html_2_Rtb
{
    /**
     * Method Name : PhotometricProductCTN
     * Method Description : Handles transformation of photometric data
     * Creation Date : 25/11/2009
     * Creator : Naresh Bohra
     * History :
     *      Version     Date            Author              Remarks
     *      1           04/02/2010      Naresh Bohra      First creation         
     */
    abstract class PhotometricProductCTN
    {
        /**
         * Method Name : Transform
         * Method Description : Adds the photometric texts.
         * Creation Date : 04/02/2010
         * Creator : Naresh Bohra
         * History :
         *      Version     Date            Author              Remarks
         *      1           04/02/2010      Naresh Bohra     First creation
         */
        public static void Transform(DataTable srcTable, String vis_type_cd, String CTNvalue, String comfamcd, String bucd, String brandcd, String dim_richtext, String dim_table_seq_nr, String cmcTextBlockType)
        {
            srcTable.Columns.Add("CTN");
            srcTable.Columns.Add("lan_id");
            srcTable.Columns.Add("photom_richtext");

            SqlConnection con = new SqlConnection(Transformer.GetConnectionString());

            SqlCommand selectCommand = new SqlCommand(Transformer.photometricProductStoredProcs.Get("AllPhotomProdCTN"), con);
            selectCommand.CommandType = CommandType.StoredProcedure;
            selectCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;

            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = selectCommand;

            DataSet allPhotometricProducts = new DataSet();
            allPhotometricProducts.Locale = Program.CultureInfo;

            sda.Fill(allPhotometricProducts);

            DataView allPhotometricProductsDV = new DataView(allPhotometricProducts.Tables[0], String.Empty, "CTN, lan_id", DataViewRowState.OriginalRows);

            for (int rowIndex = 0; rowIndex < allPhotometricProductsDV.Count; rowIndex++)
            {
                DataRow dr = allPhotometricProductsDV[rowIndex].Row;

                String CTN = Convert.ToString(dr["CTN"], Program.CultureInfo).Trim();
                String lan_id = Convert.ToString(dr["lan_id"], Program.CultureInfo).Trim();

                DataRowView[] photomProducts = allPhotometricProductsDV.FindRows(new Object[] { CTN, lan_id });

                rowIndex = rowIndex + photomProducts.Length - 1;

                XmlDocument cmcContentDoc = new XmlDocument();
                XmlElement richTextBlock = cmcContentDoc.CreateElement("RichText");
                richTextBlock.Attributes.Append(cmcContentDoc.CreateAttribute("type"));
                richTextBlock.Attributes[0].Value = cmcTextBlockType.Trim();

                // this is one item
                int rankCounter = 0;
                foreach (DataRowView drv in photomProducts)
                {
                    XmlElement itemNode = cmcContentDoc.CreateElement("Item");
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("referenceName"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("code"));

                    itemNode.Attributes[0].Value = ((int)(++rankCounter)).ToString(Program.CultureInfo);
                    itemNode.Attributes[1].Value = Convert.ToString(drv["php_nm"], Program.CultureInfo).Trim();
                    itemNode.Attributes[2].Value = "LP_PHM_" + Convert.ToString(drv["php_id"], Program.CultureInfo).Trim();

                    XmlElement labelNode = cmcContentDoc.CreateElement("Head");
                    labelNode.InnerText = Convert.ToString(drv["php_nm"], Program.CultureInfo).Trim();
                    itemNode.AppendChild(labelNode);

                    richTextBlock.AppendChild(itemNode);
                }

                if (richTextBlock.HasChildNodes)
                {
                    cmcContentDoc.AppendChild(richTextBlock);
                }

                DataRow newRow = srcTable.NewRow();

                newRow["CTN"] = dr["CTN"];
                newRow["lan_id"] = dr["lan_id"];
                newRow["photom_richtext"] = cmcContentDoc.OuterXml;
                srcTable.Rows.Add(newRow);
            }
        }
    }
}
