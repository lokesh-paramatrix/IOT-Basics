using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using Html2Rtb;

namespace Html_2_Rtb
{
    /**
     * Method Name : PhotometricProductProcessing
     * Method Description : Handles transformation of photometric data
     * Creation Date : 25/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           25/11/2009      Siddharth Naik      First creation         
     */
    abstract class PhotometricProductProcessing
    {
        /**
         * Method Name : Transform
         * Method Description : Adds the photometric texts.
         * Creation Date : 25/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           25/11/2009      Siddharth Naik      First creation
         */
        public static void Transform(DataTable srcTable, String textIDColName, String textTypeColName, String richTextTypeColName, String textColName, String lanIDColName, String comFamCdColName, String buCdColName, String brandCdColName, String cmcTextBlockType)
        {
            srcTable.DefaultView.Sort = textIDColName;
            // use max text def id to auto generate the id for dimension diagram
            int maxTextDefID = Convert.ToInt32(srcTable.DefaultView[srcTable.DefaultView.Count - 1].Row[textIDColName], Program.CultureInfo);

            SqlConnection con = new SqlConnection(Transformer.GetConnectionString());

            SqlCommand selectCommand = new SqlCommand(Transformer.photometricProductStoredProcs.Get("AllPhotometricProducts"), con);
            selectCommand.CommandType = CommandType.StoredProcedure;
            selectCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;

            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = selectCommand;

            DataSet allPhotometricProducts = new DataSet();
            allPhotometricProducts.Locale = Program.CultureInfo;

            sda.Fill(allPhotometricProducts);

            DataView allPhotometricProductsDV = new DataView(allPhotometricProducts.Tables[0], String.Empty, "com_fam_cd, brand_cd, bu_cd", DataViewRowState.OriginalRows);
                        
            for (int rowIndex = 0; rowIndex < allPhotometricProductsDV.Count; rowIndex++)
            {
                DataRow dr = allPhotometricProductsDV[rowIndex].Row;

                String com_fam_cd = Convert.ToString(dr["com_fam_cd"], Program.CultureInfo).Trim();
                String brand_cd = Convert.ToString(dr["brand_cd"], Program.CultureInfo).Trim();
                String bu_cd = Convert.ToString(dr["bu_cd"], Program.CultureInfo).Trim();

                DataRowView[] photomProducts = allPhotometricProductsDV.FindRows(new Object[] { com_fam_cd, brand_cd, bu_cd });

                rowIndex = rowIndex + photomProducts.Length - 1;

                XmlDocument cmcContentDoc = new XmlDocument();
                XmlElement richTextBlock = cmcContentDoc.CreateElement("RichText");
                richTextBlock.Attributes.Append(cmcContentDoc.CreateAttribute("type"));
                richTextBlock.Attributes[0].Value = cmcTextBlockType.Trim();

                // this is one item
                int rankCounter = 0;
                foreach (DataRowView drv in photomProducts)
                {
                    XmlElement itemNode = cmcContentDoc.CreateElement("Item");
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("referenceName"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("code"));

                    itemNode.Attributes[0].Value = ((int)(++rankCounter)).ToString(Program.CultureInfo);
                    itemNode.Attributes[1].Value = Convert.ToString(drv["php_nm"], Program.CultureInfo).Trim();
                    itemNode.Attributes[2].Value = "LP_PHM_" + Convert.ToString(drv["php_id"], Program.CultureInfo).Trim();

                    XmlElement labelNode = cmcContentDoc.CreateElement("Head");
                    labelNode.InnerText = Convert.ToString(drv["php_nm"], Program.CultureInfo).Trim();
                    itemNode.AppendChild(labelNode);

                    richTextBlock.AppendChild(itemNode);
                }

                if (richTextBlock.HasChildNodes)
                {
                    cmcContentDoc.AppendChild(richTextBlock);
                }

                DataRow newRow = srcTable.NewRow();

                newRow[textIDColName] = ++maxTextDefID;                
                newRow[richTextTypeColName] = cmcTextBlockType;
                newRow[textColName] = cmcContentDoc.OuterXml;
                newRow[lanIDColName] = dr["lan_id"];
                newRow[comFamCdColName] = com_fam_cd;
                newRow[buCdColName] = bu_cd;
                newRow[brandCdColName] = brand_cd;

                srcTable.Rows.Add(newRow);
            }
        }
    }
}
