using System;
using System.Globalization;
using System.Collections.Specialized;

namespace Html2Rtb
{
    /**
     * Class Name : Program
     * Class Description : Entry point of the executable.
     * Creation Date : 16/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           16/11/2009      Siddharth Naik      First creation
     */
    internal sealed class Program
    {
        private static CultureInfo cultureInfo = CultureInfo.CurrentCulture;

        /**
         * Property Name : CultureInfo
         * Property Description : Gets the current culture, used for globalisation on string transformations.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static CultureInfo CultureInfo
        {
            get
            {
                return cultureInfo;
            }
        }

        /**
         * Property Name : SqlCommandTimeoutPeriod
         * Property Description : Gets time out period for sql commands
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static int SqlCommandTimeoutPeriod
        {
            get
            {
                return Convert.ToInt32( ((NameValueCollection)System.Configuration.ConfigurationManager.GetSection("ApplicationConstants")).Get("SqlCommandTimeout"), cultureInfo);
            }
        }

        /**
         * Method Name : Main
         * Method Description : Entry point.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static void Main(String[] args)
        {
            //Transformer.Transform(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);

            //Transformer.Transform("rt_rich_text", "text_def_id", "vis_type_cd", "rich_text_type", "new_text", "lan_id", "com_fam_cd", "bu_cd", "brand_cd",  Environment.CurrentDirectory);                        

            Transformer.Transform("rt_dim_table", "vis_type_cd","CTN","com_fam_cd", "bu_cd", "brand_cd","dim_richtext" ,"dim_table_seq_nr", Environment.CurrentDirectory); 
        }              
    }
}
