using System;
using System.Xml;
using System.Collections.Generic;

namespace Html2Rtb
{
    /**
     * Class Name : WellFormedNessChecker
     * Class Description : Checks whether given content is well formed. If not then corrects it.
     * Creation Date : 16/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           16/11/2009      Siddharth Naik      First creation
     */
    abstract class WellFormedNessChecker
    {
        /**
         * Method Name : MakeWellFormed
         * Method Description : Corrects the content if is not well formed.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static XmlDocument MakeWellFormed(String xmlContent)
        {
            Stack<String> xmlTagsStack = new Stack<String>();
            
            int startIndex = 0;
            int endIndex = 0;

            while (true)
            {
                // 1. Get a tag, irrespective if it an start or end tag
                startIndex = xmlContent.IndexOf('<', startIndex);
                if (startIndex == -1)
                {
                    break;
                }
                endIndex = xmlContent.IndexOf('>', startIndex);

                String tag = xmlContent.Substring(startIndex, endIndex - startIndex + 1);

                if (!IsEndTag(tag))
                {
                    xmlTagsStack.Push(tag);
                    startIndex = endIndex + 1;
                }
                else
                {
                    // check if the end tag matchs up with the tag present on the top of the stack
                    if (tag.Replace("/", String.Empty).Equals(xmlTagsStack.Peek()))
                    {
                        // a vaild end tag is there, so just leave
                        // pop out the stack.
                        xmlTagsStack.Pop();
                        startIndex = endIndex + 1;
                    }
                    else
                    {
                        // insert the end tag then for the tag present at the top of stack
                        String neededEndTag = xmlTagsStack.Pop().Insert(1, "/");
                        xmlContent = xmlContent.Insert(startIndex, neededEndTag);
                        startIndex++;
                    }
                }                
            }

            // Now insert end tags for any tags that may still be left in the stack.
            while (xmlTagsStack.Count > 0)
            {
                xmlContent = xmlContent + xmlTagsStack.Pop().Insert(1, "/");
            }

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlContent);

            return doc;
        }

        /**
         * Method Name : IsEndTag
         * Method Description : Checks whether given tag is an end tag.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static bool IsEndTag(String tag)
        {
            return tag.Contains("</");
        }
    }
}
