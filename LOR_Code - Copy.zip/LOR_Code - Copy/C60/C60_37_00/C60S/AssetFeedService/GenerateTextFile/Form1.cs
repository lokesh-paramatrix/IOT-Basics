﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace GenerateTextFile
{
    public partial class Form1 : Form
    {
        public DataSet dsviselemnr;
        public DataSet dsvisdetails;
        public DataSet dscataproduct = new DataSet();
        public DataSet dslanguage = new DataSet();
        public DataSet dscaptionText = new DataSet();
        public string cataproduct = String.Empty;
        public string visLanguage = String.Empty;
        public string viscaptionText = String.Empty;
        private bool Printflag;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblMessage.Text = String.Empty;
            SqlConnection sqlConnection = new SqlConnection("data source=INDVK6Y921\\VIJAY; initial catalog=PRISMA_TEST_DB_M30_0_1_0; integrated security=SSPI; persist security info=False; Trusted_Connection=Yes");
            sqlConnection.Open();
            SqlCommand cmdviselemnr = sqlConnection.CreateCommand();
            cmdviselemnr.CommandType = CommandType.StoredProcedure;
            cmdviselemnr.CommandText = "sp_asset_feed_vis_elem_s_01";
            SqlDataAdapter sqlDAviselemnr = new SqlDataAdapter(cmdviselemnr);
            DataSet dsviselemnr = new DataSet();
            dsviselemnr.Clear();
            sqlDAviselemnr.Fill(dsviselemnr);
            string txtFileName = GetFileName();
            StreamWriter swTextFile = File.AppendText(txtFileName);
            for (int cntelem = 0; cntelem <= dsviselemnr.Tables[0].Rows.Count - 1; cntelem++)
            {
                Printflag = false;
                SqlCommand cmdvisdetails = sqlConnection.CreateCommand();
                cmdvisdetails.CommandType = CommandType.StoredProcedure;
                cmdvisdetails.CommandText = "sp_asset_feed_details_s_01";
                cmdvisdetails.Parameters.Add("@vis_elem_nr", SqlDbType.Int).Value = dsviselemnr.Tables[0].Rows[cntelem][0];
                SqlDataAdapter sqlDAvisdetails = new SqlDataAdapter(cmdvisdetails);
                DataSet dsvisdetails = new DataSet();
                dsvisdetails.Clear();

                sqlDAvisdetails.Fill(dsvisdetails);
                for (int cntvisdetail = 0; cntvisdetail <= dsvisdetails.Tables[0].Rows.Count - 1; cntvisdetail++)
                {
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["vis_elem_nr"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["vis_elem_descr"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["vis_file_name"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["file_format"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["file_format_descr"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["vis_type_cd"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["vis_type_descr"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["sort_seq_nr"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["vis_class_descr"].ToString().Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["fam_cd"].ToString().Trim());
                    if (Printflag == false)
                    {
                        dscataproduct.Clear();
                        cataproduct = String.Empty;
                        SqlCommand cmdcataproduct = sqlConnection.CreateCommand();
                        cmdcataproduct.CommandType = CommandType.StoredProcedure;
                        cmdcataproduct.CommandText = "sp_asset_feed_cata_product_s_01";
                        cmdcataproduct.Parameters.Add("@vis_elem_nr", SqlDbType.Int).Value = dsviselemnr.Tables[0].Rows[cntelem][0];
                        SqlDataAdapter sqlDAcataproduct = new SqlDataAdapter(cmdcataproduct);
                        sqlDAcataproduct.Fill(dscataproduct);

                        for (int cntproduct = 0; cntproduct <= dscataproduct.Tables[0].Rows.Count - 1; cntproduct++)
                        {
                            if (cataproduct != "")
                            {
                                cataproduct = cataproduct + "," + dscataproduct.Tables[0].Rows[cntproduct]["eop_full_eoc"].ToString().Trim();
                            }
                            else
                            {
                                cataproduct = dscataproduct.Tables[0].Rows[cntproduct]["eop_full_eoc"].ToString().Trim();
                            }
                        }

                        dslanguage.Clear();
                        visLanguage = String.Empty;
                        SqlCommand cmdlanguage = sqlConnection.CreateCommand();
                        cmdlanguage.CommandType = CommandType.StoredProcedure;
                        cmdlanguage.CommandText = "sp_asset_feed_language_s_01";
                        cmdlanguage.Parameters.Add("@vis_elem_nr", SqlDbType.Int).Value = dsviselemnr.Tables[0].Rows[cntelem][0];
                        SqlDataAdapter sqlDAlanguage = new SqlDataAdapter(cmdlanguage);
                        sqlDAlanguage.Fill(dslanguage);

                        for (int cntlanguage = 0; cntlanguage <= dslanguage.Tables[0].Rows.Count - 1; cntlanguage++)
                        {
                            if (visLanguage != "")
                            {
                                visLanguage = visLanguage + "," + dslanguage.Tables[0].Rows[cntlanguage]["lan_id"].ToString().Trim();
                            }
                            else
                            {
                                visLanguage = dslanguage.Tables[0].Rows[cntlanguage]["lan_id"].ToString().Trim();
                            }
                        }

                        dscaptionText.Clear();
                        viscaptionText = String.Empty;
                        SqlCommand cmdcaptionText = sqlConnection.CreateCommand();
                        cmdcaptionText.CommandType = CommandType.StoredProcedure;
                        cmdcaptionText.CommandText = "sp_asset_feed_captionText_s_01";
                        cmdcaptionText.Parameters.Add("@vis_elem_nr", SqlDbType.Int).Value = dsviselemnr.Tables[0].Rows[cntelem][0];
                        SqlDataAdapter sqlDAcaptionText = new SqlDataAdapter(cmdcaptionText);
                        sqlDAcaptionText.Fill(dscaptionText);

                        for (int cntcaption = 0; cntcaption <= dscaptionText.Tables[0].Rows.Count - 1; cntcaption++)
                        {
                            if (viscaptionText != "")
                            {
                                viscaptionText = viscaptionText + "," + dscaptionText.Tables[0].Rows[cntcaption]["caption_text"].ToString().Trim();
                            }
                            else
                            {
                                viscaptionText = dscaptionText.Tables[0].Rows[cntcaption]["caption_text"].ToString().Trim();
                            }
                        }
                    }
                    swTextFile.Write("\t");
                    swTextFile.Write(cataproduct.Trim());
                    swTextFile.Write("\t");
                    swTextFile.Write(dsvisdetails.Tables[0].Rows[cntvisdetail]["vis_grp_name"].ToString().Trim());

                    swTextFile.Write("\t");
                    swTextFile.Write(visLanguage.Trim());

                    swTextFile.Write("\t");
                    swTextFile.Write(viscaptionText.Trim());

                    swTextFile.Write(Environment.NewLine);
                    Printflag = true;
                }
            }
            lblMessage.Text = "File Created Successfully.";
            swTextFile.Close();
            sqlConnection.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private String GetFileName()
        {
            string dtTime = (DateTime.Now.Year) + "" + (DateTime.Now.Month) + "" + (DateTime.Now.Day) + "" + (DateTime.Now.Hour) + "" + (DateTime.Now.Minute) + "" + (DateTime.Now.Second) + "" + (DateTime.Now.Millisecond);
            string TextFilePath = "c:\\PrismaFile\\" + dtTime + ".txt";
            return TextFilePath;
        }
    }
}
