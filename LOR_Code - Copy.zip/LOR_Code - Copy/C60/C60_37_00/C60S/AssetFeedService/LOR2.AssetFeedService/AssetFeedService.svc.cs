﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Xml;
using System.ServiceModel.MsmqIntegration;
using System.Threading;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

#endregion System

#region Custom

using PRISMA.LOR2.FeedServiceDefinition;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;
using IsDnaJobManagement;
using PrismaGeneral;


#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.AssetFeedService
{
    /// <summary>
    /// 
    /// </summary>
    public class AssetFeedService : FeedServiceBase.FeedServiceBase, IAssetFeedService
    {
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        private delegate void CallCreateAssetFeedXMLFile(IParamSource objParams);

        #endregion Member variables

        #region Constructors
        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods

        /// <summary>
        /// Creates the Asset feed XML file.
        /// </summary>
        /// <param name="message">The message.</param>
        //private void CreateAssetFeedXMLFile(FeedMessage message)
        private void CreateAssetFeedXMLFile(IParamSource objParams)
        {
            #region COMMENTED BY Avdhut Vaidya
            //Logger.LogInfoMessage("AssetFeedService - Start: void CreateAssetFeedXMLFile(string message).");

            //XmlTextWriter textWriter = new XmlTextWriter((Constants.Asset_FEED_XML_FILE_PATH + Constants.Asset_FEED_XML_FILE_NAME + ".xml"), Encoding.UTF8);
            //textWriter.Formatting = Formatting.Indented;
            //textWriter.WriteProcessingInstruction("xml", "version='1.0' encoding='UTF-8'");

            //textWriter.WriteStartElement("FeedMessage");
            //textWriter.WriteElementString("JobID", message.JobID.ToString());
            //textWriter.WriteElementString("JobRunID", message.JobRunID.ToString());
            //textWriter.WriteElementString("FeedName", message.FeedName);
            //textWriter.WriteElementString("TargetGroupCode", message.TargetGroupCode);

            //textWriter.WriteEndElement();
            //textWriter.Close();

            //Logger.LogInfoMessage("AssetFeedService - Start: void CreateAssetFeedXMLFile(string message)."); 
            #endregion //COMMENTED BY Avdhut Vaidya

            IJobControl2 objJobControl;
            long jrnID;

            jrnID = Convert.ToInt64(objParams.GetParam("jrn_id"));

            objJobControl = (IJobControl2)Activator.CreateInstance(Type.GetTypeFromProgID("C93Control.clsChannelControl"));

            //Avdhut : NOTE : Substitute the following job id with the one that will be created in the interface table
            objJobControl.FStart("{9B331888-6050-4E36-95C3-7650341B3F22}", jrnID, objParams);
        }

        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Processes the feed message.
        /// </summary>
        /// <param name="message">The message.</param>
        [OperationBehavior(TransactionScopeRequired = true)]
        public void ProcessFeedMessage(FeedMessage message)
        {
            try
            {
                string[] locales;

                locales = message.Locales;

                Logger.LogInfoMessage("AssetFeedService - Start: void ProcessFeedMessage(string message).");

                ThreadHelper workerThread;
                IParamSource objParams;

                objParams = (IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));

                objParams.SetParam("jrn_id", message.JobRunID.ToString());
                objParams.SetParam("job_id", message.JobID.ToString());
                objParams.SetParam("tg_cd", message.TargetGroupCode);

                for (int index = 0; index < locales.Length; index++)
                {
                    objParams.SetParam("locale", locales[index]);
                    workerThread = new ThreadHelper();
                    workerThread.MethodToCall = new CallCreateAssetFeedXMLFile(this.CreateAssetFeedXMLFile);
                    workerThread.SetParameter(objParams);
                    workerThread.StartThread();
                    workerThread.WaitForThread();
                }

                #region COMMENTED BY Avdhut Vaidya
                ////int threadCount = ((message.Locales.Length < Convert.ToInt32(Constants.NO_OF_Asset_FEED_SERVICE_THREADS)) ? message.Locales.Length : Convert.ToInt32(Constants.NO_OF_Asset_FEED_SERVICE_THREADS));
                //int threadCount = Convert.ToInt32(Constants.NO_OF_Asset_FEED_SERVICE_THREADS);
                //ThreadHelper workerThread;
                //string[] errors = new string[threadCount];


                //for (int index = 0; index < threadCount; index++)
                //{
                //    workerThread = new ThreadHelper();
                //    workerThread.MethodToCall = new CallCreateAssetFeedXMLFile(this.CreateAssetFeedXMLFile);
                //    workerThread.SetParameter(message);
                //    workerThread.StartThread();
                //    workerThread.WaitForThread();
                //    errors[index] = workerThread.ErrorMessage;
                //} 
                #endregion //COMMENTED BY Avdhut Vaidya

                Logger.LogInfoMessage("AssetFeedService - End: void ProcessFeedMessage(string message).");
            }

            catch (Exception exception)
            {
                bool rethrow = ExceptionPolicy.HandleException(exception, Constants.LOG_ONLY_POLICY);
                if (rethrow)
                {
                    throw;
                }
            }
        }

        #endregion Public Methods

        #endregion Methods
    }
}
