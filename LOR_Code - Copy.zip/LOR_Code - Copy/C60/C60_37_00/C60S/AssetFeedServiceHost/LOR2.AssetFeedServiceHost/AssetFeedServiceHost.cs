﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.ServiceModel;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

#endregion System

#region Custom
using Common;
using PRISMA.LOR2.Common.Logging.Logging;
using PRISMA.LOR2.Common;

#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.AssetFeedServiceHost
{
    /// <summary>
    /// 
    /// </summary>
    public partial class AssetFeedServiceHost : System.ServiceProcess.ServiceBase
    {
        #region Member variables

        private Logger logger;
        private ServiceHost assetFeedServiceHost = null;
        
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AssetFeedServiceHost"/> class.
        /// </summary>
        public AssetFeedServiceHost()
        {
            InitializeComponent();
            logger = new Logger();
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// When implemented in a derived class, executes when a Start command is sent to the service by the Service Control Manager (SCM) or when the operating system starts (for a service that starts automatically). Specifies actions to take when the service starts.
        /// </summary>
        /// <param name="args">Data passed by the start command.</param>
        protected override void OnStart(string[] args)
        {
            try
            {
                logger.LogInfoMessage("AssetFeedServiceHost - Start: void override void OnStart(string[] args).");

                if (assetFeedServiceHost != null)
                {
                    assetFeedServiceHost.Close();
                }

                //Create a ServiceHost for the AssetFeedService type and provide the base address.
                assetFeedServiceHost = new ServiceHost(typeof(AssetFeedService.AssetFeedService));

                //Open the ServiceHostBase to create listeners and start listening for messages.
                assetFeedServiceHost.Open();


                logger.LogInfoMessage("AssetFeedServiceHost - End: void override void OnStart(string[] args).");
            }

            catch (Exception ex)
            {
                assetFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// When implemented in a derived class, executes when a Stop command is sent to the service by the Service Control Manager (SCM). Specifies actions to take when a service stops running.
        /// </summary>
        protected override void OnStop()
        {
            try
            {
                logger.LogInfoMessage("AssetFeedServiceHost - Start: void OnStop().");

                if (assetFeedServiceHost != null)
                {
                    assetFeedServiceHost.Close();
                    assetFeedServiceHost = null;
                }

                logger.LogInfoMessage("AssetFeedServiceHost - End: void OnStop().");
            }

            catch (Exception ex)
            {
                assetFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }
        }

        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
    }
}