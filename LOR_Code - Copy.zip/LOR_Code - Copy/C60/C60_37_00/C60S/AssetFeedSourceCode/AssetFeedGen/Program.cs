﻿//===============================================================================
//= File Name        : Program.cs
//= File Description : 
//=
//= Creation Date    : 
//= Authors          : Kailash Alle
//===============================================================================
//= History
//=
//= Version      Date        Author             Notes
//= 1.0         17/02/2010   Sarfaraz K         Added cmc_lan_id in command file
//= 2.0         08/06/2010   Arif Shaikh        Added Md5 checksum in command file
//= 3.0         07/07/2010   Arif Shaikh        Changed the logic by considering deeper path
//= 4.0         11/02/2011	 Prasad Mangle		CHG1:New Rich Media Player Assets: Video files
//= 5.0         06/06/2011   Prasad Mangle      Added one doc type PGL for locale en_US
//= 6.0         09/09/2011   Rahul Mulchandani  MCM#107 Implementation of locale
//= 7.0         05/12/2011   Manisha Dubey      IM0589948 Photometric visuals are missing on e-Catalogue 
//                                                         for BBS560i
//===============================================================================
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.IO;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using PRISMA.LOR2.Common;
using Common;
using PrismaGeneral;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.Configuration;

namespace AssetFeedGen
{
    class Program
    {
        public static DataSet dscataproduct = new DataSet();

        static void Main(string[] args)
        {
            try
            {
                IParamSource param = null;

                string strActualFileName;
                string[] strArrayActualFileName = new string[15];
                //Added by Arif
                //06-06-2011    Prasad M    Added one doc type PGL
               // string[] strDocType = new string[] { "CER", "DOC", "ENV", "INI", "SMA", "MSD", "WRN", "LTE","PGL" };

                SqlDatabase database = new SqlDatabase(Prismaconst.g_strXMLDB);

                //Added by Arif on 07-07-2010 for deeper path
                PrismaC07BS.IPrismaSettingsQuery objPrismaSettings = null;

                PrismaGeneral.IParamSource vObjParams;

                vObjParams = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                vObjParams.SetParam("_dbmodule_system", null);

                objPrismaSettings = (PrismaC07BS.IPrismaSettingsQuery)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));

                string sVisElemUNCPath = objPrismaSettings.GetSettingValue("visual_elements_unc_path", vObjParams).Trim();
                int intUNCPathLength = sVisElemUNCPath.Length;
                //Added by Arif
                string assetfeedDestinationPath = Convert.ToString(ConfigurationSettings.AppSettings["AssetfeedDestinationPath"]);

                string strSource = assetfeedDestinationPath;
                string strDestination = strSource + @"\Backup";

                //Added by arif

                string xmlFileName = strSource + @"\CONTENT-LOADED.xml";

                System.IO.File.Delete(strSource + @"\CONTENT-LOADED.xml");

                MoveFilestoBackupFolder(strSource, strDestination);

                //StreamswTextFile swTextFile = new StreamswTextFile(GetFileName(assetfeedDestinationPath), true, Encoding.ASCII);

                string txtFileName = GetFileName(assetfeedDestinationPath);
                //<<start issue ID IM0589948>>
                StreamWriter swTextFile = new StreamWriter(txtFileName, true, Encoding.UTF8);
                //StreamWriter swTextFile = new StreamWriter(txtFileName, true, Encoding.ASCII);
                //<<end issue ID IM0589948>>
                dscataproduct = database.ExecuteDataSet("sp_asset_feed_cata_product_s_01", param);

                DataTable distinctCTNs = SelectDistinct(dscataproduct.Tables[0], "CTN");

                DataView cataProductsDV = new DataView(dscataproduct.Tables[0], String.Empty, "CTN", DataViewRowState.OriginalRows);

                for (int index = 0; index < distinctCTNs.Rows.Count; index++)
                {
                    DataRowView[] visuals_per_CTN = cataProductsDV.FindRows(Convert.ToString(distinctCTNs.Rows[index][0]));

                    List<String> usedDocTypeWithSubTypes = new List<String>();

                    int intdoctypecount = 0;

                    for (int visual_per_CTN_index = 0; visual_per_CTN_index < visuals_per_CTN.Length; visual_per_CTN_index++)
                    {
                        DataRowView currRow = visuals_per_CTN[visual_per_CTN_index];

                        if (visual_per_CTN_index == Convert.ToInt32(currRow.Row["doc_type_count"]))
                        {
                            break;
                        }

                        if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["vis_file_name_actual"])))
                        {
                            //Added for Deeper path
                            strActualFileName = currRow.Row["vis_file_name_actual"].ToString().Trim();
                            strActualFileName = strActualFileName.Remove(0, intUNCPathLength + 1);
                            strArrayActualFileName = currRow.Row["vis_file_name_actual"].ToString().Trim().Split(new char[] { '\\' });

                            //<START>> Added by Prasad For CHG1   08-02-2011
                            int subTypeLen = 0;

                            if (!string.IsNullOrEmpty(currRow.Row["sub_type"].ToString().Trim()))
                                subTypeLen = (currRow.Row["sub_type"].ToString().Trim()).IndexOf('%');
                            //<END>> Added by Prasad For CHG1   08-02-2011

                            int arrlength = strArrayActualFileName.Length;

                            swTextFile.Write(strArrayActualFileName[arrlength - 1]);
                            swTextFile.Write(";");
                            //Commente By Arif for deeper path
                            //swTextFile.Write(strArrayActualFileName[4] + @"\" + strArrayActualFileName[5] + @"\" + strArrayActualFileName[6]);
                            swTextFile.Write(strActualFileName);
                            swTextFile.Write(";");
                            if (currRow.Row["model"].ToString().Trim() == "Object")
                            {
                                swTextFile.Write(currRow.Row["CTN"].ToString().Trim());
                                swTextFile.Write(";");
                                swTextFile.Write("O");
                                swTextFile.Write(";");

                                //<<START>> Added by Prasad For CHG1   08-02-2011
                                //swTextFile.Write(currRow.Row["vis_type_cd"].ToString().Trim());
                                if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["vis_type_cd"]).Trim()))
                                {

                                    if (string.IsNullOrEmpty(Convert.ToString(currRow.Row["sub_type"])))
                                    {
                                        swTextFile.Write(currRow.Row["vis_type_cd"].ToString().Trim());
                                        intdoctypecount = 0;
                                    }
                                    else
                                    {
                                        if (!usedDocTypeWithSubTypes.Contains(currRow.Row["vis_type_cd"].ToString().Trim()))
                                        {
                                            usedDocTypeWithSubTypes.Add(currRow.Row["vis_type_cd"].ToString().Trim());
                                            intdoctypecount = 0;
                                        }
                                        if (intdoctypecount == 0)
                                        {
                                            swTextFile.Write(currRow.Row["vis_type_cd"].ToString().Trim());
                                            intdoctypecount++;
                                        }
                                        else
                                        {
                                            swTextFile.Write(currRow.Row["sub_type"].ToString().Trim().Substring(0, subTypeLen) + Convert.ToString(intdoctypecount) + "_");
                                            intdoctypecount++;
                                        }
                                    }
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["sub_type"])) && string.IsNullOrEmpty(Convert.ToString(currRow.Row["locale"])))
                                    {
                                        if (!usedDocTypeWithSubTypes.Contains(currRow.Row["sub_type"].ToString().Trim()))
                                        {
                                            usedDocTypeWithSubTypes.Add(currRow.Row["sub_type"].ToString().Trim());
                                            intdoctypecount = 1;
                                        }

                                        swTextFile.Write(currRow.Row["sub_type"].ToString().Trim().Substring(0, subTypeLen) + Convert.ToString(intdoctypecount));
                                        intdoctypecount++;

                                    }
                                    if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["sub_type"])) && !string.IsNullOrEmpty(Convert.ToString(currRow.Row["locale"])))
                                    {
                                        if (!usedDocTypeWithSubTypes.Contains(currRow.Row["sub_type"].ToString().Trim() + "_" + currRow.Row["locale"].ToString().Trim()))
                                        {
                                            usedDocTypeWithSubTypes.Add(currRow.Row["sub_type"].ToString().Trim() + "_" + currRow.Row["locale"].ToString().Trim());
                                            intdoctypecount = 1;
                                        }

                                        swTextFile.Write(currRow.Row["sub_type"].ToString().Trim().Substring(0, subTypeLen) + Convert.ToString(intdoctypecount));
                                        intdoctypecount++;

                                    }
                                }
                                //<END>> Added by Prasad For CHG1   08-02-2011
                                if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["md5_checksum"])))
                                {
                                    swTextFile.Write(";");
                                    swTextFile.Write(currRow.Row["md5_checksum"].ToString().Trim());
                                }


                                //if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["locale"])))
                                //{
                                //    swTextFile.Write(";");
                                //    swTextFile.Write(currRow.Row["locale"].ToString().Trim());
                                //}--Commented and added below for MCM#107 by Rahul M


                                //int localeFlag = 0; //MCM#107
                                //foreach (string str in strDocType)
                                //{
                                //    if (currRow.Row["vis_type_cd"].ToString().Trim() == str)
                                //    {
                                //        swTextFile.Write(";");
                                //        swTextFile.Write("en_US");
                                //        localeFlag = 1;
                                //        break;
                                //    }
                                //}

                                //<<Start>>--Rahul M MCM#107 Implementation of locale
                                //if (localeFlag == 0)
                                //{
                                    if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["locale"])))
                                    {
                                        swTextFile.Write(";");
                                        swTextFile.Write(currRow.Row["locale"].ToString().Trim());
                                    }
                                //}
                                //<<END>>
                            }
                            else
                            {
                                swTextFile.Write(currRow.Row["CTN"].ToString().Trim());
                                swTextFile.Write(";");
                                swTextFile.Write("P");
                                swTextFile.Write(";");

                                //<START>> Added by Prasad For CHG1   08-02-2011
                                if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["vis_type_cd"]).Trim()))
                                {
                                    //<END>> Added by Prasad For CHG1   08-02-2011
                                    if (string.IsNullOrEmpty(Convert.ToString(currRow.Row["sub_type"])))
                                    {
                                        swTextFile.Write(currRow.Row["vis_type_cd"].ToString().Trim());
                                        intdoctypecount = 0;
                                    }
                                    else
                                    {
                                        if (!usedDocTypeWithSubTypes.Contains(currRow.Row["vis_type_cd"].ToString().Trim()))
                                        {
                                            usedDocTypeWithSubTypes.Add(currRow.Row["vis_type_cd"].ToString().Trim());
                                            intdoctypecount = 0;
                                        }
                                        if (intdoctypecount == 0)
                                        {
                                            swTextFile.Write(currRow.Row["vis_type_cd"].ToString().Trim());
                                            intdoctypecount++;
                                        }
                                        else
                                        {
                                            //<START>> Added by Prasad For CHG1   08-02-2011
                                            //swTextFile.Write(currRow.Row["sub_type"].ToString().Trim().Substring(0, 1) + Convert.ToString(intdoctypecount) + "_");
                                            //swTextFile.Write(currRow.Row["sub_type"].ToString().Trim().Substring(0, subTypeLen) + Convert.ToString(intdoctypecount) + "_"); //Commented by Samir Sahu for MCM#145
                                            //<END>> Added by Prasad For CHG1   08-02-2011
                                            //<<START>> Modified by Samir Sahu for MCM#145
                                            swTextFile.Write(currRow.Row["sub_type"].ToString().Trim().Substring(0, subTypeLen) + Convert.ToString(intdoctypecount) + "_");
                                            //<<END>> Modified by Samir Sahu for MCM#145

                                            intdoctypecount++;
                                        }
                                    }
                                }
                                //<START>> Added by Prasad For CHG1   08-02-2011
                                else
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["sub_type"])))
                                    {
                                        if (!usedDocTypeWithSubTypes.Contains(currRow.Row["sub_type"].ToString().Trim()))
                                        {
                                            usedDocTypeWithSubTypes.Add(currRow.Row["sub_type"].ToString().Trim());
                                            intdoctypecount = 1;
                                        }

                                        swTextFile.Write(currRow.Row["sub_type"].ToString().Trim().Substring(0, subTypeLen) + Convert.ToString(intdoctypecount));
                                        intdoctypecount++;

                                    }
                                }
                                //<END>> Added by Prasad For CHG1   08-02-2011
                                if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["md5_checksum"])))
                                {
                                    swTextFile.Write(";");
                                    swTextFile.Write(currRow.Row["md5_checksum"].ToString().Trim());
                                }
                                ////Added by sarfaraz
                                //if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["cmc_lan_id"])))
                                //{
                                //    swTextFile.Write(";;");
                                //    swTextFile.Write(currRow.Row["cmc_lan_id"].ToString().Trim());
                                //}

                                //int localeFlag = 0; //MCM#107
                                //foreach (string str in strDocType)
                                //{
                                //    if (currRow.Row["vis_type_cd"].ToString().Trim() == str )
                                //    {
                                //        swTextFile.Write(";");
                                //        swTextFile.Write("en_US");
                                //        localeFlag = 1;
                                //        break;
                                //    }
                                //}

                                //<<Start>>--Rahul M MCM#107 Implementation of locale
                                //if (localeFlag == 0)
                                //{
                                    if (!string.IsNullOrEmpty(Convert.ToString(currRow.Row["locale"])))
                                    {
                                        swTextFile.Write(";");
                                        swTextFile.Write(currRow.Row["locale"].ToString().Trim());
                                    }
                                //}
                                //<<END>>
                            }
                            swTextFile.Write(Environment.NewLine);

                        }
                    }

                }
                swTextFile.Close();
                //<<start issue ID IM0589948>>
                StreamWriter swXMLFile = new StreamWriter(xmlFileName, true, Encoding.UTF8);
                //StreamWriter swXMLFile = new StreamWriter(xmlFileName, true, Encoding.ASCII);
                //<<end issue ID IM0589948>>
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
            }
        }






        private static bool ColumnEqual(Object A, Object B)
        {
            // Compares two values to see if they are equal. 
            if (A == DBNull.Value && B == DBNull.Value) //  both are DBNull.Value
                return true;
            if (A == DBNull.Value || B == DBNull.Value) //  only one is DBNull.Value
                return false;
            return (A.Equals(B));  // value type standard comparison
        }

        private static DataTable SelectDistinct(DataTable SourceTable, String FieldName)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(FieldName, SourceTable.Columns[FieldName].DataType);

            object LastValue = null;
            foreach (DataRow dr in SourceTable.Select("", FieldName))
            {
                if (LastValue == null || !(ColumnEqual(LastValue, dr[FieldName])))
                {
                    LastValue = dr[FieldName];
                    dt.Rows.Add(new object[] { LastValue });
                }
            }

            return dt;
        }
        //Added by Arif
        private static void MoveFilestoBackupFolder(string strSource, string strDestination)
        {
            DirectoryInfo info = new DirectoryInfo(strSource);
            if (!Directory.Exists(strDestination))
            {
                Directory.CreateDirectory(strDestination);
            }
            string[] files = Directory.GetFiles(strSource);
            foreach (string str2 in files)
            {
                string fileName = Path.GetFileName(str2);
                string destFileName = Path.Combine(strDestination, fileName);
                File.Move(str2, destFileName);
            }
        }



        private static String GetFileName(String filepath)
        {
            string dtTime = (DateTime.Now.Year) + "" + (DateTime.Now.Month.ToString("D2")) + "" + (DateTime.Now.Day.ToString("D2")) + "" + (DateTime.Now.Hour) + "" + (DateTime.Now.Minute) + "" + (DateTime.Now.Second) + "" + (DateTime.Now.Millisecond);
            //string TextFilePath = "C:\\WINDOWS\\Temp\\LOR2_Destinations\\" + "Lighting_Assets_" + dtTime + "_command.txt";
            //string TextFilePath = "D:\\LOR2\\Destinations\\LOR2_Extractions\\ECATLIG\\Asset\\" + "Lighting_Assets_" + dtTime + "_command.txt";
            string TextFilePath = filepath + "Lighting_Assets_" + dtTime + "_command.txt";

            return TextFilePath;
        }
    }
}