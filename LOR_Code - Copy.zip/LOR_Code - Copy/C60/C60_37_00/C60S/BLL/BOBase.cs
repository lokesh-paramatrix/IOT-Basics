﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.BLL
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class BOBase : IDisposable
    {
        #region Member variables
        #endregion Member variables

        #region Constructors
        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Dispose managed resources
                //if (daoFactory != null)
                //{
                //    daoFactory.Dispose();
                //}
            }

            // Free native resources
        }

        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion Public Methods

        #endregion Methods
    }
}
