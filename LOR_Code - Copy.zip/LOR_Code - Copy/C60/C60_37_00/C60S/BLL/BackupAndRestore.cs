﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IsDNAImportTypelib;
using System.IO;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;

namespace PRISMA.LOR2.BLL
{
    public class BackupAndRestore : IGenericStep
    {
        #region IGenericStep Members
        long m_lngRunID = 0;
        string IGenericStep.FProcessData(string v_strData, PrismaGeneral.IParamSource v_objParams, System.Xml.XmlNode v_objComponentData, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            string strTempFileName;
            string strFinalFileName;
            string strBackupFolder;
            string strFolderName;
            string strFileLookupFormatString;
            string strFileLookupFormatStringKEY;
            string strDestinationsDirectory;

            m_lngRunID = Convert.ToInt32(v_objParams.GetParam("jrn_id"));

            //first move the current file to the final directory
            strDestinationsDirectory = modXMLFunctions.FGetNodeText(v_objComponentData, "FINAL_FILE_DESTINATION");
            if (strDestinationsDirectory == "")
                strDestinationsDirectory = modXMLFunctions.FGetNodeText(v_objComponentData, "FINAL_FILENAME");
            strDestinationsDirectory = Path.GetDirectoryName(strDestinationsDirectory);

            strFinalFileName = Path.GetFileName(v_strData);
            strFinalFileName = Path.Combine(strDestinationsDirectory, strFinalFileName);
            File.Move(v_strData, strFinalFileName);

            //move the older files to the backup directory
            strBackupFolder = modXMLFunctions.FGetNodeText(v_objComponentData, "BACKUP_FILENAME");
            strFolderName = Path.GetDirectoryName(strFinalFileName);

            strFileLookupFormatStringKEY = v_objParams.GetParam("xmlFileLookupFormatStringKEY");
            if(strFileLookupFormatStringKEY == "")
                strFileLookupFormatStringKEY = "xmlFileNameFormatString";
            strFileLookupFormatString = FileHelper.GetValueFromConfigOrPS(strFileLookupFormatStringKEY, v_objParams);
            strFileLookupFormatString = strFileLookupFormatString.Replace("%DateTimeStamp%", "\"DateTimeStamp\"");
            strFileLookupFormatString = FileHelper.EvaluateFormatString(strFileLookupFormatString, v_objParams);
            strFileLookupFormatString = strFileLookupFormatString.Replace("DateTimeStamp", "??????????????");

            moveFilesToBackup(strFolderName, strBackupFolder, strFileLookupFormatString, strFinalFileName, v_objJobLogger);

            string strTemp;
            strTemp = Path.GetFileNameWithoutExtension(strFileLookupFormatString);
            strFileLookupFormatString = strTemp + "_err" + Path.GetExtension(strFileLookupFormatString);
            moveFilesToBackup(strFolderName, strBackupFolder, strFileLookupFormatString, strFinalFileName, v_objJobLogger);

            return strFinalFileName;
        }

        private void moveFilesToBackup(string FolderName, string BackupFolder, string FileLookupPattern, string FileToSkip, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            //System.Diagnostics.EventLog evt;
            //evt = new System.Diagnostics.EventLog();
            //evt.Source = this.ToString();
            //evt.WriteEntry("FileToSkip:" + Path.GetFileName(FileToSkip));
            foreach (String strFileName in Directory.GetFiles(FolderName, FileLookupPattern))
            {
                if (Path.GetFileName(strFileName) != Path.GetFileName(FileToSkip))
                {
                    try
                    {
                        //evt.WriteEntry("Moving : " + strFileName + " To " + BackupFolder);
                        File.Move(strFileName, Path.Combine(BackupFolder, Path.GetFileName(strFileName)));
                    }
                    catch (IOException ioEx)
                    {
                        v_objJobLogger.FLog(m_lngRunID, "ERROR While Copying File " + strFileName + " to Backup Folder:\r\n" + ioEx.Message);
                        ExceptionPolicy.HandleException(ioEx, Prismaconst.LogOnlyPolicy);
                    }
                }
            }
        }

        #endregion
    }
}
