﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using PrismaGeneral;
using System.IO;

namespace PRISMA.LOR2.BLL
{
    public class ComponentData
    {
        public string FeedName = "";

        public ComponentData(string _feedName)
        {
            FeedName = _feedName;
        }

        public void Create(ref XmlNode xNodeComponentData, IParamSource objParamSource, int Stage, bool appendFeedName)
        {
            XmlDocument xDoc;
            XmlNode xNode;
            string strTemp;
            string keyNameSuffix = "";


            if (appendFeedName == true)
                keyNameSuffix = FeedName;

            if (xNodeComponentData == null)
            {
                xDoc = new XmlDocument();
                xNodeComponentData = xDoc.CreateElement("COMPONENT");
            }
            else
            {
                xDoc = xNodeComponentData.OwnerDocument;
            }

            if (Stage == 1) //CREATING FILE @ a temporary location
            {

                xNode = xDoc.CreateElement("FILENAME");
                xNode.InnerText = Path.Combine(FileHelper.FullFilePath(objParamSource, "LOR2TempXMLFolder" + keyNameSuffix),
                                                FileHelper.FileName(objParamSource, "xmlFileNameFormatString" + keyNameSuffix));
                xNodeComponentData.AppendChild(xNode);

            }
            else if (Stage == 2) //VALIDATING the FILE
            {
                xNode = xDoc.CreateElement("VALIDATION-TYPE");
                xNode.InnerText = "XSD";
                xNodeComponentData.AppendChild(xNode);

                xNode = xDoc.CreateElement("xml_schema_path");
                xNode.InnerText = FileHelper.GetValueFromConfigOrPS("xml_schema_url" + keyNameSuffix, objParamSource);
                xNodeComponentData.AppendChild(xNode);
            }
            else if (Stage == 3) //COPYING the FILE @ the final destination and BACKINGUP the earlier file
            {
                //xNode = xNodeComponentData.SelectSingleNode("FILENAME");
                //strTemp = xNode.InnerText;
                //xNodeComponentData.RemoveChild(xNode);

                //xNode = xDoc.CreateElement("TEMP_FILENAME");
                //xNode.InnerText = strTemp;
                //xNodeComponentData.AppendChild(xNode);

                //strTemp = Path.GetFileName(strTemp);
                xNode = xDoc.CreateElement("FINAL_FILE_DESTINATION");
                xNode.InnerText = FileHelper.FullFilePath(objParamSource, "LOR2FolderStructure" + keyNameSuffix);
                xNodeComponentData.AppendChild(xNode);

                xNode = xDoc.CreateElement("BACKUP_FILENAME");
                xNode.InnerText = FileHelper.FullFilePath(objParamSource, "LOR2BackupXMLFolder" + keyNameSuffix);
                xNodeComponentData.AppendChild(xNode);
            }

        }

        public void Create(ref XmlNode xNodeComponentData, IParamSource objParamSource, int Stage)
        {
            Create(ref xNodeComponentData, objParamSource, Stage, false);
        }
    }
}
