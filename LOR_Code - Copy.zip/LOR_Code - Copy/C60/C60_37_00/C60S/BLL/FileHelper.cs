﻿///File Summary
///Author       : Avdhut Vaidya
///Description  :
///File Name    : FileHelper.cs
///Class        : FileHelper
///NameSpace    : PRISMA.LOR2.BLL

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PrismaGeneral;
using System.Configuration;
using System.IO;
using System.Threading;

namespace PRISMA.LOR2.BLL
{
    /// <summary>
    /// The class will take care of two main things
    /// 1)Creating a folder structure
    /// 2)Generating the file name
    /// </summary>
    public static class FileHelper
    {

        #region Constructors
        #endregion //Constructors

        #region Methods

        #region Private
        private static string getDateTimeStamp()
        {
            string strFormat;
            strFormat = System.Configuration.ConfigurationManager.AppSettings["DateTimeFormat"].ToString();
            if (strFormat == "")
                strFormat = "yyyyMMddhhmmss";
            return DateTime.Now.ToString(strFormat);
        }
        private static bool validateFormatString(string formatString)
        {
            string[] formatStringSections;
            string tempString;
            formatStringSections = formatString.Split('+');

            foreach (String section in formatStringSections)
            {
                //if a sections STARTS with a double quote 
                //then it should also END with a double quote
                if (section.StartsWith("\"") !=
                    section.EndsWith("\""))
                {
                    return false;
                }

                //there should be no double quotes in middle of any section
                tempString = section.Substring(1, section.Length - 2);
                if (tempString.Contains("\"") == true)
                {
                    return false;
                }
            }

            return true;
        }
        public static string GetValueFromConfigOrPS(string key, IParamSource objParam)
        {
            string strValue;
            strValue = ConfigurationManager.AppSettings[key];

            if (strValue == null)
            {
                strValue = objParam.GetParam(key);
            }

            return strValue;
        }
        public static string EvaluateFormatString(string formatString, IParamSource objParam)
        {
            string[] formatStringSections;
            string strTemp;
            string result = "";

            if (validateFormatString(formatString) == false)
                throw new Exception("INVALID FORMAT STRING:" + formatString);

            formatStringSections = formatString.Split('+');
            foreach (String section in formatStringSections)
            {
                if (section.StartsWith("\""))
                {
                    strTemp = section.Substring(1, section.Length - 2);
                }
                else
                {
                    strTemp = section;
                    if (strTemp.ToLower() == "%datetimestamp%")
                    {
                        strTemp = getDateTimeStamp();
                    }
                    else if (strTemp.ToLower() == "%tempdirectory%")
                    {
                        strTemp = System.IO.Path.GetTempPath();
                    }
                    else if (strTemp.ToLower() == "%threadid%")
                    {
                        strTemp = Thread.CurrentThread.ManagedThreadId.ToString();
                    }
                    else if (Environment.GetEnvironmentVariable(strTemp) != null)
                    {
                        strTemp = Environment.GetEnvironmentVariable(strTemp);
                    }
                    else
                    {
                        strTemp = GetValueFromConfigOrPS(strTemp, objParam);
                    }
                }
                result += strTemp;
            }

            return result;
        }
        #endregion

        #region Public

        /// <summary>
        /// generates a file name based on the format string
        /// </summary>
        /// <param name="objParamSource">the param source should provide for all the values that form part of the formatString</param>
        /// <param name="formatString">the name of the key from the CONFIG file that specifies the format of the file name
        /// (in the format string [inside the config file] seperate different sections with a "+" sign and enclose constants in quotes)</param>
        /// <returns>the generated file name</returns>
        public static string FileName(IParamSource objParamSource, string formatStringLookupKey)
        {
            string formatString;
            string[] formatStringSections;
            string strTemp;
            string result = "";

            formatString = GetValueFromConfigOrPS(formatStringLookupKey, objParamSource);

            result = EvaluateFormatString(formatString, objParamSource);

            return result;
        }

        /// <summary>
        /// generates the entire path in which the file is to be created. also, creates the necessary
        /// folder structure if it does not exist
        /// </summary>
        /// <param name="objParamSource">the param source should provide for all the values that are part of the key</param>
        /// <param name="formatStringLookupKey">the name of the key from the CONFIG file that holds the format string forming the path structure of the file</param>
        /// <returns>the generated path</returns>
        public static string FullFilePath(IParamSource objParamSource, string formatStringLookupKey)
        {
            IParamSource objParamSettings = null;
            string strFolderStructure = "";
            string strVal = "";
            string result = "";

            try
            {
                objParamSettings = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));
                strFolderStructure = GetValueFromConfigOrPS(formatStringLookupKey, objParamSettings);

                if (strFolderStructure.EndsWith("\\"))
                    strFolderStructure = strFolderStructure.Substring(0, strFolderStructure.Length - 2);

                foreach (string section in strFolderStructure.Split('\\'))
                {
                    strVal = EvaluateFormatString(section, objParamSource);
                    if (strVal.EndsWith("\\") == false)
                        strVal += "\\";

                    result += strVal;
                }

                if (Directory.Exists(result) == false)
                {
                    try
                    {
                        System.Diagnostics.EventLog.WriteEntry("FileHelper", result);
                        Directory.CreateDirectory(result);
                    }
                    catch (Exception excep)
                    {
                        System.Diagnostics.EventLog.WriteEntry("FileHelper", excep.Message);
                        throw;
                    }
                }

                return result;
            }
            finally
            {
                if (objParamSettings != null) ((IDisposable)objParamSettings).Dispose();
            }
        }

        public static long FileSize(string fileName)
        {
            FileInfo fi = null;

            try
            {
                if (File.Exists(fileName) == false)
                    throw new FileNotFoundException("Invalid filename : " + fileName);

                fi = new FileInfo(fileName);
                return fi.Length;
            }
            catch
            {
                throw;
            }
            finally
            {
                fi = null;
            }
        }
        #endregion

        #endregion //Methods
    }
}
