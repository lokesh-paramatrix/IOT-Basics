﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using PrismaGeneral;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;

namespace PRISMA.LOR2.BLL
{
    public class LOR2Queries : IsDNAImportTypelib.IComponentDataSupplier, PrismaGeneral.ICommonRead, IDisposable
    {

        private DataSet ReadFilter(PrismaGeneral.IParamSource v_objParamSource)
        {
            DataSet result = null;
            PrismaGeneral.IParamSource objParamCopy = null;
            ICommonRead obj91BSXMLQueries = null;
            //SQLHelper objExecFromPS;
            SqlDatabase objExecFromPS;
            try
            {
                string strWhere = String.Empty;
                string strSPName = String.Empty;

                objParamCopy = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                v_objParamSource.CopyParams(objParamCopy);

                strWhere = objParamCopy.GetParam("where").Trim();
                switch (strWhere.ToLower())
                {
                    case "pmt-feed-ctn-cached-ft":
                        strSPName = "sp_pmt_feed_product_info";
                        break;
                    case "pmt-feed-ctn-text-cached-ft":
                        strSPName = "sp_pmt_feed_product_text";
                        break;
                    case "pmt-feed-ctn-acc-cached-ft":
                        strSPName = "sp_pmt_feed_product_accessory";
                        break;
                    case "pmt-feed-char-cached-ft":
                        strSPName = "sp_pmt_feed_char";
                        break;
                    case "pmt-feed-lor-data":
                        strSPName = "sp_pmt_feed_lor_data";
                        break;
                    case "pmt-feed-char-grp":
                        strSPName = "sp_pmt_feed_char_grp";
                        break;
                    case "cat-fam-feed-cached-ft":
                        strSPName = "sp_rt_catalog_family_feed";
                        break;
                    case "cat-fam-feed-prodref-cached-ft":
                        strSPName = "sp_rt_catalog_family_feed_prodref";
                        break;
                    case "catalog-feed-cached-ft":
                        strSPName = "sp_catalog_feed_info";
                        break;
                    case "catalog-feed-attribute-cached-ft":
                        strSPName = "sp_catalog_feed_attribute";
                        break;

                    case "catg-feed-wprod-cached-ft":
                        strSPName = "sp_cata_atrribute";
                        break;
                    case "catg-feed-wprod-cat-grp": //returns a set of sub catalog groups under a given catalog group
                        strSPName = "sp_categorization_feed_with_cat_grp_s_01";
                        break;
                    case "catg-feed-wprod-cat-fam": //returns a set of catalog families under a given catalog group
                        strSPName = "sp_categorization_feed_with_cat_fam_s_01";
                        break;
                    case "catg-feed-wprod-prod": //returns a set of products under a given catalog family
                        strSPName = "sp_categorization_feed_cat_prod_s_01";
                        break;
                    case "catg-feed-woprod-cat-grp": //returns a set of sub catalog groups under a given catalog group for a given language
                        strSPName = "sp_categorization_feed_wo_cat_grp_s_01";
                        break;
                    case "catg-feed-woprod-cat-fam": //returns a set of catalog families under a given catalog group
                        strSPName = "sp_categorization_feed_wo_cat_fam_s_01";
                        break;

                    case "pmt-feed-prod-cluster":
                        strSPName = "sp_pmt_feed_product_clusters";
                        break;

                    case "pmt-feed-award":
                        strSPName = "sp_pmt_awards";
                        break;

                    case "cat-fam-feed-award":
                        strSPName = "sp_get_cat_fam_awards";
                        break;

                    case "pmt-feed-naming-string":
                        strSPName = "sp_pmt_feed_naming_string";
                        break;

                    case "pmt-feed-naming-string-product-photo":
                        strSPName = "sp_rt_pmt_product_photo";
                        break;

                    case "pmt-feed-system-logo":
                        strSPName = "sp_pmt_system_logos";
                        break;

                    case "cat-fam-pmt-product-photo":
                        strSPName = "sp_rt_pmt_product_photo";
                        break;

                    case "cat-fam-feed-filters":
                        strSPName = "sp_catalog_family_feed_filters";
                        break;

                    case "cat-fam-feed-system-logo":
                        strSPName = "sp_catalog_family_system_logos";
                        break;

                    case "cat-fam-get-prod-ref-types":
                        strSPName = "sp_cat_fam_get_prod_ref_types";
                        break;
                    case "cmc-locale-details":
                        strSPName = "sp_get_cmc_locale_details";
                        break;
                    case "log_locale_run_start_time":
                        objExecFromPS = new SqlDatabase("JOB_MGR");
                        objExecFromPS.ExecuteNonQuery("sp_locale_run_i_01", v_objParamSource);
                        return null;
                    case "log_locale_run_end_time":
                        objExecFromPS = new SqlDatabase("JOB_MGR");
                        objExecFromPS.ExecuteNonQuery("sp_locale_run_u_01", v_objParamSource);
                        return null;
                    case "log_locale_run_status":
                        objExecFromPS = new SqlDatabase("JOB_MGR");
                        objExecFromPS.ExecuteNonQuery("sp_locale_run_u_02", v_objParamSource);
                        return null;
                    case "log_locale_run_file_size":
                        objExecFromPS = new SqlDatabase("JOB_MGR");
                        objExecFromPS.ExecuteNonQuery("sp_locale_run_u_03", v_objParamSource);
                        return null;
                    default:
                        obj91BSXMLQueries = (PrismaGeneral.ICommonRead)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC91BS.clsC91BSXMLQueries"));
                        result = obj91BSXMLQueries.ReadFilter(v_objParamSource);
                        break;
                }

                //objExecFromPS = new SQLHelper();
                if (strSPName != "")
                {
                    objExecFromPS = new SqlDatabase("PRISMA_XML");
                    result = objExecFromPS.ExecuteDataSet(strSPName, objParamCopy);
                }
                return result;

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (obj91BSXMLQueries != null) ((IDisposable)obj91BSXMLQueries).Dispose();
                if (objParamCopy != null) ((IDisposable)objParamCopy).Dispose();
                if (result != null) result.Dispose();
                objExecFromPS = null;
            }

        }



        #region IComponentDataSupplier Members

        void IsDNAImportTypelib.IComponentDataSupplier.FGetComponentData(ref System.Xml.XmlNode v_objStaticData, PrismaGeneral.IParamSource v_objParams)
        {

            PrismaGeneral.IParamSource objSettings = null;
            C54FileNameSource.IFileNameSource objNames = null;

            DataSet rsNames;


            XmlNode objSchemaNode;
            XmlNode objFileNameNode;
            string strSchemaPath;
            string strSchemaFileName;
            string strDestinationFolder;
            string strXMLFileName;

            objSettings = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));


            #region Identify the xdr to be used
            strSchemaPath = objSettings.GetParam("xml_schema_path");
            strSchemaFileName = v_objStaticData.SelectSingleNode("DYNAMIC-DATA/PARAM[@name = 'xdr']").InnerText;

            //Put the XDR file in the DATA node
            if (v_objStaticData.SelectSingleNode("SCHEMA-FILENAME") == null)
            {
                objSchemaNode = (XmlNode)v_objStaticData.OwnerDocument.CreateElement("SCHEMA-FILENAME");
                objSchemaNode.InnerText = Path.Combine(strSchemaPath, strSchemaFileName);
                v_objStaticData.AppendChild(objSchemaNode);
            }
            #endregion //Identify the xdr to be used

            #region Identify the final output file name and location

            objNames = (C54FileNameSource.IFileNameSource)Activator.CreateInstance(Type.GetTypeFromProgID("FileNameSource.clsAllNames"));
            rsNames = objNames.RSAllNames(v_objParams);

            strDestinationFolder = (Convert.ToString(rsNames.Tables[0].Rows[0]["DestinationFolderN"]) + "").Trim();
            strXMLFileName = (Convert.ToString(rsNames.Tables[0].Rows[0]["FullExtrFileN"])).Trim();

            //Put the final output file name in the DATA node
            objFileNameNode = (XmlNode)v_objStaticData.OwnerDocument.CreateElement("FILENAME");
            objFileNameNode.InnerText = Path.Combine(strDestinationFolder, strXMLFileName);
            v_objStaticData.AppendChild(objFileNameNode);
            #endregion //Identify the final output file name and location
        }

        #endregion

        #region ICommonRead Members

        System.Data.DataSet ICommonRead.ReadAll(IParamSource objParamSource)
        {
            throw new NotImplementedException();
        }

        System.Data.DataSet ICommonRead.ReadFilter(IParamSource objParamSource)
        {
            return ReadFilter(objParamSource);
        }

        System.Data.DataSet ICommonRead.ReadOne(IParamSource objParamSource)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            //implement the DISPOSE()
        }

        #endregion
    }
}
