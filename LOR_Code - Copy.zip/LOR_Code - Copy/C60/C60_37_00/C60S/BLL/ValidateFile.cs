﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IsDNAImportTypelib;

namespace PRISMA.LOR2.BLL
{
    class ValidateFile : IGenericStep
    {
        #region IGenericStep Members

        string IGenericStep.FProcessData(string v_strData, PrismaGeneral.IParamSource v_objParams, System.Xml.XmlNode v_objComponentData, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            //validate the file against necessary DTDs, etc
            return "";
        }

        #endregion
    }
}
