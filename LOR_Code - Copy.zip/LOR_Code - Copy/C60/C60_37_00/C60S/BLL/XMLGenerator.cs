﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;
using IsDnaXmlExtractionTlb;
using IsDnaJobManagement;
using System.Data;
using System.IO;
using PrismaGeneral;
using PRISMA.LOR2.BLL;
using PRISMA.LOR2.Common;
using Microsoft.Practices.EnterpriseLibrary.Common.Instrumentation;
using System.Globalization;

namespace PRISMA.LOR2.BLL
{
    public sealed class XMLGenerator
    : IsDnaXmlExtractionTlb.IGenerator,
        IsDnaXmlExtractionTlb.IControlInfo,
        IsDNAImportTypelib.IGenericStep
    {
        private enum eAttrType
        {
            atUnknown = 0,
            atDataField = 1,
            atCounter = 2
        }

        private struct Key
        {
            public string Name;
            public string Type;
            public string FilterBeforePart;
            public string FilterAfterPart;
            public static Key CreateInstance()
            {
                Key result = new Key();
                result.Name = String.Empty;
                result.Type = String.Empty;
                result.FilterBeforePart = String.Empty;
                result.FilterAfterPart = String.Empty;
                return result;
            }
        }

        private bool m_bAbort;
        private int m_lngRunID;
        private string m_strTmpFileName = String.Empty;
        private string m_strResult = String.Empty;
        private bool m_abort = false;

        /// <summary>
        /// initializes the Schema & the XML Writer object
        /// </summary>
        /// <param name="objSchema">The schema that holds reference to the XDR</param>
        /// <param name="xWriter">The XmlWriter object which writes the XML to the final file</param>
        private void fInitXMLObjects(ref XmlDocument objSchema, ref XmlWriter xWriter)
        {
            try
            {
                objSchema = new XmlDocument();
                xWriter = XmlWriter.Create(m_strTmpFileName);
                xWriter.WriteProcessingInstruction("xml", "version=\"1.0\" encoding=\"UTF-8\"");
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private void fFreeXMLObjects(ref XmlDocument objSchema, ref XmlNamespaceManager objSchemaNS, ref IControlInfo objControlInfo, ref XmlWriter xWriter)
        {
            try
            {
                objSchema = null;
                objControlInfo = null;
                xWriter = null;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }


        private bool fLoadSchema(ref XmlDocument objSchema, ref XmlNamespaceManager objSchemaNS, string strSchemaURL)
        {
            try
            {
                bool bResult = false;

                try
                {
                    objSchema.Load(strSchemaURL);
                    objSchemaNS = new XmlNamespaceManager(objSchema.NameTable);
                    objSchemaNS.AddNamespace("md", "urn:schema-infosupport-com:schema-ext");
                    objSchemaNS.AddNamespace("dt", "urn:schemas-microsoft-com:datatypes");

                    bResult = true;
                }
                catch (Exception e)
                {
                    bResult = false;
                    throw;
                }

                return bResult;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private XmlNode fGetSchemaRoot(ref XmlDocument objSchema)
        {
            XmlNode result;
            try
            {
                result = objSchema.DocumentElement.SelectSingleNode("element[position()= 1]");
                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private bool fProcessSchema(ref XmlDocument objSchema, XmlNamespaceManager objSchemaNS, IControlInfo objControlInfo, IJobLogger objJobLogger, IJobStatus objJobStatus, Dictionary<string, int> colCounters, Dictionary<string, DataView> objDataCache, IParamSource objParams, XmlNode objSchemaCurrNode, XmlWriter xWriter,
                                    int ilevel, string strNodeName,
                                    XmlNode objPrevNode)
        {
            DataSet rstData = null;
            XmlNode objDataNode = null;
            XmlNode objElemDef = null;
            DataRow drRstData = null; //The variable is for holding the rows from dataset - rstData
            XmlNode objNodeBuffer = null; //The variable will hold any Node that will be needed to be passed to the fProcessSchema() in case the current node is empty
            int iRowCounter = 0;
            bool bFlgElemWritten = false; //The variable will be set while writing XML to the stream, so that when fProcessSchema raises any error in a recursive call, it gets to know whether to call the WriteEndElement
            bool bProcessingChilds = false;
            bool result = false;
            try
            {
                ilevel = ilevel + 1;

                bool bEnd = false;
                bool bCreateNode = false;
                bool bSkip = false;
                bool fCheckJobAbortingStatus = false;

                //First get the element definition
                //The element definition determines the attributes and the child elements
                //for the current element
                //'element definition' is the 'ElementType' element from the schema.
                objElemDef = modXMLFunctions.FGetNodeDef(objSchemaCurrNode);
                if (objElemDef.Attributes["name"].Value == "ProductReferences") { string strTemp = "strTemp"; }
                frsGetCacheData(objElemDef, objSchemaNS, objControlInfo, objJobLogger, objDataCache, objParams);

                // Now get the data for this node
                rstData = fGetNodeData(objSchemaCurrNode, objSchemaNS, objControlInfo, objJobLogger, objDataCache, objParams);

                bCreateNode = false;
                bEnd = true;
                bProcessingChilds = false;

                fCheckJobAbortingStatus = modXMLFunctions.FGetNodeText(objSchemaCurrNode, "@md:CheckAborting", objSchemaNS).ToLower() == "true";
                do
                {
                    if (fCheckJobAbortingStatus)
                    {
                        pCheckJobRunAborting(objJobStatus);
                    }

                    bCreateNode = rstData == null;
                    if (rstData != null)
                    {
                        bCreateNode = rstData.Tables.Count == 0;
                    }
                    if (!bCreateNode)
                    {
                        bCreateNode = iRowCounter < rstData.Tables[0].Rows.Count;
                        if (bCreateNode == true)
                        {
                            drRstData = rstData.Tables[0].Rows[iRowCounter];
                            iRowCounter = iRowCounter + 1;
                            bEnd = false;
                        }
                        else
                        {
                            bEnd = true;
                        }
                    }
                    else
                    {
                        bEnd = true;
                        bCreateNode = objSchemaCurrNode.SelectSingleNode("md:datasource", objSchemaNS) == null || fIsTable(objSchemaCurrNode, objSchemaNS);
                    }

                    if (bCreateNode)
                    {
                        // If there is data then process the element
                        // First if any log information is present, log it
                        fLogMessage(objSchemaCurrNode, objSchemaNS, objControlInfo, objJobLogger, drRstData, objParams, ilevel);
                        // If any counter data present, then update the counters
                        fProcessCounters(ref objSchema, objSchemaNS, objControlInfo, objJobLogger, colCounters, objSchemaCurrNode, objParams);

                        // if the element defines a table then do some special processing
                        // otherwise try to create the element with all his attributes
                        if (fIsTable(objSchemaCurrNode, objSchemaNS))
                        {
                            bFlgElemWritten = fCreateTableFromData(ref objSchema, objSchemaNS, objControlInfo, objJobLogger, colCounters, objDataCache, drRstData, objSchemaCurrNode, xWriter, objParams);
                        }
                        else
                        {
                            objDataNode = fCreateNodeFromData(drRstData, objSchemaNS, objControlInfo, objJobLogger, colCounters, objSchemaCurrNode, objParams);
                            bFlgElemWritten = false;
                            objNodeBuffer = objDataNode;

                            //check if the current node is EMPTY or NO that is no attributes and no child elements yet
                            // the 3rd condition in the IF is to check if the empty node in objDataNode is not any HTML node like <BR /> <h1 /> etc
                            //if the value of 'occurIf' is sub element, it indicates that the current element can occur
                            //only if there are sub elements to the current element, so the current element wont be written
                            //now, it will be written while the sub node (if found) is written

                            string occurIf = modXMLFunctions.FGetNodeText(objSchemaCurrNode, "@occurIf", "");

                            if ((objDataNode.Attributes.Count > 0 || objDataNode.ChildNodes.Count > 0
                                || objElemDef.Attributes["name"].Value != objDataNode.Name
                                || modXMLFunctions.FGetNodeText(objSchemaCurrNode, "@minOccurs", "0") != "0")
                                 && occurIf != "subElement")
                            {
                                //before writing this node, check if any previous nodes have been passed
                                if (objPrevNode != null)
                                {
                                    //while writing the previous element, ensure that its END ELEMENT is not written, this is because the current element
                                    //that is to be written should be sub element to the PREVIOUS ELEMENTS
                                    //so pass the value of parameter splBehaviour = 1
                                    writeFromXmlNodeToStream(objPrevNode, xWriter, false, 1);
                                    objPrevNode = null; //after writing the previous element once, set it to null so that it is not written again
                                }
                                writeFromXmlNodeToStream(objDataNode, xWriter, false);
                                result = true; //result = true tells the calling area that SOME NODE is been written to the output
                                bFlgElemWritten = true;

                            }
                            else if (objPrevNode != null)
                            {
                                //check if the previous node is not null, in case it is not null, then append the current element to prev node and
                                //then pass this node to the next call to fProcessSchema(). Store this node in objNodeBuffer
                                objNodeBuffer = objPrevNode.Clone(); //dont directly do any thing to objPrevNode, use a clone instead, because objPrevNode is been passed here ByRef
                                XmlNodeList objNodeBufferList;

                                //The node that should be added to the PrevNode should be at the lowest level
                                objNodeBufferList = objNodeBuffer.SelectNodes("//*");
                                if (objNodeBufferList.Count > 0)
                                {
                                    //using the XPath "//*" retrieves all the nodes in the objNodeBuffer and the lowest level node at the last position
                                    objNodeBufferList[objNodeBufferList.Count - 1].InnerXml = objDataNode.OuterXml; //Appending the node to the inner most level of Previous Node
                                }
                                else
                                {
                                    //if there are no sub nodes to the objPrevNode, the straight away append the objDataNode to the objNodeBuffer
                                    objNodeBuffer.InnerXml = objDataNode.OuterXml;
                                }
                            }
                        }
                        // Now save all attributes with indication save='yes' to the paramsource
                        //fSetParams(rstData, v_objSchemaCurrNode, v_objParams); Avdhut Vaidya
                        fSetParams(drRstData, objSchemaNS, objControlInfo, objJobLogger, objSchemaCurrNode, objParams); //Avdhut Vaidya
                        // If this element is a reference then do not process his childs
                        if (modXMLFunctions.FGetNodeText(objSchemaCurrNode, "@md:reference", objSchemaNS).ToLower() != "yes" && !fIsTable(objSchemaCurrNode, objSchemaNS))
                        {
                            foreach (XmlNode objChildNode in objElemDef.SelectNodes("element"))
                            {
                                //NOTE: Following try - catch - block is required, because, when there is an error
                                //in this for-each-loop, it should continue with the next objChildNode.
                                //Earlier the variable bProcessChilds was being used to do this. In the ErrHandler,
                                //there was a check that if bProcessingChilds = true then Resume Next.
                                try //try - catch block added by Avdhut
                                {
                                    bProcessingChilds = true;
                                    // In case of the root element the parent is different so use an other call
                                    if (objDataNode == null)
                                    {
                                        //fProcessSchema(v_objParams, objChildNode, (XmlNode) m_objXMLDoc.DocumentElement); Avdhut Vaidya
                                        fProcessSchema(ref objSchema, objSchemaNS, objControlInfo, objJobLogger, objJobStatus, colCounters, objDataCache, objParams, objSchemaCurrNode, xWriter, ilevel, objDataNode.Name.ToString()); //Avdhut Vaidya
                                    }
                                    else
                                    {
                                        //See if we want to skip this child
                                        bSkip = (modXMLFunctions.FGetNodeText(objChildNode, "@md:skip", objSchemaNS) == "yes");

                                        if (!bSkip)
                                        {
                                            if (bFlgElemWritten == false)
                                            {
                                                //if no node is written here, it means that the node was empty, so pass it to the next level
                                                if (fProcessSchema(ref objSchema, objSchemaNS, objControlInfo, objJobLogger, objJobStatus, colCounters, objDataCache, objParams, objChildNode, xWriter, ilevel, objDataNode.Name.ToString(), objNodeBuffer) == true)
                                                {
                                                    //if fProcessSchema() returns true, then it means that prevNode has been written to the output,
                                                    //so set objPrevNode to null and also set the flag bFlagElemWritten to true
                                                    objPrevNode = null;
                                                    bFlgElemWritten = true;
                                                    result = true;
                                                }
                                            }
                                            else
                                            {
                                                fProcessSchema(ref objSchema, objSchemaNS, objControlInfo, objJobLogger, objJobStatus, colCounters, objDataCache, objParams, objChildNode, xWriter, ilevel, objDataNode.Name.ToString()); //Avdhut Vaidya
                                            }
                                        }
                                    }
                                }
                                //catch (Exception e)
                                catch (XmlException e)
                                {
                                    fInsertErrorComment(e, objSchemaCurrNode, objControlInfo, objJobLogger, strNodeName, xWriter);
                                }
                            }
                            bProcessingChilds = false;
                        }

                        #region COMMENTED BY Avdhut Vaidya temporarily on 2009-09-10 @ 05:30 PM
                        //if (objDataNode != null)
                        //{
                        //    if (!(objDataNode.ChildNodes.Count == 0 &&
                        //        objDataNode.Attributes.Count == 0 &&
                        //        modXMLFunctions.FGetNodeText(objSchemaCurrNode, "@minOccurs", "0") == "0"))
                        //    {
                        //        writeFromXmlNodeToStream(objDataNode, xWriter, true);
                        //    }
                        //} 
                        #endregion //COMMENTED BY Avdhut Vaidya temporarily on 2009-09-10 @ 05:30 PM

                        //Write the "END" Element only if the start node is written
                        if (bFlgElemWritten == true)
                        {
                            xWriter.WriteEndElement();
                            bFlgElemWritten = false;
                            if (ilevel == 2) { xWriter.Flush(); }
                        }
                    }
                }
                while (!bEnd);



                return result;
            }
            catch (Exception excep)
            {
                objJobLogger.FLog(m_lngRunID, excep.Message + ":" + excep.StackTrace);
                if (bFlgElemWritten == true)
                {
                    result = true;
                    xWriter.WriteEndElement();
                }

                if (!m_abort)
                {
                    //Insert Error Comment in xml file and then continue
                    fInsertErrorComment(excep, objSchemaCurrNode, objControlInfo, objJobLogger, strNodeName, xWriter); //Avdhut Vaidya
                }

                if (m_abort)
                {
                    ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                    throw;
                }
                else
                {
                    if (rstData != null)
                    {
                        rstData.Dispose();
                    }
                    objDataNode = null;
                    objElemDef = null;
                }
            }
            finally
            {
                if (rstData != null)
                {
                    rstData.Dispose();
                }
                objDataNode = null;
                objElemDef = null;
            }

            return result;
        }

        private bool fProcessSchema(ref XmlDocument v_objSchema, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, IJobStatus v_objJobStatus, Dictionary<string, int> v_colCounters, Dictionary<string, DataView> v_objDataCache, PrismaGeneral.IParamSource v_objParams, XmlNode objChildNode, XmlWriter xWriter, int v_level, string strNodeName)
        {
            return fProcessSchema(ref v_objSchema, v_objSchemaNS, v_objControlInfo, v_objJobLogger, v_objJobStatus, v_colCounters, v_objDataCache, v_objParams, objChildNode, xWriter, v_level, strNodeName, null);
        }

        private void fInsertErrorComment(Exception Err_Renamed, XmlNode v_objSchemaNode, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, string strNodeName, XmlWriter xWriter)
        {
            IsDnaJobManagement.IJobStatus objJobMgr = null;

            try
            {
                string strComment = String.Empty;

                if (strNodeName == "")
                {
                    return;
                }

                strNodeName = modXMLFunctions.FGetNodeText(v_objSchemaNode, "@name", modXMLFunctions.FGetNodeText(v_objSchemaNode, "@type"));

                strComment = "*** ERROR **** Node: " + strNodeName + ", (" + Err_Renamed.Message + ")";

                // Also log the error in the job log
                fProgress(strComment, m_abort, v_objJobLogger);

                // Insert Error Comment on the same place as Element which caused the error.
                xWriter.WriteComment(strComment); //Avdhut Vaidya

                // Now set Job status to ERRORS so following steps can handle with this.
                objJobMgr = (IsDnaJobManagement.IJobStatus)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobManager"));
                objJobMgr.FSetStatus(m_lngRunID, "ERRORS");

            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
            finally
            {
                if (objJobMgr != null) ((IDisposable)objJobMgr).Dispose();
            }
        }

        private void fLogMessage(XmlNode objSchemaNode, XmlNamespaceManager objSchemaNS, IControlInfo objControlInfo, IJobLogger objJobLogger, DataRow drRstData, IParamSource objParams, int ilevel)
        {
            XmlNode objMsg = null;
            try
            {
                string strMsg = String.Empty;
                string strName = String.Empty;
                string strIndent = String.Empty;
                objMsg = objSchemaNode.SelectSingleNode("md:log-message", objSchemaNS);
                if (objMsg != null)
                {
                    strIndent = modXMLFunctions.FGetNodeText(objMsg, "@md:indent", "none", objSchemaNS);
                    switch (strIndent.ToLower().Trim())
                    {
                        case "auto":
                            strMsg = new string("-"[0], ilevel * 2);
                            break;
                        case "none":
                            strMsg = "";
                            break;
                        default:
                            double dbNumericTemp = 0;
                            if (Double.TryParse(strIndent, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out dbNumericTemp))
                            {
                                strMsg = new string("-"[0], Int32.Parse(strIndent));
                            }
                            break;
                    }

                    foreach (XmlNode objNode in objMsg.ChildNodes)
                    {
                        if (objNode.NodeType == XmlNodeType.Element)
                        {
                            if (objNode.Name == "md:param")
                            {
                                strName = modXMLFunctions.FGetNodeText(objNode, "@name");
                                if (FFieldExist(drRstData.Table.DataSet, strName))
                                {
                                    strMsg = strMsg + Convert.ToString(drRstData[strName]).Trim();
                                }
                                else if (Convert.ToString(objParams.GetParam(strName)) != "")
                                {
                                    strMsg = strMsg + Convert.ToString(objParams.GetParam(strName)).Trim();
                                }
                                else
                                {
                                    strMsg = strMsg + "[UNKNOWN PARAM:" + strName + "]";
                                }
                            }
                        }
                        else if (objNode.NodeType == XmlNodeType.Text)
                        {
                            strMsg = strMsg + objNode.Value;
                        }
                    }
                }
                if (strMsg != "")
                {
                    fProgress(strMsg, m_abort, objJobLogger);
                }

                objMsg = null;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private void fProcessCounters(ref XmlDocument objSchema, XmlNamespaceManager objSchemaNS, IControlInfo objControlInfo, IJobLogger objJobLogger, Dictionary<string, int> colCounters, XmlNode objParentNode, IParamSource objParams)
        {
            XmlNodeList objCounters = null;
            try
            {
                int lngCounterID = 0;
                int lngCounterValue = 0;
                string strScope = String.Empty;

                objCounters = objParentNode.SelectNodes("md:counter", objSchemaNS);
                foreach (XmlNode objCounter in objCounters)
                {
                    lngCounterID = Int32.Parse(modXMLFunctions.FGetNodeText(objCounter, "@id"));
                    strScope = modXMLFunctions.FGetNodeText(objCounter, "@scope").ToLower();
                    if (strScope == "" || strScope == Convert.ToString(objParams.GetParam("scope")).ToLower())
                    {
                        if (objCounter.SelectSingleNode("@value") == null)
                        {
                            fIncreaseCounter(ref objSchema, objSchemaNS, objControlInfo, objJobLogger, colCounters, lngCounterID);
                        }
                        else
                        {
                            lngCounterValue = Int32.Parse(modXMLFunctions.FGetNodeText(objCounter, "@value"));
                            fSetCounter(ref objSchema, objSchemaNS, objControlInfo, objJobLogger, colCounters, lngCounterID, lngCounterValue);
                        }
                    }
                }

                objCounters = null;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private void fIncreaseCounter(ref XmlDocument objSchema, XmlNamespaceManager objSchemaNS, IControlInfo objControlInfo, IJobLogger objJobLogger, Dictionary<string, int> colCounters, int lngCounterID)
        {
            try
            {
                string strType = String.Empty;

                strType = modXMLFunctions.FGetNodeText((XmlNode)objSchema.DocumentElement, "md:counterdef/md:counter[@id='" + lngCounterID.ToString() + "']/@type", objSchemaNS).ToLower();
                switch (strType)
                {
                    case "persistent":
                        fIncreaseCounter(lngCounterID, 1, objJobLogger);
                        break;
                    case "translucent":
                        colCounters["C" + lngCounterID.ToString()] = Convert.ToInt32(colCounters["C" + lngCounterID.ToString()]) + 1;
                        break;
                }
            }
            catch (Exception excep)
            {
                fProgress("Error: counter does not exist [id: " + lngCounterID.ToString() + "]", m_bAbort, objJobLogger);

                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private void fSetCounter(ref XmlDocument objSchema, XmlNamespaceManager objSchemaNS, IControlInfo objControlInfo, IJobLogger objJobLogger, Dictionary<string, int> colCounters, int iCounterID, int iValue)
        {
            string strType = modXMLFunctions.FGetNodeText((XmlNode)objSchema.DocumentElement, "md:counterdef/md:counter[@id='" + iCounterID.ToString() + "']/@type", objSchemaNS).ToLower();
            switch (strType)
            {
                case "persistent":
                    fSetCounter(iCounterID, iValue, objJobLogger);
                    break;
                case "translucent":
                    colCounters["C" + iCounterID.ToString()] = iValue;
                    break;
                default:
                    fProgress("Warning: counter type [" + strType + "] for counter [" + iCounterID.ToString() + "] is not valid !", m_bAbort, objJobLogger);
                    break;
            }
        }

        private void frsGetCacheData(XmlNode objElemDef, XmlNamespaceManager objSchemaNS, IControlInfo objControlInfo, IJobLogger objJobLogger, Dictionary<string, DataView> objDataCache, IParamSource objParams)
        {
            string strName = String.Empty;
            try
            {
                XmlNode objComponentNode = null;
                DataSet rsData = null;
                DataView dvData = null;

                foreach (XmlNode objCacheNode in objElemDef.SelectNodes("md:cached-data", objSchemaNS))
                {
                    strName = modXMLFunctions.FGetNodeText(objCacheNode, "@name");

                    if (strName != "")
                    {
                        objComponentNode = objCacheNode.SelectSingleNode("md:component", objSchemaNS);
                        if (objComponentNode != null)
                        {
                            if (objDataCache.ContainsKey(strName) == true)
                            {
                                objDataCache.Remove(strName);
                            }
                            rsData = fGetNodeDataFromComponent(objComponentNode, objSchemaNS, objControlInfo, objJobLogger, objParams);
                            dvData = new DataView(rsData.Tables[0]);
                            objDataCache.Add(strName, dvData);
                        }
                    }
                }

            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private DataSet fGetNodeDataFromComponent(XmlNode v_objComponentNode, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, PrismaGeneral.IParamSource v_objParams)
        {
            DataSet rsResultData = null;
            ICommonRead objObject = null;

            try
            {
                string strProgID = String.Empty;
                string strMethod = String.Empty;

                // If a component element is present, read the progid and create the component
                // The component must implement the ICommonRead interface. When no method attribute
                // is specified, the ReadFilter method is used
                strProgID = modXMLFunctions.FGetNodeText(v_objComponentNode, "@progid");
                if (strProgID != "")
                {
                    foreach (XmlNode objParam in v_objComponentNode.SelectNodes("md:param", v_objSchemaNS))
                    {
                        v_objParams.SetParam(modXMLFunctions.FGetNodeText(objParam, "@name"), objParam.InnerText);
                    }

                    if (strProgID == Constants.DEFAULT_LOCAL_QUERY_LOOKUP_COMPONENT)
                    {
                        objObject = (ICommonRead)new LOR2Queries();
                    }
                    else
                    {
                        objObject = (ICommonRead)Activator.CreateInstance(Type.GetTypeFromProgID(strProgID, true));
                    }
                    strMethod = modXMLFunctions.FGetNodeText(v_objComponentNode, "@method", "ReadFilter");
                    switch (strMethod.ToLower())
                    {
                        case "readone":
                            rsResultData = objObject.ReadOne(v_objParams);
                            break;
                        case "readall":
                            rsResultData = objObject.ReadAll(v_objParams);
                            break;
                        default:
                            rsResultData = objObject.ReadFilter(v_objParams);
                            break;
                    }
                }
                else
                {
                    fProgress("Warning: No ProgID specified for the following component: " + modXMLFunctions.FGetElementPath(v_objComponentNode), m_bAbort, v_objJobLogger);
                }



                return rsResultData;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
            finally
            {
                if (rsResultData != null)
                {
                    rsResultData.Dispose();
                }
                if (objObject != null) ((IDisposable)objObject).Dispose();
            }
        }

        private DataSet fGetNodeData(XmlNode v_objNode, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, Dictionary<string, DataView> v_objDataCache, PrismaGeneral.IParamSource v_objParams, bool v_bTableData)
        {
            DataSet result = new DataSet();
            XmlNode objComponentNode = null;
            List<string> colFields = null;
            XmlNode objElemDef = null;
            DataSet rsCachedData = null;
            DataView dvResult = null;
            DataRow drResult = null;
            try
            {
                bool bFound = false;
                string strComponentNode = String.Empty;
                string strName = String.Empty;
                List<Key> arrKeyFields = new List<Key>();
                Key typKeyField = Key.CreateInstance();
                int iTeller = 0;
                StringBuilder strFilter = new StringBuilder();
                strFilter.Append(String.Empty);

                // One of the following nodes can exist in one <element><md:datasource> node:
                //   - md:component
                //   - md:use-cache
                //   - md:aggregate_cache
                //   - md:table/md:component
                //   - md:table/md:use-cache

                strComponentNode = "md:datasource";
                if (v_bTableData)
                {
                    strComponentNode = strComponentNode + "/md:table";
                }

                //Search for md:component
                bFound = modXMLFunctions.FSelectNode(v_objNode, strComponentNode + "/md:component", ref objComponentNode, v_objSchemaNS);

                //Now get the data
                if (bFound)
                {
                    //Get the data from the component
                    result = fGetNodeDataFromComponent(objComponentNode, v_objSchemaNS, v_objControlInfo, v_objJobLogger, v_objParams);
                }
                else
                {
                    //See if we have cached data
                    bFound = modXMLFunctions.FSelectNode(v_objNode, strComponentNode + "/md:use-cache", ref objComponentNode, v_objSchemaNS);

                    if (bFound)
                    {
                        // Use cached data
                        result = frsGetCachedData(objComponentNode, v_objSchemaNS, v_objDataCache, v_objParams);
                    }
                }

                if (!bFound)
                {
                    //See if we can aggregate cached data.
                    bFound = modXMLFunctions.FSelectNode(v_objNode, strComponentNode + "/md:aggregate_cache", ref objComponentNode, v_objSchemaNS);

                    if (bFound)
                    {
                        colFields = new List<string>();

                        iTeller = 1;

                        // Create empty record set with the correct fields.
                        objElemDef = modXMLFunctions.FGetNodeDef(v_objNode);

                        // Store all fields needed for the XML extraction in a dictionary so they can be accessed with high performance.
                        foreach (XmlNode objField in v_objNode.SelectNodes("md:datasource/md:attributemap/md:attribute", v_objSchemaNS))
                        {
                            colFields.Add(modXMLFunctions.FGetNodeText(objField, "@datafield"));
                        }

                        // Store all key fields in a array so they can be accessed with high performance. The
                        // key fields are used to check if a record is already inserted in the return DataSet. If so
                        // the record is not inserted again. The parts needed to filter the already stored records are already
                        // build here so it doesn't have to  be done per record.

                        foreach (XmlNode objKeyField in objComponentNode.SelectNodes("md:unique-key/md:field", v_objSchemaNS))
                        {
                            typKeyField.Name = modXMLFunctions.FGetNodeText(objKeyField, "@name");
                            typKeyField.Type = modXMLFunctions.FGetNodeText(objKeyField, "@type");

                            // Create the filter parts for this key. Depending the type of the key quote's are needed around the values.
                            // The values are later filled.
                            if (typKeyField.Type.ToLower().Trim() == "numeric")
                            {
                                typKeyField.FilterBeforePart = typKeyField.Name + " = ";
                                typKeyField.FilterAfterPart = "";
                            }
                            else
                            {
                                typKeyField.FilterBeforePart = typKeyField.Name + " = '";
                                typKeyField.FilterAfterPart = "'";
                            }

                            arrKeyFields.Add(typKeyField);

                            // If the key field is not part of the XML fields then store it in the fields dictionary.
                            if (colFields.Contains(typKeyField.Name) == false)
                            {
                                colFields.Add(typKeyField.Name);
                            }
                        }

                        foreach (XmlNode objCacheDataNode in objComponentNode.SelectNodes("md:use-cache/md:cache", v_objSchemaNS))
                        {
                            strName = modXMLFunctions.FGetNodeText(objCacheDataNode, "@name");

                            // Retrieve the cached data. If the cache doesn't exist in the cache then Nothing is returned.
                            rsCachedData = frsGetCachedData(objCacheDataNode, v_objSchemaNS, v_objDataCache, v_objParams);

                            if (rsCachedData != null)
                            {
                                if (rsCachedData.Tables.Count != 0)
                                {
                                    //If this if the first cache with a DataSet then create the return DataSet with only the needed
                                    // fields (data attributes and cache aggregate keys).
                                    //<START>ADDED BY Avdhut Vaidya
                                    bool bTmpFlag;
                                    bTmpFlag = false;
                                    if (result != null)
                                    {
                                        if (result.Tables.Count != 0)
                                        {
                                            bTmpFlag = false;
                                        }
                                        else
                                        {
                                            bTmpFlag = true;
                                        }
                                    }
                                    //<END>ADDED BY Avdhut Vaidya
                                    //if (result == null) Avdhut Vaidya
                                    if (bTmpFlag == true)  //Avdhut Vaidya
                                    {
                                        result = new DataSet();
                                        //result = objRsUtil.CopyStructure(rsCachedData); Avdhut Vaidya;
                                        result = rsCachedData.Clone(); //Avdhut Vaidya
                                        // Now delete fields which are not needed.
                                        for (int iDataColCntr = result.Tables[0].Columns.Count - 1; iDataColCntr >= 0; iDataColCntr--)
                                        {
                                            if (colFields.Contains(result.Tables[0].Columns[iDataColCntr].ColumnName) == false)
                                            {
                                                result.Tables[0].Columns.Remove(result.Tables[0].Columns[iDataColCntr]);
                                            }
                                        }
                                        //result.Open(Type.Missing, Type.Missing, ADODB.CursorTypeEnum.adOpenUnspecified, ADODB.LockTypeEnum.adLockUnspecified, -1); Avdhut Vaidya
                                    }

                                    //<START>COMMENTED BY Avdhut Vaidya
                                    //if (! (rsCachedData.Tables[0].Rows.Count >0 && rsCachedData.Tables[0].Rows.Count ==0))
                                    //{
                                    //	rsCachedData.MoveFirst();
                                    //}
                                    //<END>COMMENTED BY Avdhut Vaidya

                                    //while(! rsCachedData.Tables[0].Rows.Count >0) Avdhut Vaidya
                                    foreach (DataRow drCachedData in rsCachedData.Tables[0].Rows)
                                    {
                                        // Create the filter to check if the record is already stored in the to be returned DataSet.
                                        // The check is performed on the key fields given in the <md:unique-key> node.
                                        strFilter = new StringBuilder("");
                                        //for (intTeller = 1; intTeller <= arrKeyFields.GetUpperBound(0); intTeller++) Avdhut Vaidya
                                        foreach (Key arrKeyField in arrKeyFields)
                                        {
                                            if (strFilter.ToString() != "")
                                            {
                                                strFilter.Append(" AND ");
                                            }

                                            strFilter.Append(arrKeyField.FilterBeforePart +
                                                            drCachedData[arrKeyField.Name].ToString() +
                                                            arrKeyField.FilterAfterPart);
                                        }

                                        #region COMMENTED BY Avdhut Vaidya
                                        /*
                                        <START>COMMENTED BY Avdhut Vaidya
										result.Filter = strFilter.ToString();
										
										// If the record doesn't exist add a record and fill the neccessary fields.
										if (result.Tables[0].Rows.Count >0 && result.Tables[0].Rows.Count ==0)
										{
											result.Filter = ADODB.FilterGroupEnum.adFilterNone;
											result.AddNew(Type.Missing, Type.Missing);
											foreach (string strFieldName in colFields.Items())
											{
												result.Tables[0].Columns[strFieldName] = rsCachedData.Tables[0].Columns[strFieldName];
											}
											result.Update(Type.Missing, Type.Missing);
										}
										
										rsCachedData.MoveNext();
                                        <END>COMMENTED BY Avdhut Vaidya
                                        */
                                        #endregion

                                        //<START>Added by Avdhut Vaidya
                                        dvResult = new DataView(result.Tables[0], strFilter.ToString(), "", DataViewRowState.CurrentRows);
                                        // If the record doesn't exist add a record and fill the neccessary fields.
                                        if (dvResult.Count == 0)
                                        {
                                            drResult = result.Tables[0].NewRow();
                                            foreach (string strFieldName in colFields)
                                            {
                                                drResult[strFieldName] = drCachedData[strFieldName].ToString();
                                            }
                                            result.Tables[0].Rows.Add(drResult);
                                        }
                                        //<END>Added by Avdhut Vaidya
                                    }

                                    //result.Filter = ADODB.FilterGroupEnum.adFilterNone;
                                } //Table count != 0
                            }
                        }

                    }
                }

                objComponentNode = null;
                colFields = null;
                objElemDef = null;
                //<START>Added by Avdhut Vaidya
                drResult = null;
                dvResult = null;
                //<END>Added by Avdhut Vaidya


                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;

            }
            finally
            {
                if (rsCachedData != null)
                {
                    rsCachedData.Dispose();
                }
            }
        }

        private DataSet fGetNodeData(XmlNode v_objNode, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, Dictionary<string, DataView> v_objDataCache, PrismaGeneral.IParamSource v_objParams)
        {
            return fGetNodeData(v_objNode, v_objSchemaNS, v_objControlInfo, v_objJobLogger, v_objDataCache, v_objParams, false);
        }

        private void fSetParams(DataRow drRstData, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, XmlNode v_objSchemaNode, PrismaGeneral.IParamSource v_objParams)
        {
            XmlNodeList objKeys = null;
            try
            {
                string strAttrName = String.Empty;

                if (v_objSchemaNode.Name == "element")
                {
                    // Store all attributes marked as 'save="yes"' in paramsource
                    objKeys = v_objSchemaNode.SelectNodes("md:datasource/md:attributemap/md:attribute[@save='yes']", v_objSchemaNS);
                    if (objKeys != null)
                    {
                        foreach (XmlNode objKey in objKeys)
                        {
                            strAttrName = modXMLFunctions.FGetNodeText(objKey, "@datafield");
                            if (FFieldExist(drRstData.Table.DataSet, strAttrName)) //Avdhut Vaidya
                            {
                                v_objParams.SetParam(strAttrName, drRstData[strAttrName].ToString() + "");
                            }
                            else
                            {
                                v_objParams.SetParam(strAttrName, "");
                            }
                        }
                    }
                    // Store all params which have to be initialized at this point
                    objKeys = v_objSchemaNode.SelectNodes("md:datasource/md:attributemap/md:param", v_objSchemaNS);
                    if (objKeys != null)
                    {
                        foreach (XmlNode objKey in objKeys)
                        {
                            strAttrName = modXMLFunctions.FGetNodeText(objKey, "@name");
                            if (strAttrName != "")
                            {
                                v_objParams.SetParam(strAttrName, objKey.InnerText);
                            }
                            else
                            {
                                fProgress("Warning: No name attribute found for param [" + modXMLFunctions.FGetElementPath(objKey) + "].", m_bAbort, v_objJobLogger);
                            }
                        }
                    }
                }


                objKeys = null;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        private XmlNode fCreateNodeFromData(DataRow drRstData, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, Dictionary<string, int> v_colCounters
            , XmlNode v_objSchemaNode, PrismaGeneral.IParamSource v_objParams)
        {
            XmlNode result;
            XmlNode objNewDataNode = null;
            XmlAttribute objDataAttr = null;
            XmlNode objElemDef = null;
            XmlNode objAttrMap = null;
            try
            {
                string strAttrName = String.Empty;
                string strDatafield = String.Empty;
                bool bAbort = false;
                string strElemName = String.Empty;

                XmlDocument objDOM = new XmlDocument();

                // First get the definition for this element
                objElemDef = modXMLFunctions.FGetNodeDef(v_objSchemaNode);
                strElemName = modXMLFunctions.FGetNodeText(objElemDef, "@name");
                // If there is any data at all then process it
                //if (v_rstData != null) Avdhut Vaidya
                if (drRstData != null) //Avdhut Vaidya
                {
                    //if (! v_rstData.Tables[0].Rows.Count >0)
                    // Now create the new element
                    //COMMENTED By Avdhut Vaidya
                    //objNewDataNode = (XmlNode) m_objXMLDoc.CreateElement(modXMLFunctions.fGetNodeText(objElemDef, "@name"));
                    objNewDataNode = objDOM.CreateElement(modXMLFunctions.FGetNodeText(objElemDef, "@name")); //Avdhut Vaidya
                    // Retrieve the attributemap and if there is an attributemap lets make
                    // some attributes
                    objAttrMap = v_objSchemaNode.SelectSingleNode("md:datasource/md:attributemap", v_objSchemaNS);
                    if (objAttrMap != null)
                    {
                        // Now create all attributes available in the datasource
                        foreach (XmlNode objSchemaAttr in objElemDef.SelectNodes("attribute"))
                        {
                            // Get the attribute name from the attribute definition
                            strAttrName = modXMLFunctions.FGetNodeText(objSchemaAttr, "@type");
                            // Now create the attribute and check the type of the attribute
                            // so the right value can be retrieved.
                            // if the datafield attribute is present, the value will be retrieved from the
                            // DataSet or the parametersource
                            // if the counterid attribute is present, the value will be retrieved from a
                            // counter
                            // if none of these attributes are present, the value will be empty and the attribute
                            // will not be added to the element

                            objDataAttr = objDOM.CreateAttribute(strAttrName); //Avdhut Vaidya
                            eAttrType switchVar = fGetAttrType(objAttrMap, v_objSchemaNS, strAttrName);
                            if (switchVar == eAttrType.atDataField)
                            {
                                objDataAttr.Value = fGetValueFromRSOrPS(fGetAttrFromMap(objAttrMap, v_objSchemaNS, objDataAttr.Name), drRstData, v_objParams).Trim(); //Avdhut Vaidya
                            }
                            else if (switchVar == eAttrType.atCounter)
                            {
                                objDataAttr.Value = fGetCounterValue(objAttrMap, v_objSchemaNS, v_colCounters, strAttrName).ToString().Trim(); //Avdhut Vaidya
                            }
                            else
                            {
                                objDataAttr.Value = "";

                            }
                            // If no value then discard the attribute to the element
                            //if (objDataAttr.Value != "") Avdhut Vaidya

                            if (objDataAttr.Value != "") // || modXMLFunctions.FGetNodeText(objElemDef, "//AttributeType[@name='file-name']/@required", "no") == "yes")
                            {
                                objNewDataNode.Attributes.Append(objDataAttr); //Avdhut Vaidya
                            }

                            objDataAttr = null;

                        }
                        // Check if there is a nodetext in the attributemap
                        // if present retrieve the value and use this as the element text
                        eAttrType switchVar_2 = fGetAttrType(objAttrMap, v_objSchemaNS, "", true);
                        if (switchVar_2 == eAttrType.atDataField)
                        {
                            objNewDataNode.InnerText = fGetValueFromRSOrPS(fGetAttrFromMap(objAttrMap, v_objSchemaNS, "", true), drRstData, v_objParams).Trim(); //Avdhut Vaidya
                        }
                        else if (switchVar_2 == eAttrType.atCounter)
                        {
                            objNewDataNode.InnerText = fGetCounterValue(objAttrMap, v_objSchemaNS, v_colCounters, "", true).ToString().Trim(); //Avdhut Vaidya
                        }
                    }
                    // If the new element has no child nodes (text node in this case) and no attributes
                    // then do not add the new node
                    //if ((objNewDataNode.ChildNodes.length != 0) || (objNewDataNode.attributes.length != 0) || (modXMLFunctions.fGetNodeText(v_objSchemaNode, "@minOccurs", "0") != "0")) Avdhut Vaidya
                    if ((objNewDataNode.ChildNodes.Count != 0) || (objNewDataNode.Attributes.Count != 0) || (modXMLFunctions.FGetNodeText(v_objSchemaNode, "@minOccurs", "0") != "0")) //Avdhut Vaidya
                    {
                        //v_objParentDataNode.appendChild(objNewDataNode); Avdhut Vaidya
                    }
                }
                else
                {
                    // If there is no DataSet, try to find a datafield element
                    // if present then use this datafield to retrieve the value for the element text
                    // from the paramsource
                    //objNewDataNode = (XmlNode) m_objXMLDoc.createElement(modXMLFunctions.fGetNodeText(objElemDef, "@name"));
                    objNewDataNode = objDOM.CreateElement(modXMLFunctions.FGetNodeText(objElemDef, "@name"));
                    strDatafield = modXMLFunctions.FGetNodeText(v_objSchemaNode, "md:datafield", v_objSchemaNS);
                    if (strDatafield != "")
                    {
                        if (fGetParam(v_objParams, strDatafield) != "")
                        {
                            objNewDataNode.InnerText = fGetParam(v_objParams, strDatafield).Trim(); //Avdhut Vaidya
                        }
                    }

                    #region The following code is similar to the code above
                    objAttrMap = v_objSchemaNode.SelectSingleNode("md:attributemap", v_objSchemaNS);
                    if (objAttrMap != null)
                    {
                        foreach (XmlNode objSchemaAttr in objElemDef.SelectNodes("attribute"))
                        {
                            strAttrName = modXMLFunctions.FGetNodeText(objSchemaAttr, "@type");

                            objDataAttr = objDOM.CreateAttribute(strAttrName); //Avdhut Vaidya
                            eAttrType switchVar = fGetAttrType(objAttrMap, v_objSchemaNS, strAttrName);
                            if (switchVar == eAttrType.atDataField)
                            {
                                objDataAttr.Value = fGetValueFromRSOrPS(fGetAttrFromMap(objAttrMap, v_objSchemaNS, objDataAttr.Name), drRstData, v_objParams).Trim(); //Avdhut Vaidya
                            }
                            else if (switchVar == eAttrType.atCounter)
                            {
                                objDataAttr.Value = fGetCounterValue(objAttrMap, v_objSchemaNS, v_colCounters, strAttrName).ToString().Trim(); //Avdhut Vaidya
                            }
                            else
                            {
                                objDataAttr.Value = "";
                            }

                            if (objDataAttr.Value != "")
                            {
                                objNewDataNode.Attributes.Append(objDataAttr);
                            }

                            objDataAttr = null;
                        }
                    }
                    #endregion //The following code is similar to the code above

                    #region Avdhut Vaidya : MIGRATION NOTE : v_objParentDataNode will no longer be used
                    //// Now add the new node to his parent
                    //// If this new element is the parent then add it to the document instead of
                    //// the parent node
                    //if (v_objParentDataNode == null)
                    //{
                    //	// the root node must allways be added
                    //	m_objXMLDoc.appendChild(objNewDataNode);
                    //} else
                    //{
                    //	// Now check if the node must be added, if the node has no attributes and no
                    //	// childs (text nodes) and according to the element definition has no child elements
                    //	// then discard this element
                    //	if ((objNewDataNode.childNodes.length != 0) || (objNewDataNode.attributes.length != 0) || (objElemDef.SelectNodes("element").length != 0) || (modXMLFunctions.fGetNodeText(v_objSchemaNode, "@minOccurs", "0") != "0"))
                    //	{
                    //		// If the element contains a insert-position attribute, then try to
                    //		// to add the element at the position specified.
                    //		// only  'head' is supported for now.
                    //		if (modXMLFunctions.fGetNodeText(v_objSchemaNode, "@md:insert-position").ToLower() == "head")
                    //		{
                    //			v_objParentDataNode.insertBefore(objNewDataNode, v_objParentDataNode.firstChild);
                    //		} else
                    //		{
                    //			v_objParentDataNode.appendChild(objNewDataNode);
                    //		}
                    //	}
                    //}
                    #endregion
                }

                //If the element definition contains a isxml='yes' attribute,
                //the convert the element text to xml so it becomes part of the structure
                // if the element text is not valid then stop the extraction
                if (fIsXML(objElemDef, v_objSchemaNS))
                {
                    if (!fTextToXML(objNewDataNode))
                    {
                        //objNewDataNode.Value = ""; Avadhut Vaidya
                        fProgress("The following Text is not valid xml: " + objNewDataNode.OuterXml, bAbort, v_objJobLogger);
                        throw new Exception((0 + 9101).ToString() + ", ISXML, " + "The following Text is not valid xml: " + objNewDataNode.OuterXml);
                    }
                }

                result = objNewDataNode;
                objNewDataNode = null;
                objDataAttr = null;
                objElemDef = null;
                objAttrMap = null;
                objDOM = null; //Added by Avdhut Vaidya


                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        // Siddharth Naik, 06/10/2009, Fixing FxCop Issues.
        // Below modification XmlNode to IXPathNavigable
        public string fGetAttrFromMap(/*XmlNode*/ System.Xml.XPath.IXPathNavigable v_objAttrMap, XmlNamespaceManager v_objSchemaNS, string v_strAttrName, bool v_bElement)
        {
            string result = String.Empty;
            try
            {
                XmlNode objAttr = null;
                string strResult = String.Empty;

                strResult = v_strAttrName;
                if (v_objAttrMap != null && v_objAttrMap is XmlNode)
                {
                    if (v_bElement)
                    {
                        objAttr = ((XmlNode)v_objAttrMap).SelectSingleNode("md:nodetext", v_objSchemaNS);
                    }
                    else
                    {
                        objAttr = ((XmlNode)v_objAttrMap).SelectSingleNode("md:attribute[@name = '" + v_strAttrName + "']", v_objSchemaNS);
                    }
                    if (objAttr != null)
                    {
                        strResult = modXMLFunctions.FGetNodeText(objAttr, "@datafield");
                    }
                }
                result = strResult;
                objAttr = null;

                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        public string fGetAttrFromMap(/*XmlNode*/ System.Xml.XPath.IXPathNavigable v_objAttrMap, XmlNamespaceManager v_objSchemaNS, string v_strAttrName)
        {
            return fGetAttrFromMap(v_objAttrMap, v_objSchemaNS, v_strAttrName, false);
        }

        private eAttrType fGetAttrType(XmlNode v_objAttrMap, XmlNamespaceManager v_objSchemaNS, string v_strAttrName, bool v_bElement)
        {
            eAttrType eResult = (eAttrType)0;

            if (v_objAttrMap == null)
            {
                return eAttrType.atUnknown;
            }

            if (v_bElement)
            {
                if (v_objAttrMap.SelectSingleNode("md:nodetext", v_objSchemaNS) == null)
                {
                    eResult = eAttrType.atUnknown;
                }
                else if (v_objAttrMap.SelectSingleNode("md:nodetext[@datafield]", v_objSchemaNS) != null)
                {
                    eResult = eAttrType.atDataField;
                }
                else if (v_objAttrMap.SelectSingleNode("md:nodetext[@counterid]", v_objSchemaNS) != null)
                {
                    eResult = eAttrType.atCounter;
                }
            }
            else
            {
                if (v_objAttrMap.SelectSingleNode("md:attribute[@name='" + v_strAttrName + "']", v_objSchemaNS) == null)
                {
                    eResult = eAttrType.atUnknown;
                }
                else if (v_objAttrMap.SelectSingleNode("md:attribute[@name='" + v_strAttrName + "' and @datafield]", v_objSchemaNS) == null)
                {
                    eResult = eAttrType.atCounter;
                }
                else
                {
                    eResult = eAttrType.atDataField;
                }
            }
            return eResult;
        }

        private eAttrType fGetAttrType(XmlNode v_objAttrMap, XmlNamespaceManager v_objSchemaNS, string v_strAttrName)
        {
            return fGetAttrType(v_objAttrMap, v_objSchemaNS, v_strAttrName, false);
        }

        private string fGetValueFromRSOrPS(string v_strName, DataRow v_objDatarow, PrismaGeneral.IParamSource v_objParams) //Avdhut Vaidya
        {
            string result = String.Empty;
            try
            {
                string strValue = String.Empty;
                bool bFound = false;
                if (v_objDatarow != null)
                {
                    bFound = false;
                    strValue = "";
                    foreach (DataColumn objField in v_objDatarow.Table.Columns)
                    {
                        if (v_strName == objField.ColumnName) //Avdhut Vaidya
                        {
                            strValue = v_objDatarow[objField].ToString().Trim(); //Avdhut Vaidya
                            bFound = true;
                            break;
                        }
                    }
                }
                if (!bFound)
                {
                    strValue = Convert.ToString(v_objParams.GetParam(v_strName));
                }

                result = strValue;

                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        private int fGetCounterValue(XmlNode v_objAttrMap, XmlNamespaceManager v_objSchemaNS, Dictionary<string, int> v_colCounters, string v_strAttrName, bool v_bElement)
        {
            int result = 0;
            int lngCounterID = 0;
            try
            {
                if (v_bElement)
                {
                    lngCounterID = Int32.Parse(modXMLFunctions.FGetNodeText(v_objAttrMap, "md:nodetext/@counterid", v_objSchemaNS));
                }
                else
                {
                    lngCounterID = Int32.Parse(modXMLFunctions.FGetNodeText(v_objAttrMap, "md:attribute[@name='" + v_strAttrName + "']/@counterid", v_objSchemaNS));
                }
                result = v_colCounters["C" + lngCounterID.ToString()]; //Avdhut Vaidya


                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        private int fGetCounterValue(XmlNode v_objAttrMap, XmlNamespaceManager v_objSchemaNS, Dictionary<string, int> v_colCounters, string v_strAttrName)
        {
            return fGetCounterValue(v_objAttrMap, v_objSchemaNS, v_colCounters, v_strAttrName, false);
        }

        //========================================================================
        //= Function Name    : fCreateTableFromData
        //= Description      : <fdesc>
        //= Creation Date    : 10-04-2000
        //= Author           : MarkR
        //========================================================================
        //= Input parameters
        //= 1.           : v_rstData (DataSet)
        //= description  : <paramdesc>
        //= 2.           : v_objSchemaNode (IXMLDOMNode)
        //= description  : <paramdesc>
        //= 3.           : v_objParentDataNode (IXMLDOMNode)
        //= description  : <paramdesc>
        //= 4.           : v_objParams (PrismaGeneral.IParamSource)
        //= description  : <paramdesc>
        //========================================================================
        //= Pre conditions
        //= 1.       : <precondition>
        //========================================================================
        //= Post conditions
        //= 1.       : <postcondition>
        //========================================================================
        //= Notes   :
        //= 1.      : All descisions made during coding the application are placed
        //=           at the top of the file. This so every body can read it
        //=           without digging trough the code
        //========================================================================
        //= History
        //=
        //= Version  Date        Author      Notes
        //= 1        10-04-2000  MarkR   First creation
        //========================================================================
        private bool fCreateTableFromData(ref XmlDocument v_objSchema, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, Dictionary<string, int> v_colCounters, Dictionary<string, DataView> v_objDataCache
            , DataRow drRsData, XmlNode v_objSchemaNode, XmlWriter objXMLWriter, PrismaGeneral.IParamSource v_objParams)
        {
            XmlNode objTableNode = null;
            XmlNode objElemDef = null;
            XmlNode objNode = null;
            XmlNode objRow = null;
            XmlNode objHead = null;
            DataSet rsTableData = null;
            //XmlNode objColSpan = null; COMMENTED By Avdhut Vaidya
            XmlAttribute objColSpan = null; //Added by Avdhut Vaidya
            bool result = false; //Avdhut Vaidya
            //The result variable indicates whethere anything was written to the objXMLWriter object.
            try
            {
                string strHeaderElem = String.Empty;
                string strRowElem = String.Empty;
                string strColElem = String.Empty;
                XmlNode objAttrMap = null;
                XmlNode objRowDef = null;
                XmlAttribute objNewAttr = null;
                XmlNode objTableRow = null;
                bool bIsXML = false;
                int lRowCount = 0;
                int lVisColCount = 0;
                int lColSpan = 0;
                string strColspanAttr = String.Empty;

                //<START>Added by Avdhut Vaidya
                DataRow[] drTableDataSubSet;
                XmlDocument objDOM;
                //<END>Added by Avdhut Vaidya

                //<START>Avdhut Vaidya : MIGRATION
                objTableNode = fCreateNodeFromData(drRsData, v_objSchemaNS, v_objControlInfo, v_objJobLogger, v_colCounters, v_objSchemaNode, v_objParams);
                objDOM = objTableNode.OwnerDocument;
                //<END>Avdhut Vaidya : MIGRATION

                fSetParams(drRsData, v_objSchemaNS, v_objControlInfo, v_objJobLogger, v_objSchemaNode, v_objParams);

                rsTableData = fGetNodeData(v_objSchemaNode, v_objSchemaNS, v_objControlInfo, v_objJobLogger, v_objDataCache, v_objParams, true);

                if (rsTableData != null) //CONVERSTION PENDING : Also check if Tables.count > 0
                {
                    strHeaderElem = modXMLFunctions.FGetNodeText(v_objSchemaNode, "md:datasource/md:table/md:thead/@tagname", v_objSchemaNS);
                    strRowElem = modXMLFunctions.FGetNodeText(v_objSchemaNode, "md:datasource/md:table/md:trow/@tagname", v_objSchemaNS);
                    strColElem = modXMLFunctions.FGetNodeText(v_objSchemaNode, "md:datasource/md:table/md:tcol/@tagname", v_objSchemaNS);
                    strColspanAttr = modXMLFunctions.FGetNodeText(v_objSchemaNode, "md:datasource/md:table/md:tcol/@colspan-attribute", v_objSchemaNS);

                    objAttrMap = v_objSchemaNode.SelectSingleNode("md:datasource/md:table/md:trow/md:attributemap", v_objSchemaNS);
                    objRowDef = v_objSchema.DocumentElement.SelectSingleNode("ElementType[@name='" + strRowElem + "']", v_objSchemaNS);
                    objTableRow = v_objSchemaNode.SelectSingleNode("md:datasource/md:table/md:trow", v_objSchemaNS);

                    objElemDef = modXMLFunctions.FGetNodeDef(v_objSchemaNode);


                    #region  //Add header rows
                    //UPGRADE_WARNING: (1037) Couldn't resolve default property of object rsTableData.Filter.
                    //<START>Modified by Avdhut
                    //NOT SUPPORTED : rsTableData.Filter = "IsHeader = True";
                    drTableDataSubSet = rsTableData.Tables[0].Select("IsHeader = True");
                    //if (! (rsTableData.Tables[0].Rows.Count ==0 && rsTableData.Tables[0].Rows.Count >0))
                    if (drTableDataSubSet.Length > 0)
                    //<END>Modified by Avdhut
                    {
                        //objHead = (XmlNode)m_objXMLDoc.CreateElement(strHeaderElem); COMMENTED BY Avdhut Vaidya
                        objHead = objDOM.CreateElement(strHeaderElem); //Avdhut Vaidya
                        objTableNode.AppendChild(objHead);
                        lRowCount = 0;
                        #region for loop - ROW Traversing
                        //while (! rsTableData.Tables[0].Rows.Count >0) COMMENTED BY Avdhut Vaidya
                        foreach (DataRow drTableData in drTableDataSubSet) //Added By Avdhut Vaidya
                        {
                            DataColumn objField;
                            lRowCount++;
                            bIsXML = (modXMLFunctions.FGetNodeText(v_objSchemaNode, "md:datasource/md:table/md:thead/md:trow[@index = " + lRowCount.ToString() + "]/@isxml", "no", v_objSchemaNS).ToLower() == "yes");

                            //objRow = (XmlNode) m_objXMLDoc.createElement(strRowElem); COMMENTED BY Avdhut Vaidya
                            objRow = objDOM.CreateElement(strRowElem); //Added by Avdhut Vaidya

                            objHead.AppendChild(objRow);
                            lColSpan = 0;
                            #region for loop - COLUMN TRAVERSING
                            for (int lngIndex = 0; lngIndex <= rsTableData.Tables[0].Columns.Count - 2; lngIndex++)
                            {
                                objField = rsTableData.Tables[0].Columns[lngIndex];
                                //if (objField.Name != "IsHeader" && ! objField.Name.StartsWith("$")) COMMENTED By Avdhut Vaidya
                                if (objField.ColumnName != "IsHeader" && !objField.ColumnName.StartsWith("$"))
                                {
                                    lVisColCount++;
                                    if (lColSpan == 0)
                                    {
                                        //<START>MODIFIED By Avdhut Vaidya
                                        //objNode = (XmlNode) m_objXMLDoc.createElement(strColElem);
                                        //objNode.Value = modXMLFunctions.fGetNodeText(v_objSchemaNode, "md:datasource/md:table/md:thead/md:tcol[@index='" + ((lngIndex + 1).ToString()) + "']/@caption", Convert.ToString(objField) + "").Trim();
                                        objNode = objDOM.CreateElement(strColElem);
                                        objNode.InnerText = modXMLFunctions.FGetNodeText(v_objSchemaNode, "md:datasource/md:table/md:thead/md:tcol[@index='" + ((lngIndex + 1).ToString()) + "']/@caption", drTableData[lngIndex].ToString() + "", v_objSchemaNS).Trim();
                                        //<END>MODIFIED By Avdhut Vaidya

                                        //if (bIsXML && objNode.Value != "") COMMENTED BY Avdhut Vaidya
                                        if (bIsXML && objNode.InnerText != "") //Avdhut Vaidya
                                        {
                                            if (!fTextToXML(objNode))
                                            {
                                                //objNode.Value = ""; Avdhut Vaidya
                                                //objNode.InnerText = ""; //Avdhut Vaidya
                                                //v_objControlInfo.FProgress("The following Text is not valid xml: " + objNode.InnerXml, ref m_bAbort);
                                                fProgress("The following Text is not valid xml: " + objNode.InnerXml, m_bAbort, v_objJobLogger);
                                                throw new Exception((0 + 9101).ToString() + ", ISXML, " + "The following Text is not valid xml: " + objNode.InnerXml);
                                            }
                                        }
                                        // Check if colspan is specified
                                        if (FFieldExist(rsTableData, "$colspan_" + lVisColCount.ToString()))
                                        {
                                            //lColSpan = Int32.Parse("0" + Convert.ToString(rsTableData.Tables[0].Columns["$colspan_" + lVisColCount.ToString()]));
                                            lColSpan = Int32.Parse("0" + drTableData["$colspan_" + lVisColCount.ToString()].ToString());
                                            if (lColSpan > 0)
                                            {
                                                //<START>Modified by Avdhut Vaidya
                                                //objColSpan = (XmlNode) m_objXMLDoc.createAttribute(strColspanAttr);
                                                //objColSpan.Value = lColSpan.ToString();
                                                //objNode.attributes.setNamedItem(objColSpan);
                                                objColSpan = objDOM.CreateAttribute(strColspanAttr);
                                                objColSpan.InnerText = lColSpan.ToString();
                                                objNode.Attributes.Append(objColSpan);
                                                //<END>Modified by Avdhut Vaidya
                                                objColSpan = null;
                                                lColSpan--;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        lColSpan--;
                                    }

                                    objRow.AppendChild(objNode);
                                }
                            } //END for loop - COLUMN Traversing 
                            #endregion
                            //rsTableData.MoveNext(); COMMENTED By Avdhut Vaidya
                        } //END for loop - ROW Traversing 
                        #endregion
                    } //END if (drTableDataSubSet.Length > 0)

                    #endregion

                    #region // Add body rows
                    //UPGRADE_WARNING: (1037) Couldn't resolve default property of object rsTableData.Filter.
                    //<START>Modified by Avdhut Vaidya
                    //rsTableData.Filter = "IsHeader = False";
                    //while (! rsTableData.Tables[0].Rows.Count >0)
                    //drTableDataSubSet = rsTableData.Tables[0].Select("IsHeader = False"); Avdhut Vaidya
                    drTableDataSubSet = rsTableData.Tables[0].Select("IsHeader = False OR IsHeader Is Null"); //Avdhut Vaidya
                    foreach (DataRow drTableRow in drTableDataSubSet)
                    {

                        //objRow = (XmlNode) m_objXMLDoc.createElement(strRowElem); COMMENTED By Avdhut Vaidya
                        objRow = objDOM.CreateElement(strRowElem); //Added by Avdhut Vaidya
                        if (objRowDef != null)
                        {
                            #region // Look for attributes
                            foreach (XmlNode objAttr in objRowDef.SelectNodes("attribute"))
                            {
                                //<START>Modified by Avdhut Vaidya
                                //objNewAttr = (XmlNode) m_objXMLDoc.CreateAttribute(modXMLFunctions.fGetNodeText(objAttr, "@type"));
                                objNewAttr = objDOM.CreateAttribute(modXMLFunctions.FGetNodeText(objAttr, "@type"));
                                //<END>Modified by Avdhut Vaidya
                                eAttrType switchVar = fGetAttrType(objAttrMap, v_objSchemaNS, objNewAttr.Name);
                                if (switchVar == eAttrType.atDataField)
                                {
                                    //objNewAttr.Value = fGetValueFromRSOrPS(fGetAttrFromMap(objAttrMap, objNewAttr.Name), rsTableData, v_objParams).Trim(); Avdhut Vaidya
                                    objNewAttr.InnerText = fGetValueFromRSOrPS(fGetAttrFromMap(objAttrMap, v_objSchemaNS, objNewAttr.Name), drTableRow, v_objParams).Trim(); //Avdhut Vaidya

                                }
                                else if (switchVar == eAttrType.atCounter)
                                {
                                    //objNewAttr.Value = fGetCounterValue(objAttrMap, objNewAttr.Name).ToString().Trim(); Avdhut Vaidya
                                    objNewAttr.InnerText = fGetCounterValue(objAttrMap, v_objSchemaNS, v_colCounters, objNewAttr.Name).ToString().Trim(); //Avdhut Vaidya
                                }
                                else
                                {
                                    //objNewAttr.Value = ""; //Avdhut Vaidya
                                    objNewAttr.InnerText = ""; //Avdhut Vaidya
                                }
                                //<START>Modified by Avdhut Vaidya
                                //if (objNewAttr.Value != "")
                                //{
                                //	objRow.attributes.setNamedItem(objNewAttr);
                                //}
                                if (objNewAttr.InnerText != "")
                                {
                                    objRow.Attributes.Append(objNewAttr);
                                }
                                //<END>Modified by Avdhut Vaidya
                            }
                            #endregion // Look for attributes
                        }

                        objTableNode.AppendChild(objRow);
                        foreach (DataColumn objField in rsTableData.Tables[0].Columns)
                        {
                            //objField = objField; COMMENTED BY Avdhut Vaidya
                            //if (objField.Name != "IsHeader" && ! objField.Name.StartsWith("$")) Avdhut Vaidya
                            if (objField.ColumnName != "IsHeader" && !objField.ColumnName.StartsWith("$")) //Avdhut Vaidya
                            {
                                //objNode = (XmlNode) m_objXMLDoc.CreateElement(strColElem); Avdhut Vaidya
                                objNode = objDOM.CreateElement(strColElem);
                                //UPGRADE_WARNING: (1049) Use of Null/IsNull() detected.
                                //if (!Convert.IsDBNull(objField))  //Avdhut Vaidya
                                if (drTableRow[objField] != DBNull.Value) //Avdhut Vaidya
                                {
                                    //objNode.Value = (Convert.ToString(objField) + "").Trim();
                                    objNode.InnerText = Convert.ToString(drTableRow[objField]).Trim();
                                }
                                objRow.AppendChild(objNode);
                            }
                        }

                        //rsTableData.MoveNext(); COMMENTED BY Avdhut Vaidya

                        fProcessCounters(ref v_objSchema, v_objSchemaNS, v_objControlInfo, v_objJobLogger, v_colCounters, objTableRow, v_objParams);
                    }
                    #endregion // Add body rows
                    //        Call v_objParentDataNode.appendChild(objTableNode)

                    //<START>Avdhut Vaidya : MIGRATION
                    //fProgress("<START>WRITING " + objTableNode.Name, m_abort, v_objJobLogger);
                    if (rsTableData.Tables[0].Rows.Count > 0)
                    {
                        writeFromXmlNodeToStream(objTableNode, objXMLWriter, false);
                        result = true;
                    }
                    //fProgress("<END>WRITING Product Specification Table", m_abort, v_objJobLogger);
                    //<END>Avdhut Vaidya : MIGRATION
                }
                else
                {
                    // Remove table node
                    //<START>Avdhut Vaidya : MIGRATION
                    //as the node is not being appended to v_objParentDataNode, there is no question of removing it
                    //v_objParentDataNode.RemoveChild(objTableNode);
                    //<END>Avdhut Vaidya : MIGRATION
                }

                objNode = null;
                objHead = null;
                objRow = null;
                objTableNode = null;
                objElemDef = null;
                objColSpan = null;
                objDOM = null;  //Added by Avdhut Vaidya

                return result; //Avdhut Vaidya
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
            finally
            {
                if (rsTableData != null)
                {
                    rsTableData.Dispose();
                }
            }
        }

        private bool FFieldExist(DataSet ds, string fieldName)
        {
            return ds.Tables[0].Columns.Contains(fieldName);
        }

        /// <summary>
        /// Reads from the XML Node and writes to the XML Text Writer object.
        /// RECURSIVE calls are used within
        /// </summary>
        /// <param name="objNode">The node object which will be written</param>
        /// <param name="objWriter">The stream to Write</param>
        /// <param name="writeRoot">if false, the root node will be skipped and the sub nodes (inner nodes) will be written to the stream</param>
        /// <param name="splBehaviour">
        /// bydefault -1 indicates no special behaviour
        /// if 1 is passed, EndElement will not be called for any node
        /// </param>
        //========================================================================
        //= Function Name    : writeFromXmlNodeToStream
        //= Description      : Writes from a given XML Node to a Stream
        //= Creation Date    : Feb-2009
        //= Author           : Avdhut Vaidya
        //========================================================================
        //= History
        //=
        //= Version  Date           Author          Notes
        //= 1        02-2009        Avdhut Vaidya   First creation
        //========================================================================
        private void writeFromXmlNodeToStream(XmlNode objNode, XmlWriter objWriter, bool writeEndElement, int splBehaviour)
        {
            //When a node is recieved, write the node first,
            //then the attributes of the node, after that
            //go for the sub nodes
            //When finally all the above things are written,
            //write the closing tag of the current node

            #region Write the main node and its attributes
            //MAIN ELEMENT
            objWriter.WriteStartElement(objNode.Prefix, objNode.Name, objNode.NamespaceURI);
            //ATTRIBUTES:
            foreach (XmlAttribute objAttr in objNode.Attributes)
            {
                objWriter.WriteAttributeString(objAttr.Prefix, objAttr.Name, objAttr.NamespaceURI, objAttr.Value);
            }
            #endregion

            #region Write the sub nodes
            foreach (XmlNode objSubNode in objNode.ChildNodes)
            {
                switch (objSubNode.NodeType)
                {
                    //case XmlNodeType.Attribute: //TAKEN CARE IN THE ELEMENT SECTION
                    //    break;
                    case XmlNodeType.CDATA:
                        objWriter.WriteCData(objSubNode.InnerText);
                        break;
                    case XmlNodeType.Comment:
                        objWriter.WriteComment(objSubNode.InnerText);
                        break;
                    //case XmlNodeType.Document:
                    //    break;
                    //case XmlNodeType.DocumentFragment:
                    //    break;
                    //case XmlNodeType.DocumentType:
                    //    break;

                    case XmlNodeType.Element:
                        //if it is of type element, then write the sub nodes of this element
                        //via call to this same function
                        writeFromXmlNodeToStream(objSubNode, objWriter, true, splBehaviour);
                        break;
                    case XmlNodeType.EndElement:
                        objWriter.WriteEndElement();
                        break;
                    case XmlNodeType.EndEntity:
                        objWriter.WriteEndElement();
                        break;
                    //case XmlNodeType.Entity:
                    //    break;
                    //case XmlNodeType.EntityReference:
                    //    break;
                    //case XmlNodeType.None:
                    //    break;
                    //case XmlNodeType.Notation:
                    //    break;
                    case XmlNodeType.ProcessingInstruction:
                        objWriter.WriteProcessingInstruction(objSubNode.Name, objSubNode.Value);
                        break;
                    case XmlNodeType.SignificantWhitespace:
                        objWriter.WriteWhitespace(objSubNode.Value);
                        break;
                    case XmlNodeType.Text:
                        objWriter.WriteString(objSubNode.Value);
                        break;
                    case XmlNodeType.Whitespace:
                        objWriter.WriteWhitespace(objSubNode.Value);
                        break;
                    //case XmlNodeType.XmlDeclaration:
                    //    break;
                    default:
                        break;
                }
            }
            #endregion

            //NOW THE END ELEMENT CAN BE WRITTEN
            if (writeEndElement == true)
            {
                if (splBehaviour == 1) //if spl behaviour is 1 then NO END ELEMENT
                { }
                else
                {
                    objWriter.WriteEndElement();
                }
            }
        }

        private void writeFromXmlNodeToStream(XmlNode objSubNode, XmlWriter objWriter, bool writeEndElement)
        {
            writeFromXmlNodeToStream(objSubNode, objWriter, writeEndElement, -1);
        }

        //========================================================================
        //= Function Name    : fIsTable
        //= Description      : <fdesc>
        //= Creation Date    : 10-04-2000
        //= Author           : MarkR
        //========================================================================
        //= Input parameters
        //= 1.           : v_objSchemaNode (IXMLDOMNode)
        //= description  : <paramdesc>
        //========================================================================
        //= Pre conditions
        //= 1.       : <precondition>
        //========================================================================
        //= Post conditions
        //= 1.       : <postcondition>
        //========================================================================
        //= Notes   :
        //= 1.      : All descisions made during coding the application are placed
        //=           at the top of the file. This so every body can read it
        //=           without digging trough the code
        //========================================================================
        //= History
        //=
        //= Version  Date        Author      Notes
        //= 1        10-04-2000  MarkR   First creation
        //========================================================================
        private bool fIsTable(XmlNode v_objSchemaNode, XmlNamespaceManager v_objSchemaNS)
        {
            bool result = false;
            try
            {
                result = v_objSchemaNode.SelectSingleNode("md:datasource/md:table", v_objSchemaNS) != null;

                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        //========================================================================
        //= Function Name    : fGetParam
        //= Description      : <fdesc>
        //= Creation Date    : 10-04-2000
        //= Author           : MarkR
        //========================================================================
        //= Input parameters
        //= 1.           : v_objParams (PrismaGeneral.IParamSource)
        //= description  : <paramdesc>
        //= 2.           : v_strParamName (String)
        //= description  : <paramdesc>
        //========================================================================
        //= Pre conditions
        //= 1.       : <precondition>
        //========================================================================
        //= Post conditions
        //= 1.       : <postcondition>
        //========================================================================
        //= Notes   :
        //= 1.      : All descisions made during coding the application are placed
        //=           at the top of the file. This so every body can read it
        //=           without digging trough the code
        //========================================================================
        //= History
        //=
        //= Version  Date        Author      Notes
        //= 1        10-04-2000  MarkR   First creation
        //========================================================================
        private string fGetParam(PrismaGeneral.IParamSource v_objParams, string v_strParamName)
        {
            string result = String.Empty;
            //try
            //{
                return Convert.ToString(v_objParams.GetParam(v_strParamName));
            //}
            //catch
            //{
            //    return result;
            //}
        }

        private void fInitCounters(ref XmlDocument v_objSchema, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, ref Dictionary<string, int> v_colCounters) //Avdhut Vaidya
        {
            XmlNode objCounterDef = null;
            try
            {
                int lngCounterID = 0;
                string strCounterName = String.Empty;
                int lngStartValue = 0;
                string strType = String.Empty;

                v_colCounters = new Dictionary<string, int>(); //Avdhut Vaidya

                objCounterDef = v_objSchema.DocumentElement.SelectSingleNode("md:counterdef", v_objSchemaNS);
                if (objCounterDef != null)
                {
                    foreach (XmlNode objCounter in objCounterDef.SelectNodes("md:counter", v_objSchemaNS))
                    {
                        lngCounterID = Int32.Parse(modXMLFunctions.FGetNodeText(objCounter, "@id"));
                        strCounterName = modXMLFunctions.FGetNodeText(objCounter, "@name");
                        lngStartValue = Int32.Parse(modXMLFunctions.FGetNodeText(objCounter, "@value", "0"));
                        strType = modXMLFunctions.FGetNodeText(objCounter, "@type").ToLower();
                        if (strType == "persistent")
                        {
                            fRegisterCounter(lngCounterID, strCounterName, v_objJobLogger);
                            fIncreaseCounter(lngCounterID, lngStartValue, v_objJobLogger);
                        }
                        else
                        {
                            #region COMMENTED BY Avdhut Vaidya
                            //object tempRefParam = "C" + lngCounterID.ToString();
                            //object tempRefParam2 = lngStartValue;
                            //m_colCounters.Add(ref tempRefParam, ref tempRefParam2);
                            #endregion //COMMENTED BY Avdhut Vaidya
                            v_colCounters.Add("C" + lngCounterID.ToString(), lngStartValue); //Avdhut Vaidya
                        }
                    }
                }
                objCounterDef = null;

            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        private void fFreeCounters(ref XmlDocument v_objSchema, XmlNamespaceManager v_objSchemaNS, IControlInfo v_objControlInfo, IJobLogger v_objJobLogger, Dictionary<string, int> v_colCounters) //Avdhut Vaidya
        {
            int lngCounterID = 0;

            //hitesh refer from above
            foreach (XmlNode objCounter in v_objSchema.DocumentElement.SelectNodes("md:counterdef/md:counter", v_objSchemaNS))
            {
                lngCounterID = Int32.Parse(modXMLFunctions.FGetNodeText(objCounter, "@id"));
                //v_objControlInfo.FUnRegisterCounter(lngCounterID);
                fUnRegisterCounter(lngCounterID, v_objJobLogger);
            }
            v_colCounters = null;
        }

        //========================================================================
        //= Function Name    : IGenerator_fGenerate
        //= Description      : <fdesc>
        //= Creation Date    : 10-04-2000
        //= Author           : MarkR
        //========================================================================
        //= Input parameters
        //= 1.           : v_objParams (PrismaGeneral.IParamSource)
        //= description  : <paramdesc>
        //= 2.           : v_objControl (IControlInfo)
        //= description  : <paramdesc>
        //========================================================================
        //= Pre conditions
        //= 1.       : <precondition>
        //========================================================================
        //= Post conditions
        //= 1.       : <postcondition>
        //========================================================================
        //= Notes   :
        //= 1.      : All descisions made during coding the application are placed
        //=           at the top of the file. This so every body can read it
        //=           without digging trough the code
        //========================================================================
        //= History
        //=
        //= Version  Date        Author      Notes
        //= 1        10-04-2000  MarkR   First creation
        //========================================================================
        private string IGenerator_fGenerate(PrismaGeneral.IParamSource v_objParams, IControlInfo v_objControl, IJobLogger v_objJobLogger, IJobStatus v_objJobStatus)
        {
            string result = String.Empty;
            //<START>ADDED BY Avdhut Vaidya
            XmlDocument objSchema = null;
            XmlNamespaceManager objSchemaNS = null;
            if (v_objJobStatus == null)
            {
                v_objJobStatus = (IJobStatus)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobManager"));
            }
            Dictionary<string, int> colCounters = null;
            Dictionary<string, DataView> objDataCache = new Dictionary<string, DataView>();
            XmlWriter xWriter = null;
            //<END>ADDED BY Avdhut Vaidya

            try
            {
                string strSchemaURL = String.Empty;
                //Scripting.FileSystemObject objFS = null; Avdhut Vaidya
                //Scripting.TextStream objTS = null; Avdhut Vaidya

                string strFileName = String.Empty;

                pCheckJobRunAborting(v_objJobStatus);

                fInitXMLObjects(ref objSchema, ref xWriter);
                strSchemaURL = fGetParam(v_objParams, "xml_schema_name");
                if (strSchemaURL != "")
                {
                    if (fLoadSchema(ref objSchema, ref objSchemaNS, strSchemaURL))
                    {
                        v_objControl.FProgress("Loading schema succeeded.", ref m_bAbort);

                        fInitCounters(ref objSchema, objSchemaNS, v_objControl, v_objJobLogger, ref colCounters);

                        fProcessSchema(ref objSchema, objSchemaNS, v_objControl, v_objJobLogger, v_objJobStatus, colCounters, objDataCache, v_objParams, fGetSchemaRoot(ref objSchema), xWriter, 1, ""); //Avdhut Vaidya
                        v_objControl.FProgress("XML successfully generated.", ref m_bAbort);

                    }
                }

                xWriter.Close(); //Avdhut Vaidya

                //Returns the size (KB) of generated XML file
                long lngFileSize = fGetFileSize(m_strTmpFileName);
                //fSetCounter(111, lngFileSize, v_objJobLogger);

                fFreeCounters(ref objSchema, objSchemaNS, v_objControl, v_objJobLogger, colCounters);

                fFreeXMLObjects(ref objSchema, ref objSchemaNS, ref v_objControl, ref xWriter);

                result = m_strTmpFileName;

                //Call m_objXMLDoc.Save("C:\Extractie_test.xml")

                //Call fFreeXMLObjects

                return result;
            }
            catch (Exception excep)
            {
                try { if (xWriter != null) { xWriter.Close(); } }
                catch (InvalidOperationException)
                { }
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }

        private long fGetFileSize(string v_strTmpFileName)
        {
            long lngFileSize;
            FileInfo fi;
            fi = new FileInfo(v_strTmpFileName);
            lngFileSize = fi.Length;
            return lngFileSize / 1024;
        }

        private bool fIsXML(XmlNode v_objSchemaNode, XmlNamespaceManager v_objSchemaNS)
        {
            bool bResult = false;

            XmlNode objIsXML = v_objSchemaNode.SelectSingleNode("@md:isxml", v_objSchemaNS);
            if (objIsXML == null)
            {
                bResult = false;
            }
            else
            {
                bResult = objIsXML.Value.Trim().ToLower() == "yes";
                objIsXML = null;
            }
            return bResult;
        }

        private bool fTextToXML(XmlNode v_objNode)
        {

            bool bResult = false;

            #region COMMENTED BY Avdhut Vaidya
            //string strXML = "<ROOT>" + v_objNode.Value + "</ROOT>";
            //MSXML2.DOMDocument objXMLDoc = (MSXML2.DOMDocument) new XmlDocument   /*MSXML2.DOMDocument30*/();
            //objXMLDoc.async = false;
            //if (objXMLDoc.LoadXml/*.loadXML*/(strXML))
            //{
            //    v_objNode.Value = "";
            //    foreach (XmlNode objChild in objXMLDoc.DocumentElement.childNodes)
            //    {
            //        objChild = objChild;
            //        v_objNode.appendChild(objChild);
            //    }
            //    bResult = true;
            //} 
            #endregion //COMMENTED BY Avdhut Vaidya

            //<START>ADDED BY Avdhut Vaidya
            XmlDocumentFragment xFrag;
            string strXML;
            strXML = v_objNode.InnerText;
            xFrag = v_objNode.OwnerDocument.CreateDocumentFragment();

            try
            {
                xFrag.InnerXml = strXML;
                v_objNode.InnerText = "";
                while (xFrag.ChildNodes.Count > 0)
                {
                    v_objNode.AppendChild(xFrag.FirstChild);
                }

                bResult = true;
            }
            catch (XmlException xExcep)
            {
                //SOME ERROR OCCURED PROBABLY WHILE LOADING strXML
                ExceptionPolicy.HandleException(xExcep, Prismaconst.LogOnlyPolicy); //This will log in the error
            }
            finally
            {
                xFrag = null;
            }
            //<END>ADDED BY Avdhut Vaidya

            return bResult;
        }

        private void fIncreaseCounter(long v_lngCounterID, long v_lngAmount, IJobLogger v_objJobLogger)
        {
            try
            {
                v_objJobLogger.FIncreaseCounter(m_lngRunID, v_lngCounterID, v_lngAmount);

            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }
        private void fProgress(string v_strActivity, bool r_bAbort, IJobLogger v_objJobLogger)
        {
            try
            {
                v_objJobLogger.FLog(m_lngRunID, v_strActivity);

            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
        }
        private void fRegisterCounter(long v_lngCounterID, string v_strCounterName, IJobLogger v_objJobLogger) { }
        private void fSetCounter(long v_lngCounterID, long v_lngValue, IJobLogger v_objJobLogger)
        {
            try
            {
                v_objJobLogger.FSetCounter(m_lngRunID, v_lngCounterID, v_lngValue);

            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;

            }
        }
        private void fUnRegisterCounter(long v_lngCounterID, IJobLogger v_objJobLogger) { }

        private void IControlInfo_fIncreaseCounter(long v_lngCounterID, long v_lngAmount)
        {
            //try
            //{
            //    m_objJobLogger.FIncreaseCounter(m_lngRunID, v_lngCounterID, v_lngAmount);
            //
            //}
            //catch (Exception excep)
            //{

            //    //string tempRefParam = "IsDNAXMLExtraction::clsXMLGenerator::IControlInfo_fIncreaseCounter(" + "v_lngCounterID:= " + v_lngCounterID.ToString() + "," + "v_lngAmount:= " + v_lngAmount.ToString() + ")";
            //    //string tempRefParam2 = "ISDNAMSG";
            //    ////<START>Modified by Avdhut Vaidya
            //    ////Prismaconst.ReportError(m_objAbstrObjectContext, excep, ref tempRefParam, ref tempRefParam2);
            //    //IsDNAErrorModule.clsSaveError.ReportError(excep, ref tempRefParam, ref tempRefParam2);
            //    ////<END>Modified by Avdhut Vaidya
            //    //
            //    //throw new Exception(0 + ", " + excep.Source + ", " + excep.Message + ", " + excep.HelpLink + ", " + excep.TargetSite);
            //    ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
            //
            //    throw;

            //}
        }
        private void IControlInfo_fProgress(string v_strActivity, bool r_bAbort)
        {
            //try
            //{
            //    m_objJobLogger.FLog(m_lngRunID, v_strActivity);
            //
            //}
            //catch (Exception excep)
            //{

            //    //string tempRefParam = "IsDNAXMLExtraction::clsXMLGenerator::IControlInfo_fProgress(" + "v_strActivity:= " + v_strActivity + "," + "r_bAbort:= " + r_bAbort.ToString() + ")";
            //    //string tempRefParam2 = "ISDNAMSG";
            //    ////<START>Modified by Avdhut Vaidya
            //    ////Prismaconst.ReportError(m_objAbstrObjectContext, excep, ref tempRefParam, ref tempRefParam2);
            //    //IsDNAErrorModule.clsSaveError.ReportError(excep, ref tempRefParam, ref tempRefParam2);
            //    ////<END>Modified by Avdhut Vaidya

            //    //
            //    //throw new Exception(0 + ", " + excep.Source + ", " + excep.Message + ", " + excep.HelpLink + ", " + excep.TargetSite);
            //    ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
            //
            //    throw;

            //}
        }
        private void IControlInfo_fRegisterCounter(long v_lngCounterID, string v_strCounterName)
        {
            //
        }
        private void IControlInfo_fSetCounter(long v_lngCounterID, long v_lngValue)
        {
            //try
            //{

            //    m_objJobLogger.FSetCounter(m_lngRunID, v_lngCounterID, v_lngValue);
            //
            //}
            //catch (Exception excep)
            //{
            //    //string tempRefParam = "IsDNAXMLExtraction::clsXMLGenerator::IControlInfo_fSetCounter(" + "v_lngCounterID:= " + v_lngCounterID.ToString() + "," + "v_lngValue:= " + v_lngValue.ToString() + ")";
            //    //string tempRefParam2 = "ISDNAMSG";
            //    ////<START>Modified by Avdhut Vaidya
            //    ////Prismaconst.ReportError(m_objAbstrObjectContext, excep, ref tempRefParam, ref tempRefParam2);
            //    //IsDNAErrorModule.clsSaveError.ReportError(excep, ref tempRefParam, ref tempRefParam2);
            //    ////<END>Modified by Avdhut Vaidya

            //    //
            //    //throw new Exception(0 + ", " + excep.Source + ", " + excep.Message + ", " + excep.HelpLink + ", " + excep.TargetSite);
            //    ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
            //
            //    throw;

            //}
        }
        private void IControlInfo_fUnRegisterCounter(long v_lngCounterID)
        {
            //
        }

        private string IGenericStep_fProcessData(string v_strData, PrismaGeneral.IParamSource v_objParams, XmlNode v_objComponentData, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            string result = String.Empty;
            IsDnaJobManagement.IJobStatus objJobStatus = null;

            try
            {
                //<START>ADDED BY Avdhut Vaidya
                objJobStatus = (IsDnaJobManagement.IJobStatus)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobManager"));
                //<END>ADDED BY Avdhut Vaidya

                string strSchemaFile = String.Empty;
                string strFileName = String.Empty;

                m_lngRunID = Convert.ToInt32(v_objParams.GetParam("jrn_id"));

                m_abort = false;

                pCheckJobRunAborting(objJobStatus);

                if (v_objComponentData.SelectSingleNode("SCHEMA") != null)
                {
                    strFileName = BuildPath(modXMLFunctions.FGetNodeText(v_objComponentData, "PRISMA-SETTINGS/SETTING[@name='xml_schema_path']"), modXMLFunctions.FGetNodeText(v_objComponentData, "SCHEMA")); //Avdhut Vaidya

                    v_objParams.SetParam("xml_schema_name", strFileName);
                }

                //Set v_objControlInfo = Me
                //Call v_objControlInfo.fProgress("Update statistics started.", m_bAbort)
                //Call objExecSPFromPS.ExecNoRS("sp_xml_b_00", g_strSYSTEMERRORSOURCE, v_objParams)
                //Call v_objControlInfo.fProgress("Update statistics succeeded.", m_bAbort)

                #region COMMENTED BY Avdhut Vaidya
                /*
						if (objFS == null)
						{
							objFS = new Scripting.FileSystemObject();
						}
						
						m_strTmpFileName = objFS.BuildPath(modXMLFunctions.fGetNodeText(v_objComponentData, "FILENAME"), objFS.GetTempName());
					    */

                #endregion //COMMENTED BY Avdhut Vaidya

                m_strTmpFileName = modXMLFunctions.FGetNodeText(v_objComponentData, "FILENAME");

                result = IGenerator_fGenerate(v_objParams, this, v_objJobLogger, objJobStatus);


                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);

                throw;
            }
            finally
            {
                if (objJobStatus != null) ((IDisposable)objJobStatus).Dispose();
            }
        }

        /// <summary>
        /// can be used as a FileSystem.BuildPath() function.
        /// concatinates the folder and file name with a path seperator if it does not exist in the <paramref name="path"/>
        /// </summary>
        /// <param name="path">the path of the folder</param>
        /// <param name="name">the name of the file</param>
        /// <returns>returns the concatinated path and folder</returns>
        private string BuildPath(string path, string name)
        {
            string result;
            result = "";
            result = path;
            if (result.EndsWith("\\") == false)
            {
                result = result + "\\";
            }
            result = result + name;
            return result;
        }

        private void pCheckJobRunAborting(IJobStatus v_objJobStatus)
        {
            string strCurrentJobRunStatus = v_objJobStatus.FGetStatus(m_lngRunID).Trim().ToUpper();
            if (strCurrentJobRunStatus == "ABORTING")
            {
                m_abort = true;
                throw new Exception((9999 + 0).ToString() + ", Job aborted by other process.");
            }
        }

        private DataSet frsGetCachedData(XmlNode v_objComponentNode, XmlNamespaceManager v_objSchemaNS, Dictionary<string, DataView> v_objDataCache, PrismaGeneral.IParamSource v_objParams)
        {
            DataSet result = null;
            DataSet rsCachedData = null;
            DataView dvCachedData = null;
            DataRowView[] drv;
            DataTable resultDataTable = null;
            try
            {
                string strFilter = String.Empty;
                string strFieldName = String.Empty;
                string strFieldNameList = "";
                string strFieldValue = String.Empty;
                string strFieldValueList = "";
                string strName = String.Empty;
                string strParamFieldName = String.Empty;

                strName = modXMLFunctions.FGetNodeText(v_objComponentNode, "@name");

                if (v_objDataCache.ContainsKey(strName) == true) //Avdhut Vaidya
                {
                    dvCachedData = v_objDataCache[strName]; //Avdhut Vaidya
                    strFilter = "";
                    foreach (XmlNode objFilterField in v_objComponentNode.SelectNodes("md:filter/md:field", v_objSchemaNS))
                    {
                        if (strFilter != "")
                        {
                            strFilter = strFilter + " and ";
                        }
                        strFieldName = modXMLFunctions.FGetNodeText(objFilterField, "@name");

                        // For md:table tags $ fields are needed. With caching the fields
                        // that are needed for the filtering that are retrieved from the
                        // paramsource (the values) are stored wothout the preceeding $ sign.
                        // Therefor the $ sign is remove from the paramsource field name.
                        if (strFieldName.StartsWith("$"))
                        {
                            strParamFieldName = strFieldName.Substring(1);
                        }
                        else
                        {
                            strParamFieldName = strFieldName;
                        }

                        strFieldValue = modXMLFunctions.FGetNodeText(objFilterField, "@value", Convert.ToString(v_objParams.GetParam(strParamFieldName)));

                        // The "[" and "]" signs are needed around the fieldnames because
                        // if a $ sign is in the field name this sign is a special charater
                        // for the filter engine.
                        if (strFieldValue != "")
                        {
                            strFilter = strFilter + "[" + strFieldName + "]" + " = '" + strFieldValue + "'";
                        }
                        else
                        {
                            strFilter = strFilter + strFieldName + " = null";
                        }

                        strFieldNameList += "," + strFieldName;
                        strFieldValueList += "·" + strFieldValue;
                    }
                    strFieldNameList = strFieldNameList.Substring(1);
                    strFieldValueList = strFieldValueList.Substring(1);


                    if (strFilter != "")
                    {
                        strFilter = "(" + strFilter + ")";
                    }
                    //<START>MODIFIED BY Avdhut Vaidya
                    if (dvCachedData.Sort != strFieldNameList)
                        dvCachedData.Sort = strFieldNameList;
                    drv = dvCachedData.FindRows(strFieldValueList.Split('·'));
                    resultDataTable = dvCachedData.Table.Clone();
                    result = new DataSet();
                    result.Tables.Add(resultDataTable);
                    foreach (DataRowView dr in drv)
                    {
                        resultDataTable.ImportRow(dr.Row);
                    }
                    //<END>MODIFIED BY Avdhut Vaidya
                }


                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
            finally
            {
                if (resultDataTable != null)
                    resultDataTable.Dispose();
                if (result != null)
                    result.Dispose();
                if (rsCachedData != null)
                    rsCachedData.Dispose();
            }
        }

        #region IGenericStep Members

        string IsDNAImportTypelib.IGenericStep.FProcessData(string v_strData, PrismaGeneral.IParamSource v_objParams, XmlNode v_objComponentData, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            return IGenericStep_fProcessData(v_strData, v_objParams, v_objComponentData, v_objJobLogger);
        }

        #endregion

        #region IControlInfo Members

        void IControlInfo.FProgress(string v_strActivity, ref bool r_bAbort)
        {
            IControlInfo_fProgress(v_strActivity, r_bAbort);
        }

        void IControlInfo.FIncreaseCounter(long v_lngCounterID, long v_lngAmount)
        {
            IControlInfo_fIncreaseCounter(v_lngCounterID, v_lngAmount);
        }

        void IControlInfo.FSetCounter(long v_lngCounterID, long v_lngValue)
        {
            IControlInfo_fSetCounter(v_lngCounterID, v_lngValue);
        }

        void IControlInfo.FRegisterCounter(long v_lngCounterID, string v_strCounterName)
        {
            IControlInfo_fRegisterCounter(v_lngCounterID, v_strCounterName);
        }

        void IControlInfo.FUnRegisterCounter(long v_lngCounterID)
        {
            IControlInfo_fUnRegisterCounter(v_lngCounterID);
        }

        #endregion

        #region IGenerator Members

        string IGenerator.FGenerate(PrismaGeneral.IParamSource v_objParams, IControlInfo v_objControl)
        {
            return IGenerator_fGenerate(v_objParams, v_objControl, null, null);
        }

        #endregion
    }
}
