﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IsDNAImportTypelib;
using System.Xml;
using System.IO;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;

namespace PRISMA.LOR2.BLL
{
    public class clsDistribute
        : IGenericStep
    {

        private IsDnaJobManagement.IJobLogger m_objJobLogger;

        private string fProcessData(string v_strData, PrismaGeneral.IParamSource v_objParams, XmlNode v_objComponentData, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            string result = String.Empty;
            string tmpExt = String.Empty;
            FileStream objTmpStream = null;
            XmlReader objXMLReader = null;
            XmlWriter objXMLWriter = null;

            try
            {
                string strXML = String.Empty;
                int lngPos = 0;
                int lngHulp = 0;
                int lngHulpPos = 0;
                int lngDTDPos = 0;
                string strHulp = String.Empty;

                string strXMLFileName = String.Empty;
                string strBaseFileName = String.Empty;
                string strSourceDTDFileName = String.Empty;
                string strTargetDTDFileName = String.Empty;
                string strXSLTFileName = String.Empty;
                string strDTDName = String.Empty;
                string strData = String.Empty;


                m_objJobLogger = v_objJobLogger;

                byte[] bytData = new byte[200];

                objTmpStream = new FileStream(v_strData, FileMode.Open, FileAccess.Read);
                //strData = objTmpStream.Read(200); Avdhut Vaidya
                objTmpStream.Read(bytData, 0, 200);
                strData = new String(System.Text.Encoding.UTF8.GetChars(bytData));
                objTmpStream.Close();
                objTmpStream = null;


                strXMLFileName = modXMLFunctions.FGetNodeText(v_objComponentData, "FILENAME");

                strBaseFileName = strXMLFileName.Replace("." + Path.GetExtension(strXMLFileName).Substring(1), "");
                File.Copy(v_strData, strBaseFileName + "_tmp.xml");

                strSourceDTDFileName = Path.Combine(modXMLFunctions.FGetNodeText(v_objComponentData, "DTD/@sourcepath"), modXMLFunctions.FGetNodeText(v_objComponentData, "DTD/@filename"));
                strTargetDTDFileName = Path.Combine(modXMLFunctions.FGetNodeText(v_objComponentData, "DTD/@targetpath"), modXMLFunctions.FGetNodeText(v_objComponentData, "DTD/@filename"));
                strDTDName = Path.GetFileName(strSourceDTDFileName);

                lngHulpPos = (strData.IndexOf("?>") + 1);
                if (lngHulpPos == 0)
                {
                    lngHulpPos = 1;
                }
                lngDTDPos = strData.IndexOf("<", lngHulpPos);
                if (lngDTDPos < 0)
                {
                    //Get out, no TOP ELEMENT
                    throw new System.Exception((+9899).ToString() + ", XML Document has no TOP ELEMENT");
                }
                lngPos = strData.IndexOf(" ", lngDTDPos);
                lngHulp = strData.IndexOf(">", lngDTDPos);
                if (lngPos > lngHulp)
                {
                    lngPos = lngHulp;
                }

                strHulp = strData.Substring(lngDTDPos + 1, lngPos - (lngDTDPos + 1));
                objXMLReader = XmlTextReader.Create(v_strData);
                objXMLWriter = XmlTextWriter.Create(strBaseFileName + "_err.xml");
                objXMLWriter.WriteStartDocument();
                objXMLWriter.WriteDocType(strHulp, null, strDTDName, null);
                //objXMLReader.MoveToContent();
                copyXML(objXMLWriter, objXMLReader);
                objXMLWriter.Flush();
                objXMLWriter.Close();
                objXMLReader.Close();

                try
                {
                    File.Copy(strSourceDTDFileName, strTargetDTDFileName, true);
                }
                catch (Exception exep)
                {

                }
                //<END>MODIFIED BY Avdhut Vaidya

                result = v_strData;


                if (File.Exists(strBaseFileName + "_tmp.xml"))
                {
                    File.Delete(strBaseFileName + "_tmp.xml");
                }

                return result;
            }
            catch (Exception excep)
            {
                if (File.Exists(v_strData))
                {
                    try { objTmpStream.Close(); objTmpStream = null; }
                    catch (Exception ex) { }
                    try { if (objXMLReader != null) { objXMLReader.Close(); } objXMLReader = null; }
                    catch (Exception ex) { ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy); }
                    File.Delete(v_strData);
                }
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private void copyXML(XmlWriter xtw, XmlReader xtr)
        {

            try
            {
                int i = 0;
                while (true)
                {
                    i++;
                    if (i >= 5000)
                    {
                        xtw.Flush();
                        i = 0;
                    }

                    if (xtr.Read() == false)
                    {
                        break;
                    }
                    switch (xtr.NodeType)
                    {
                        case XmlNodeType.Attribute:
                            xtw.WriteAttributeString(xtr.Prefix,
                                xtr.LocalName, xtr.NamespaceURI, xtr.Value);
                            break;
                        case XmlNodeType.CDATA:
                            xtw.WriteCData(xtr.Value);
                            break;
                        case XmlNodeType.Comment:
                            xtw.WriteComment(xtr.Value);
                            break;
                        case XmlNodeType.DocumentType:
                            xtw.WriteDocType(xtr.Name, null, null, null);
                            break;
                        case XmlNodeType.Element:
                            xtw.WriteStartElement(xtr.Prefix,
                                xtr.LocalName, xtr.NamespaceURI);
                            if (xtr.AttributeCount > 0)
                                xtw.WriteAttributes(xtr, true);
                            if (xtr.IsEmptyElement)
                                xtw.WriteEndElement();
                            break;
                        case XmlNodeType.EndElement:
                            xtw.WriteEndElement();
                            break;
                        case XmlNodeType.EntityReference:
                            xtw.WriteEntityRef(xtr.Name);
                            break;
                        case XmlNodeType.ProcessingInstruction:
                            xtw.WriteProcessingInstruction(xtr.Name, xtr.Value);
                            break;
                        case XmlNodeType.SignificantWhitespace:
                            xtw.WriteWhitespace(xtr.Value);
                            break;
                        case XmlNodeType.Text:
                            xtw.WriteString(xtr.Value);
                            break;
                        case XmlNodeType.Whitespace:
                            xtw.WriteWhitespace(xtr.Value);
                            break;
                    }
                }
                xtw.Flush();
            }
            catch (Exception excep)
            {
                xtw.Flush();
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }

        }

        private void LogEvent(string str)
        {
            System.Diagnostics.EventLog objEvtLog;
            objEvtLog = new System.Diagnostics.EventLog("Application");
            objEvtLog.Source = this.ToString();
            objEvtLog.WriteEntry(str);
            objEvtLog = null;
        }

        #region IGenericStep Members

        string IsDNAImportTypelib.IGenericStep.FProcessData(string v_strData, PrismaGeneral.IParamSource v_objParams, XmlNode v_objComponentData, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            return fProcessData(v_strData, v_objParams, v_objComponentData, v_objJobLogger);
        }

        #endregion

    }

}
