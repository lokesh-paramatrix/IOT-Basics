﻿using Common;
using System;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Collections;

namespace PRISMA.LOR2.BLL
{
    public sealed class clsJobLogger
        : IsDnaJobManagement.IJobLogger
    {
        private PrismaGeneral.ICommonRead m_objIsDnaJobMgt;

        //IJobLogger =============================================================================================
        private void FLog(long vLngRunID, string vStrLogMsg)
        {
            PrismaGeneral.IParamSource objparams = null;
            try
            {
                int lnglen = 0;
                string strmsgpart = String.Empty;
                string strmsg = String.Empty;

                objparams = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                objparams.SetParam("jrn_id", vLngRunID.ToString());

                strmsg = vStrLogMsg;

                do
                {
                    lnglen = strmsg.Length;
                    if (lnglen > 255)
                    {
                        strmsgpart = strmsg.Substring(0, 255);
                        strmsg = strmsg.Substring(255);
                    }
                    else
                    {
                        strmsgpart = strmsg;
                    }
                    objparams.SetParam("jlg_info", strmsgpart);

                    ExecuteNonQuery("sp_job_mgr_b_08", Prismaconst.g_strJOBMANAGERDB, objparams);
                }
                while (lnglen > 255);
            }

            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
            finally
            {
                if (objparams != null) ((IDisposable)objparams).Dispose();
            }
        }

        private void ExecuteNonQuery(string spName, string requiredDB, PrismaGeneral.IParamSource objParams)
        {
            SqlDatabase objExecuteSPFromPS;
            objExecuteSPFromPS = new SqlDatabase(requiredDB);
            objExecuteSPFromPS.ExecuteNonQuery(spName, objParams);
            objExecuteSPFromPS = null;
        }

        private void FIncreaseCounter(long vLngRunID, long vLngCounterID, long vLngAmount)
        {
            PrismaGeneral.IParamSource objparams = null;
            try
            {
                objparams = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                objparams.SetParam("JRN_ID", vLngRunID.ToString());
                objparams.SetParam("JCT_ID", vLngCounterID.ToString());
                objparams.SetParam("JCV_VALUE", vLngAmount.ToString());

                ExecuteNonQuery("sp_job_mgr_b_07", Prismaconst.g_strJOBMANAGERDB, objparams);
            }

            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
            finally
            {
                if (objparams != null) ((IDisposable)objparams).Dispose();
            }
        }

        private void FSetCounter(long vLngRunID, long vLngCounterID, long vLngValue)
        {
            PrismaGeneral.IParamSource objparams = null;
            try
            {
                objparams = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                objparams.SetParam("JRN_ID", vLngRunID.ToString());
                objparams.SetParam("JCT_ID", vLngCounterID.ToString());
                objparams.SetParam("JCV_VALUE", vLngValue.ToString());

                ExecuteNonQuery("sp_job_mgr_b_19", Prismaconst.g_strJOBMANAGERDB, objparams);
            }

            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
            finally
            {
                if (objparams != null) ((IDisposable)objparams).Dispose();
            }
        }

        #region IJobLogger Members

        void IsDnaJobManagement.IJobLogger.FIncreaseCounter(long vLngRunID, long vLngCounterID, long vLngAmount)
        {
            FIncreaseCounter(vLngRunID, vLngCounterID, vLngAmount);
        }

        void IsDnaJobManagement.IJobLogger.FLog(long vLngRunID, string vStrLogMsg)
        {
            FLog(vLngRunID, vStrLogMsg);
        }

        void IsDnaJobManagement.IJobLogger.FSetCounter(long vLngRunID, long vLngCounterID, long vLngValue)
        {
            FSetCounter(vLngRunID, vLngCounterID, vLngValue);
        }

        #endregion
    }
}