using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IsDNAImportTypelib;
using System.Xml;
using System.IO;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;
using PRISMA.LOR2.BLL;
using System.Xml.Schema;

namespace PRISMA.LOR2.BLL
{
    public class clsXMLValidator
    : IsDNAImportTypelib.IGenericStep
    {

        private IsDnaJobManagement.IJobLogger m_objJobLogger = null;
        private int m_jrn_id = 0;
        private string m_locale = "";
        private string m_target_group = "";
        private string m_feed_name = "";

        private bool FValidateUsingSchema(string v_strXML, string v_strSchemaURL)
        {
            try
            {
                XmlReader xReader;
                XmlReaderSettings xReaderSettings;
                ValidationEventHandler xrsValidator;
                bool bValidXML = false;

                bValidXML = true;
                FLog("<START>VALIDATING " + v_strXML + " AGAINST XSD: " + v_strSchemaURL);
                xrsValidator = delegate(object sender, ValidationEventArgs e)
                {
                    bValidXML = false;
                    FLog("XSDError", e.Exception.Message);
                };

                xReaderSettings = new XmlReaderSettings();
                xReaderSettings.ValidationType = ValidationType.Schema;
                xReaderSettings.Schemas.Add("", v_strSchemaURL);
                xReaderSettings.ValidationEventHandler += new ValidationEventHandler(xrsValidator);

                xReader = XmlReader.Create(v_strXML, xReaderSettings);
                while (xReader.Read()) ;
                xReader.Close();
                FLog("<END>VALIDATING " + v_strXML + " AGAINST XSD: " + v_strSchemaURL);
                return bValidXML;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        private void FLog(string strMsg)
        {
            FLog("", strMsg);
        }

        private void FLog(string strCategory, string strMsg)
        {
            if (strCategory != "")
                strCategory = "::" + strCategory;
            m_objJobLogger.FLog(m_jrn_id, m_feed_name + "::" + m_target_group + "::" + m_locale + strCategory + "::" + strMsg);
        }

        private bool FValidateUsingDTD(string v_strXML, string v_strDTD)
        {
            XmlDocument objXMLDoc = new XmlDocument();

            try
            {
                objXMLDoc.Load(v_strXML);
                objXMLDoc = null;
                return true;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }

        #region IGenericStep Members
        string IsDNAImportTypelib.IGenericStep.FProcessData(string v_strData, PrismaGeneral.IParamSource v_objParams, XmlNode v_objComponentData, IsDnaJobManagement.IJobLogger v_objJobLogger)
        {
            string result = String.Empty;
            try
            {
                string strType = String.Empty;
                string strSchemaURL = String.Empty;
                string strDTDUrl = String.Empty;
                string strSchemaPath = String.Empty;
                string strXMLFileName = String.Empty;
                string strBaseFileName = String.Empty;

                string strExtension = String.Empty;

                m_jrn_id = int.Parse(v_objParams.GetParam("jrn_id"));
                m_locale = v_objParams.GetParam("locale");
                m_target_group = v_objParams.GetParam("publ_target_group_cd");
                m_feed_name = v_objParams.GetParam("feedName");

                strSchemaPath = modXMLFunctions.FGetNodeText(v_objComponentData, "xml_schema_path");
                if (File.Exists(strSchemaPath) == false)
                    throw new FileNotFoundException("SCHEMA FILE " + strSchemaPath + " NOT FOUND");

                //FIRST CHANGE THE NAME OF THE FILE TO <<FILENAME>>_err.xml
                strExtension = Path.GetExtension(v_strData);
                strXMLFileName = v_strData.Replace(strExtension, "");
                strXMLFileName += "_err.xml";
                File.Move(v_strData, strXMLFileName);

                m_objJobLogger = v_objJobLogger;

                strType = modXMLFunctions.FGetNodeText(v_objComponentData, "VALIDATION-TYPE").ToLower();

                if (strType == "dtd")
                {
                    //strXMLFileName = modXMLFunctions.FGetNodeText(v_objComponentData, "FILENAME");
                    //strBaseFileName = strXMLFileName.Replace(Path.GetExtension(strXMLFileName), "");
                    //strDTDUrl = Path.Combine(modXMLFunctions.FGetNodeText(v_objComponentData, "DTD/@sourcepath"),
                    //                            modXMLFunctions.FGetNodeText(v_objComponentData, "DTD/@filename"));


                    if (!FValidateUsingDTD(strXMLFileName, strSchemaPath))
                    {
                        FLog("WARNING: The XML is not valid according to the DTD.");
                        v_strData = strXMLFileName;
                    }
                    else
                    {
                        FLog("XML is successfully validated against the DTD.");
                        File.Move(strXMLFileName, v_strData);
                    }
                }
                else
                {
                    if (!FValidateUsingSchema(strXMLFileName, strSchemaPath))
                    {
                        FLog("The XML is not valid according the Schema.");
                        v_strData = strXMLFileName;
                    }
                    else
                    {
                        FLog("XML is successfully validated against the Schema.");
                        File.Move(strXMLFileName, v_strData);
                    }
                }

                result = v_strData;

                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                throw;
            }
        }
        #endregion
    }
}