﻿using System;
using System.Text;
using Common;
using System.Xml;

namespace PRISMA.LOR2.BLL
{
    class modXMLFunctions
    {
        static public string FGetOutputXmlFilename(string locale)
        {
            return "Lighting." + locale + "." + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xml";
        }

        static public bool FSelectNode(XmlNode v_objParentNode, string v_strXSLPatern, ref XmlNode r_objResultNode)
        {
            r_objResultNode = v_objParentNode.SelectSingleNode(v_strXSLPatern);
            return r_objResultNode != null;
        }

        static public bool FSelectNode(XmlNode v_objParentNode, string v_strXSLPatern, ref XmlNode r_objResultNode, XmlNamespaceManager nsMgr)
        {
            r_objResultNode = v_objParentNode.SelectSingleNode(v_strXSLPatern, nsMgr);
            return r_objResultNode != null;
        }

        static public string FGetNodeText(XmlNode v_objParentNode, string v_strXSLPatern, string v_strDefault)
        {
            XmlNode objNode = null;
            string strResult = String.Empty;


            if (FSelectNode(v_objParentNode, v_strXSLPatern, ref objNode))
            {
                strResult = objNode.InnerText; //Avdhut Vaidya
            }
            else
            {
                strResult = v_strDefault;
            }
            return strResult;
        }

        static public string FGetNodeText(XmlNode v_objParentNode, string v_strXSLPatern, string v_strDefault, XmlNamespaceManager nsMgr)
        {
            XmlNode objNode = null;
            string strResult = String.Empty;


            if (FSelectNode(v_objParentNode, v_strXSLPatern, ref objNode, nsMgr))
            {
                strResult = objNode.InnerText; //Avdhut Vaidya
            }
            else
            {
                strResult = v_strDefault;
            }
            return strResult;
        }

        static public string FGetNodeText(XmlNode v_objParentNode, string v_strXSLPatern)
        {
            return FGetNodeText(v_objParentNode, v_strXSLPatern, "");
        }

        static public string FGetNodeText(XmlNode v_objParentNode, string v_strXSLPatern, XmlNamespaceManager nsMgr)
        {
            return FGetNodeText(v_objParentNode, v_strXSLPatern, "", nsMgr);
        }

        static public int FGetCounterID(XmlNode v_objSchemaNode)
        {
            int lngResult = 0;

            XmlNode objCounter = v_objSchemaNode.SelectSingleNode("md:counter");


            if (objCounter == null)
            {
                lngResult = 0;
            }
            else
            {
                lngResult = Int32.Parse(objCounter.SelectSingleNode("@id").Value);
                objCounter = null;
            }
            return lngResult;
        }


        static public XmlNode FGetNodeDef(XmlNode v_objSchemaNode)
        {
            XmlNode objResultNode = null;
            string strTypeName = String.Empty;


            switch (v_objSchemaNode.Name.ToLower())
            {
                case "elementtype":
                case "attributetype":
                    objResultNode = v_objSchemaNode;
                    break;
                case "element":
                    strTypeName = v_objSchemaNode.SelectSingleNode("@type").Value;
                    objResultNode = v_objSchemaNode.OwnerDocument.DocumentElement.SelectSingleNode("ElementType[@name='" + strTypeName + "']");
                    break;
                case "attribute":
                    strTypeName = v_objSchemaNode.SelectSingleNode("@type").Value;
                    objResultNode = v_objSchemaNode.ParentNode.SelectSingleNode("AttributeType[@name='" + strTypeName + "']");
                    if (objResultNode == null)
                    {
                        objResultNode = v_objSchemaNode.OwnerDocument.DocumentElement.SelectSingleNode("AttributeType[@name='" + strTypeName + "']");
                    }
                    break;
                default:
                    objResultNode = null;
                    break;
            }

            return objResultNode;
        }

        static public string FGetElementPath(XmlNode v_objNode)
        {
            XmlNode objNode = null;
            StringBuilder strPath = new StringBuilder();
            strPath.Append(String.Empty);

            XmlNodeList objAncestors = v_objNode.SelectNodes("ancestor-or-self::*");
            for (int lIndex = objAncestors.Count - 1; lIndex >= 0; lIndex--)
            {
                if (!String.IsNullOrEmpty(strPath.ToString()))
                {
                    strPath.Append("/");
                }
                strPath.Append(objNode.Name);
            }

            return strPath.ToString();
        }

        static public bool FFindAncestor(XmlNode v_objNode, string v_strNodeName)
        {
            bool bResult = false;

            XmlNode objNode = v_objNode.ParentNode;
            while (objNode != null && !bResult)
            {

                bResult = (objNode.Name == v_strNodeName);
                objNode = objNode.ParentNode;
            }

            return bResult;
        }
    }
}