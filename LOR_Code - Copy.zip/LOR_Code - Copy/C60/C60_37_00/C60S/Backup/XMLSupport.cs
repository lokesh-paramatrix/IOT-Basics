using System; 
using System.Xml;
using Common;
using PrismaGeneral;
using System.EnterpriseServices;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace C93Control
{
    public class modXMLSupport
    {
        static public XmlNode FCreateAttribute(XmlNode vObjNode, string vStrAttrName, string vStrAttrValue)
        {

            XmlNode objAttr = (XmlNode)vObjNode.OwnerDocument.CreateAttribute(vStrAttrName);
            vObjNode.Attributes.SetNamedItem(objAttr);
            objAttr.InnerText = vStrAttrValue;
            return objAttr;
        }

        static public XmlNode FCreateNodeWithAttributes(XmlNode vObjNode)
        {
            XmlNode objNewNode = vObjNode.CloneNode(false);
            foreach (XmlNode objAttr in vObjNode.Attributes)
            {
                objNewNode.Attributes.SetNamedItem(objAttr.CloneNode(true));
            }
            return objNewNode;
        }

        static public XmlNode FCreateXmlDocument(string vStrRootNode)
        {

            XmlDocument objXMLDoc = new XmlDocument();
            //objXMLDoc.async = false;
            XmlNode objRoot = (XmlNode)objXMLDoc.CreateElement(vStrRootNode);
            objXMLDoc.AppendChild(objRoot);

            return objRoot;
        }

        static public XmlNode FCreateXmlDocumentFromNode(XmlNode vObjNode)
        {

            XmlDocument objXMLDoc = new XmlDocument();
            //objXMLDoc.async = false;
            XmlNode objRoot = vObjNode.CloneNode(false);
            objXMLDoc.AppendChild(objRoot);

            return objRoot;
        }

        static public XmlNode FCreateXmlDocumentFromString(string vStrXml)
        {
            XmlNode objRoot;
            objRoot = null;
            XmlDocument objXMLDoc = new XmlDocument();
            //objXMLDoc.async = false;
            try
            {
                objXMLDoc.LoadXml(vStrXml);
                objRoot = (XmlNode)objXMLDoc.DocumentElement;
            }
            catch(XmlException)
            {
                objRoot = null;
            }
            return objRoot;
        }

        static public XmlNode FCreateXmlDocumentFromUrl(string vStrUrl)
        {
            XmlNode objRoot;
            objRoot = null;
            XmlDocument objXMLDoc = new XmlDocument();
            //objXMLDoc.async = false; //Nikhil in .Net what is the replacement??
            try
            {
                objXMLDoc.Load(vStrUrl);
                objRoot = (XmlNode)objXMLDoc.DocumentElement;
                //objXMLDoc.setProperty("SelectionLanguage", "XPath"); //Nikhil in .Net what is the replacement??
            }
            catch(XmlException)
            {
                objRoot = null;
            }
            return objRoot;
        }

        static public string FGetNodeText(XmlNode vObjNode, string vStrXslPattern)
        {
            string strResult = String.Empty;

            XmlNode objNode = vObjNode.SelectSingleNode(vStrXslPattern);
            if (objNode != null)
            {
                strResult = objNode.InnerText;
                objNode = null;
            }
            return strResult;
        }
    }
}
