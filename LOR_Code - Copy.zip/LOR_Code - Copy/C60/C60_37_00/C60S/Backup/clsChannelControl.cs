using System; 
using System.Data; 
using System.IO;
using System.Collections;
using System.Runtime.InteropServices; 
using System.Xml;
using System.EnterpriseServices;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;
using PrismaGeneral;

namespace C93Control
{
    [Transaction(TransactionOption.NotSupported)] 
    [JustInTimeActivation(true)]
    [EventTrackingEnabled(true)] 
    [ProgId("C93Control.clsChannelControl")]
    [ClassInterface(ClassInterfaceType.AutoDual)]

    public class clsChannelControl
        : System.EnterpriseServices.ServicedComponent, IsDnaJobManagement.IJobControl2, IsDnaJobManagement.IJobLogger
    {
        private IsDnaJobManagement.IJobLogger m_objLogger;
        private IsDnaJobManagement.IJobStatus m_objJobStatus;
        private IsDnaJobManagement.IJobMgrControl m_objJobManager;
        private PrismaGeneral.ICommonRead m_objJobManagement;
        private PrismaGeneral.ICommonModify m_objManageXMLRelatedJobs;
        private long m_lngRunID;

        private IsDnaJobManagement.IJobLogger ObjLogger
        {
            get
            {
                if (m_objLogger == null)
                {
                    m_objLogger = (IsDnaJobManagement.IJobLogger)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobLogger"));
                }
                return m_objLogger;
            }
        }

        private IsDnaJobManagement.IJobMgrControl ObjJobManager
        {
            get
            {
                if (m_objJobManager == null)
                {
                    m_objJobManager = (IsDnaJobManagement.IJobMgrControl)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobManager"));
                }
                return m_objJobManager;
            }
        }

        private IsDnaJobManagement.IJobStatus ObjJobStatus
        {
            get
            {
                if (m_objJobStatus == null)
                {
                    m_objJobStatus = (IsDnaJobManagement.IJobStatus)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobManager"));
                }
                return m_objJobStatus;
            }
        }

        private PrismaGeneral.ICommonRead ObjJobManagement
        {
            get
            {
                if (m_objJobManagement == null)
                {
                    m_objJobManagement = (PrismaGeneral.ICommonRead)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobManagement"));
                }
                return m_objJobManagement;
            }
        }

        private PrismaGeneral.ICommonModify ObjManageXmlRelatedJobsModify
        {
            get
            {
                if (m_objManageXMLRelatedJobs == null)
                {
                    m_objManageXMLRelatedJobs = (PrismaGeneral.ICommonModify)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsManageRunningXMLJobs"));
                }

                return m_objManageXMLRelatedJobs;
            }
        }

        //IJobControl ========================================================================================
        private void FStart(string vStrJobUid, long vLngRunID, PrismaGeneral.IParamSource vObjParams)
        {

            PrismaGeneral.IParamSource objSettings = null;
            PrismaGeneral.ICommonRead objRead = null;
            PrismaGeneral.ICommonRead objManageXMLRelatedJobsRead = null;
            PrismaGeneral.IParamSource objParams = null;
            
            long lngChannelID = 0;
            XmlNode objChannelDefRoot;
            XmlNode objChannelData;
            string strStatus = String.Empty;
            bool bJobGrpJob = false;
            long lngJobGrpRunId = 0;
            string strJobKind = String.Empty;

            DataSet rsRead=null;
            DataSet rsInterfInfo=null;
            DataSet rsJobType=null;
            DataSet rsRunningSnapshots=null;

            try
            {
                string strChannelDefFile = String.Empty;
                //Object objFS;

                //objFS = new Object();
                // Copy parameters so paramsource is not poluted by where parameters
                objParams = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));;
                vObjParams.CopyParams(objParams);

                // Set RunID for use in IJobLogger implementation
                m_lngRunID = vLngRunID;

                // Get Settings for Channel Definition
                objSettings = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));

                objRead = (PrismaGeneral.ICommonRead)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC93BS.clsInterfacingSystem"));

                // Get interface information
                objParams.SetParam("ifc_guid", vStrJobUid);
                vStrJobUid = Convert.ToString(vStrJobUid);
                objParams.SetParam("where", "c_get_interface_by_guid");

                rsInterfInfo = objRead.ReadFilter(objParams);

                objParams.SetParam("ifs_id", rsInterfInfo.Tables[0].Rows[0]["ifs_id"].ToString());
                objParams.SetParam("ifs_cd", rsInterfInfo.Tables[0].Rows[0]["ifs_cd"].ToString());
                objParams.SetParam("interface_def_path", objSettings.GetParam("interface_def_path"));

                strChannelDefFile = Path.Combine(objSettings.GetParam("interface_def_path"), rsInterfInfo.Tables[0].Rows[0]["ifc_def_file"].ToString());
                lngChannelID = Convert.ToInt32(rsInterfInfo.Tables[0].Rows[0]["ifc_id"]);
                objParams.SetParam("channel_id", lngChannelID.ToString());
                
                objParams.SetParam("ifc_id", lngChannelID.ToString());
                
                objParams.SetParam("jrn_id", vLngRunID.ToString());

                objParams.SetParam("where", "job_run_info");
                rsRead = ObjJobManagement.ReadFilter(objParams);
                objParams.SetParam("jsv_id", rsRead.Tables[0].Rows[0]["jsv_id"].ToString());

                if (Convert.ToString(rsRead.Tables[0].Rows[0]["jrn_jgp_run_id"]) + "" != "")
                {
                    
                    lngJobGrpRunId = Convert.ToInt32(rsRead.Tables[0].Rows[0]["jrn_jgp_run_id"]);
                    
                    objParams.SetParam("jrn_jgp_run_id", lngJobGrpRunId.ToString());
                    bJobGrpJob = false;
                }
                else
                {
                    bJobGrpJob = true;
                }

                // Get the job type of the job which can be used to determine if the job has to be
                // placed in the job_running_xml_related table.
                objParams.SetParam("where", "job_kind");
                rsJobType = ObjJobManagement.ReadFilter(objParams);
                if (!(rsJobType.Tables[0].Rows.Count == 0 && rsJobType.Tables[0].Rows.Count == 0))
                {
                    strJobKind = Convert.ToString(rsJobType.Tables[0].Rows[0]["jkd_cd"]).Trim().ToUpper();
                    if (strJobKind == "XML")
                    {
                        // Create a record in the job_running_xml_related table so the snapshot
                        // is aware of the XML job.
                        objParams.SetParam("where", "running_xml_related_job");
                        ObjManageXmlRelatedJobsModify.Insert(objParams);

                        // If a snapshot is running then don't start the XML job!
                        objManageXMLRelatedJobsRead = (PrismaGeneral.ICommonRead)ObjManageXmlRelatedJobsModify;
                        objParams.SetParam("where", "running_snapshot_jobs");
                        rsRunningSnapshots = objManageXMLRelatedJobsRead.ReadFilter(objParams);
                        if (!(rsRunningSnapshots.Tables[0].Rows.Count == 0 && rsRunningSnapshots.Tables[0].Rows.Count == 0))
                        {
                            throw new System.Exception((9999).ToString() + ", XML Job stopped because snapshot is running.");
                        }
                    }
                }

                rsJobType = null;

                //Read Channel definition file
                objChannelDefRoot = modXMLSupport.FCreateXmlDocumentFromUrl(strChannelDefFile);

                if (objChannelDefRoot == null)
                {
                    throw new System.Exception((9999).ToString() + ", IsDnaMsg, " + "The channel definition file [" + strChannelDefFile + "] could not be loaded.");
                }
                //Get the right channel definition from the file

                objChannelData = objChannelDefRoot.SelectSingleNode("CHANNEL[@id = " + lngChannelID.ToString() + "]");

                if (objChannelData == null)
                {
                    throw new System.Exception((9999).ToString() + ", IsDnaMsg, " + "The channel [" + lngChannelID.ToString() + "] does not exist in the channel definition file [" + strChannelDefFile + "].");
                }

                //Now we can process the steps in the channel
                //First log a message indicating we are starting to process the channel.
                ObjLogger.FLog(m_lngRunID, "Processing of channel " + lngChannelID.ToString() + " has started.");

                FProcessSteps(lngChannelID, objChannelData, objParams);

                ObjLogger.FLog(m_lngRunID, "Processing of channel " + lngChannelID.ToString() + " has finished.");

                strStatus = ObjJobStatus.FGetStatus(m_lngRunID).Trim().ToUpper();

                if (strStatus == "STARTED")
                {
                    ObjJobManager.FFinish(m_lngRunID);

                    if (!bJobGrpJob)
                    {
                        objParams.SetParam("where", "get_jobgroup_run_info");
                        rsRead = ObjJobManagement.ReadFilter(objParams);
                     
                        if (!(rsRead.Tables[0].Rows.Count == 0 && rsRead.Tables[0].Rows.Count == 0))
                        {
                            DataRow[] rsRead_rowFilter = rsRead.Tables[0].Select("jrn_status='STARTED' or jrn_status='WAITING'");

                            if (rsRead_rowFilter.Length == 0)
                            {
                                strStatus = ObjJobStatus.FGetStatus(lngJobGrpRunId).Trim().ToUpper();
                                if (!(strStatus == "ABORTING" || strStatus == "ABORTED" || strStatus == "FAILED" || strStatus == "ERRORS"))
                                {
                                    //Call objJobStatus.fSetStatus(lngJobGrpRunId, "FINISHED")
                                    ObjJobManager.FFinish(lngJobGrpRunId);
                                }
                                else
                                {
                                    if (strStatus == "ABORTING")
                                    {
                                        //Call objJobManager.fAbort(lngJobGrpRunId)
                                        ObjJobStatus.FSetStatus(lngJobGrpRunId, "ABORTED");
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (!bJobGrpJob)
                    {
                        if (strStatus == "ERRORS")
                        {
                            strStatus = ObjJobStatus.FGetStatus(lngJobGrpRunId).Trim().ToUpper();
                            if (strStatus != "ERRORS" && strStatus != "FAILED")
                            {
                                ObjJobStatus.FSetStatus(lngJobGrpRunId, "ERRORS");
                            }
                        }
                        else if (strStatus == "FAILED")
                        {
                            if (ObjJobStatus.FGetStatus(lngJobGrpRunId).Trim().ToUpper() != "FAILED")
                            {
                                //Call objJobStatus.fSetStatus(lngJobGrpRunId, "FAILED")
                                ObjJobManager.FFailed(lngJobGrpRunId);
                            }
                        }
                        else if (strStatus == "ABORTING")
                        {
                            objParams.SetParam("where", "get_jobgroup_run_info");
                            rsRead = ObjJobManagement.ReadFilter(objParams);
                          
                            if (!(rsRead.Tables[0].Rows.Count == 0 && rsRead.Tables[0].Rows.Count == 0))
                            {
                                DataRow[] rsRead_rowFilter = rsRead.Tables[0].Select("jrn_status='STARTED' or jrn_status='WAITING'");

                                if (rsRead_rowFilter.Length == 0)
                                {
                                    ObjJobManager.FAbort(lngJobGrpRunId);
                                    ObjJobManager.FFailed(lngJobGrpRunId);
                                }
                            }
                        }
                    }
                }

                if (strJobKind == "XML")
                {
                    // Delete the record from the job_running_xml_related table of the current job.
                    //string tempRefParam17 = "running_xml_related_job";
                    objParams.SetParam("where", "running_xml_related_job");
                    ObjManageXmlRelatedJobsModify.Delete(objParams);
                }
                ContextUtil.SetComplete();
            }
            catch (System.Exception excep)
            {

                if (strJobKind == "XML")
                {
                    // Delete the record from the job_running_xml_related table of the current job.
                    objParams.SetParam("where", "running_xml_related_job");
                    ObjManageXmlRelatedJobsModify.Delete(objParams);
                }

                strStatus = ObjJobStatus.FGetStatus(m_lngRunID).Trim().ToUpper();

                //Call App.LogEvent("bJobGrpJob=" & bJobGrpJob)
                //Call App.LogEvent("strStatus=" & strStatus)
                //Call App.LogEvent("objJobStatus.fGetStatus(lngJobGrpRunId)" & objJobStatus.fGetStatus(lngJobGrpRunId))

                if (!bJobGrpJob)
                {
                    if (strStatus == "ABORTING")
                    {
                        objParams.SetParam("where", "get_jobgroup_run_info");
                        rsRead = ObjJobManagement.ReadFilter(objParams);
                      
                        if (!(rsRead.Tables[0].Rows.Count == 0 && rsRead.Tables[0].Rows.Count == 0))
                        {
                            DataRow[] rsRead_rowFilter = rsRead.Tables[0].Select("jrn_status='STARTED' or jrn_status='WAITING'");

                            if (rsRead_rowFilter.Length == 0)
                            {
                                ObjJobManager.FAbort(lngJobGrpRunId);
                                ObjJobManager.FFailed(lngJobGrpRunId);
                            }
                        }
                    }
                    else
                    {
                        if (ObjJobStatus.FGetStatus(lngJobGrpRunId).Trim().ToUpper() != "FAILED")
                        {
                            ObjJobManager.FFailed(lngJobGrpRunId);
                        }
                    }
                }

                if (strStatus == "ABORTING")
                {
                    ObjLogger.FLog(m_lngRunID, "Processing of channel " + lngChannelID.ToString() + " has aborted.");
                }
                else
                {
                    ObjLogger.FLog(m_lngRunID, "Processing of channel " + lngChannelID.ToString() + " has failed.");
                    ObjLogger.FLog(m_lngRunID, "Error " + 0 + ": " + excep.Message);
                }

                ObjJobManager.FFailed(m_lngRunID);

                if (strStatus == "ABORTING")
                {
                }
                else
                {
                    ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                    ContextUtil.SetAbort();
                    throw new System.Exception(0 + ", " + excep.Source + ", " + excep.Message + ", " + excep.HelpLink + ", " + excep.TargetSite);
                }
            }
            finally
            {
                objChannelDefRoot = null;
                objChannelData = null;

                if (rsInterfInfo != null) rsInterfInfo.Dispose();
                if (rsRead != null) rsRead.Dispose();
                if (rsJobType != null) rsJobType.Dispose();
                if (rsRunningSnapshots != null) rsRunningSnapshots.Dispose();

                if (objSettings != null) ((IDisposable)objSettings).Dispose();
                if (objRead != null) ((IDisposable)objRead).Dispose();
                if (objParams != null) ((IDisposable)objParams).Dispose();
                if (objManageXMLRelatedJobsRead != null) ((IDisposable)objManageXMLRelatedJobsRead).Dispose();
            }
        }

        private void FProcessSteps(long vLngChannelID, XmlNode vObjChannelData, PrismaGeneral.IParamSource vObjParams)
        {
            XmlNodeList objSteps;
            XmlNodeList objGroups;
            XmlNode objGroup;
            IsDNAImportTypelib.IStepProcessor objStepProcessor = null;
            try
            {
                //XmlNode objStep;
                objStepProcessor = null;
                string strData = String.Empty;
                string strUseTransaction = String.Empty;
                string strOldTx = String.Empty;

                // Get step groups
                objGroups = vObjChannelData.SelectNodes("GROUP");

                if (objGroups.Count == 0)
                {
                    //No groups are defined so use a transaction for all steps
                    //Set objSteps = v_objChannelData.selectNodes("*")
                    objSteps = vObjChannelData.SelectNodes("STEP|IF|LOOP");

                    objStepProcessor = (IsDNAImportTypelib.IStepProcessor)new C93Control.clsTxTransaction();
                    objStepProcessor.FProcessSteps(vLngChannelID, objSteps, vObjParams, (IsDnaJobManagement.IJobLogger)this);
                }
                else
                {
                    foreach (XmlNode objGroup2 in objGroups)
                    {
                        objGroup = objGroup2;
                        strUseTransaction = modXMLSupport.FGetNodeText(objGroup, "@transaction").ToLower();
                        if (String.IsNullOrEmpty(strUseTransaction)) 
                        {
                            strUseTransaction = "yes";
                        }
                        if (strUseTransaction != strOldTx)
                        {
                            switch (strUseTransaction)
                            {
                                case "no":
                                    objStepProcessor = (IsDNAImportTypelib.IStepProcessor)new C93Control.clsTxNoTransaction();
                                    break;
                                case "yes":
                                    objStepProcessor = (IsDNAImportTypelib.IStepProcessor)new C93Control.clsTxTransaction();
                                    break;
                            }
                            strOldTx = strUseTransaction;
                        }
                        objSteps = objGroup.SelectNodes("STEP|IF|LOOP");

                         objStepProcessor.FProcessSteps(vLngChannelID, objSteps, vObjParams, (IsDnaJobManagement.IJobLogger)this);
                    }
                }
                ContextUtil.SetComplete();
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (objStepProcessor != null) ((IDisposable)objStepProcessor).Dispose();
                objSteps = null;
                objGroups = null;
                objGroup = null;
            }
        }

        //IJobLogger ========================================================================================
        private void FIncreaseCounter(long vLngRunID, long vLngCounterID, long vLngAmount)
        {
            ObjLogger.FIncreaseCounter(m_lngRunID, vLngCounterID, vLngAmount);
        }

        private void FLog(long vLngRunID, string vStrLogMsg)
        {
            ObjLogger.FLog(m_lngRunID, vStrLogMsg);
        }

        private void FSetCounter(long vLngRunID, long vLngCounterID, long vLngValue)
        {
            ObjLogger.FSetCounter(m_lngRunID, vLngCounterID, vLngValue);
        }

        #region IJobControl2 Members

        void IsDnaJobManagement.IJobControl2.FStart(string vStrJobUid, long vLngRunID, IParamSource vObjParams)
        {
            FStart(vStrJobUid, vLngRunID, vObjParams);
        }

        #endregion

        #region IJobLogger Members

        void IsDnaJobManagement.IJobLogger.FIncreaseCounter(long vLngRunID, long vLngCounterID, long vLngAmount)
        {
            FIncreaseCounter(vLngRunID, vLngCounterID, vLngAmount);
        }

        void IsDnaJobManagement.IJobLogger.FLog(long vLngRunID, string vStrLogMsg)
        {
            FLog(vLngRunID, vStrLogMsg);
        }

        void IsDnaJobManagement.IJobLogger.FSetCounter(long vLngRunID, long vLngCounterID, long vLngValue)
        {
            FSetCounter(vLngRunID, vLngCounterID, vLngValue);
        }

        #endregion

        #region System.EnterpriseServices.ServicedComponent Members
        protected override void Activate()
        {
            base.Activate();
            //m_objLogger = null;
            //m_objJobManager = null;
            //m_objManageXMLRelatedJobs = null;
        }
        protected override bool CanBePooled()
        {
            return true;
        }
        protected override void Deactivate()
        {
            //if (m_objLogger != null) ((IDisposable)m_objLogger).Dispose();
            //if (m_objJobManager != null) ((IDisposable)m_objJobManager).Dispose();
            //if (m_objManageXMLRelatedJobs != null) ((IDisposable)m_objManageXMLRelatedJobs).Dispose();
            base.Deactivate();
        }
        #endregion
    }
}
