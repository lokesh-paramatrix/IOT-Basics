using System; 

namespace C93Control
{
    public class clsErrorHelper
    {
        //private string m_strSource = String.Empty;
        //private string m_strMessage = String.Empty;
        //private string m_strHelpContext = String.Empty;
        //private string m_strHelpFile = String.Empty;

        public void FSaveErrorObject(Exception vObjException)
        {
            //m_strSource = vObjException.Source;
            //m_strMessage = vObjException.Message;
            //m_strHelpContext = vObjException.TargetSite.ToString();
            //m_strHelpFile = vObjException.HelpLink;
        }

        public void FRestoreErrorObject(Exception rObjException)
        {
            //rObjException.Number = m_lngNumber;
            //rObjException.Message = m_strMessage;
            //rObjException.Source = m_strSource;
            //rObjException.TargetSite = m_strHelpContext;
            //rObjException.HelpLink = m_strHelpFile;
        }
    }
}
