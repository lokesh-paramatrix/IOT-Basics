using System;
using System.Data;
using System.Collections;
using System.Runtime.InteropServices;
using System.EnterpriseServices;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;
using PrismaGeneral;

namespace C93Control
{
    [Transaction(TransactionOption.Supported)]
    [JustInTimeActivation(true)]
    [EventTrackingEnabled(true)] 
    [ProgId("C93Control.clsJobProvider")]
    [ClassInterface(ClassInterfaceType.AutoDual)]

    public class clsJobProvider
        : System.EnterpriseServices.ServicedComponent, IsDnaJobManagement.IJobProvider
    {
        //**********************************************************
        // Implementation of ObjectControl Interface
        // Default implementaion using abstract object context
        //**********************************************************

        private DataSet FGetAllJobs()
        {
            DataSet result = null;
            PrismaGeneral.ICommonRead objRead = null;
            PrismaGeneral.IParamSource objParam = null;

            try
            {
                objRead = (PrismaGeneral.ICommonRead)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC93BS.clsInterfacingSystem"));
                objParam = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));

                objParam.SetParam("where", "c_job_provider");

                result = objRead.ReadFilter(objParam);

                ContextUtil.SetComplete();

                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (result != null) result.Dispose();
                if (objRead != null) ((IDisposable)objRead).Dispose();
                if (objParam != null) ((IDisposable)objParam).Dispose();
            }
        }

        private DataSet FGetScheduledJobs()
        {
            throw new System.Exception(Prismaconst.E_NOT_IMPL.ToString());
        }

        private bool FProvidesJob(string vStrJobUid)
        {
            bool result = false;
            PrismaGeneral.ICommonRead objRead = null;
            DataSet rsResult = null;
            PrismaGeneral.IParamSource objParam = null;

            try
            {
                objRead = (PrismaGeneral.ICommonRead)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC93BS.clsInterfacingSystem"));
                objParam = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));

                objParam.SetParam("where", "c_job_exists");
                objParam.SetParam("ifc_guid", vStrJobUid);

                rsResult = objRead.ReadFilter(objParam);

                result = !(rsResult.Tables[0].Rows.Count == 0 && rsResult.Tables[0].Rows.Count == 0);

                ContextUtil.SetComplete();

                return result;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (rsResult != null) rsResult.Dispose();
                if (objRead != null) ((IDisposable)objRead).Dispose();
                if (objParam != null) ((IDisposable)objParam).Dispose();
            }
        }

        #region IJobProvider Members

        DataSet IsDnaJobManagement.IJobProvider.FGetAllJobs()
        {
            return FGetAllJobs();
        }

        DataSet IsDnaJobManagement.IJobProvider.FGetScheduledJobs()
        {
            return FGetScheduledJobs();
        }

        bool IsDnaJobManagement.IJobProvider.FProvidesJob(string vStrJobUid)
        {
            return FProvidesJob(vStrJobUid);
        }

        #endregion

        #region System.EnterpriseServices.ServicedComponent Members
        protected override void Activate()
        {
            base.Activate();
        }
        protected override bool CanBePooled()
        {
            return true;
        }
        protected override void Deactivate()
        {
            base.Deactivate();
        }
        #endregion

    }
}