using System; 
using System.IO; 
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using System.EnterpriseServices;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;
using PrismaGeneral;

namespace C93Control
{
    [Transaction(TransactionOption.Supported)]
    [JustInTimeActivation(true)]
    [EventTrackingEnabled(true)]
    [ProgId("C93Control.clsStepProcessor")]
    [ClassInterface(ClassInterfaceType.AutoDual)]

    public class clsStepProcessor
        : System.EnterpriseServices.ServicedComponent, IsDNAImportTypelib.IStepProcessor
    {
        private IsDnaJobManagement.IJobLogger m_objLogger;
        private IsDnaJobManagement.IJobStatus m_objJobStatus;
        private string m_strResult;

        private IsDnaJobManagement.IJobStatus objJobStatus
        {
            get
            {
                if (m_objJobStatus == null)
                {
                    m_objJobStatus = (IsDnaJobManagement.IJobStatus)Activator.CreateInstance(Type.GetTypeFromProgID("IsDNAJobMgt.clsJobManager"));
                }
                return m_objJobStatus;
            }
        }

        private void FProcessSteps(long v_lngChannelID, XmlNodeList v_objSteps, PrismaGeneral.IParamSource v_objParams, IsDnaJobManagement.IJobLogger v_objLogger)
        {
            //XmlNode objStep;
            try
            {
                //IsDNAImportTypelib.IGenericStep objBooleanStep;
                string strData;
                //IsDnaXml.IXmlParamSource objXMLParam;

                m_objLogger = v_objLogger;

                strData = "";
                
                // Process every step and use output data from one step as input data for the next step
                FProcessSteps(strData, v_lngChannelID, v_objSteps, v_objParams);

                ContextUtil.SetComplete();
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
        }

        private string FProcessSteps(string v_strData, long v_lngChannelID, XmlNodeList v_objSteps, PrismaGeneral.IParamSource v_objParams)
        {
            IsDNAImportTypelib.IGenericStep objBooleanStep = null;

            try
            {
                XmlNode objStep;
                
                string strData = String.Empty;
                IsDnaXml.IXmlParamSource objXMLParam;
                string strProgID = String.Empty;
                string strTest = String.Empty;
                bool bResult = false;
                string strResult = String.Empty;
                //PrismaGeneral.IParamSource objSettings;
                bool fPeekMsg = false;
                XmlNodeList objHulpSteps;
                string strCurrentJobRunStatus = String.Empty;

                // Retrieve steps from channel data
                if (v_objSteps.Count == 0)
                {
                    throw new System.Exception((9999).ToString() + ", IsDnaMsg, " + "There are no steps defined for channel [" + v_lngChannelID.ToString() + "].");
                }

                strData = v_strData;

                // Process every step and use output data from one step as input data for the next step
                foreach (XmlNode objStep2 in v_objSteps)
                {
                    objStep = objStep2;
                    strCurrentJobRunStatus = objJobStatus.FGetStatus(Convert.ToInt32(v_objParams.GetParam("jrn_id"))).Trim().ToUpper();
                    if (strCurrentJobRunStatus == "ABORTING")
                    {
                        throw new System.Exception((9999).ToString() + ", Job aborted by other process.");
                    }

                    //This is to enable a loop to stop the current file processing and start the next one

                    if (Convert.ToString(v_objParams.GetParam("__StopThisIteration")) == "true")
                    {
                        v_objParams.SetParam("__StopThisIteration", "false");
                        break;
                    }

                    if (objStep.Name == "IF" || objStep.Name == "WHEN")
                    {
                        strTest = modXMLSupport.FGetNodeText(objStep, "@test");
                        if (strTest != "")
                        {
                            strProgID = modXMLSupport.FGetNodeText(objStep, "@progid");
                            if (strProgID != "")
                            {
                                objBooleanStep = (IsDNAImportTypelib.IGenericStep)Activator.CreateInstance(Type.GetTypeFromProgID(strProgID, true));
                                strResult = objBooleanStep.FProcessData(strData, v_objParams, null, m_objLogger);
                                bResult = (strResult == strTest);
                                if (objBooleanStep != null)
                                {
                                    ((IDisposable)objBooleanStep).Dispose();
                                    objBooleanStep = null;
                                }
                            }
                            else if (modXMLSupport.FGetNodeText(objStep, "@type").ToLower() == "xslt")
                            {
                                AddPrismaSettings(objStep.SelectSingleNode("STEP"));
                                bResult = objStep.SelectSingleNode(strTest) != null;
                            }
                            else if (modXMLSupport.FGetNodeText(objStep, "@type").ToLower() == "environment")
                            {
                                AddPrismaSettings(objStep.SelectSingleNode("STEP"));
                                bResult = objStep.SelectSingleNode("STEP/PRISMA-SETTINGS/SETTING[@name='environment' and text() = '" + strTest + "']") != null;
                            }
                            else
                            {
                                objXMLParam = (IsDnaXml.IXmlParamSource)v_objParams;
                                bResult = objXMLParam.FGetXmlNode().SelectSingleNode("/PARAMSOURCE[" + strTest + "]") != null;
                            }
                            if (bResult)
                            {
                                m_strResult = FProcessSteps(strData, v_lngChannelID, objStep.SelectNodes("*"), v_objParams);
                                strData = m_strResult;
                            }
                        }
                        else
                        {
                            throw new System.Exception((9999).ToString() + ", IsDnaMsg, No test condition is provided.");
                        }
                    }
                    else if (objStep.Name == "LOOP")
                    {
                        do
                        {
                            v_objParams.SetParam("_peek", "true");

                            objHulpSteps = objStep.SelectNodes("IF");
                            if (objHulpSteps.Count == 0)
                            {
                                strTest = FProcessSteps(strData, v_lngChannelID, objStep.SelectNodes("*[1]"), v_objParams);
                            }
                            else
                            {
                                strTest = FProcessSteps(strData, v_lngChannelID, objStep.SelectNodes("IF"), v_objParams);
                            }
                            fPeekMsg = Boolean.Parse((strTest == "") ? "false" : strTest);


                            v_objParams.SetParam("_peek", "false");

                            if (fPeekMsg)
                            {
                                m_strResult = FProcessSteps(strData, v_lngChannelID, objStep.SelectNodes("*"), v_objParams);
                                strData = m_strResult;

                                // If after processing one file the status is set to aborted by another
                                // process stop the processing of the job.
                                //UPGRADE_WARNING: (1068) v_objParams.GetParam() of type Variant is being forced to long.
                                strCurrentJobRunStatus = objJobStatus.FGetStatus(Convert.ToInt32(v_objParams.GetParam("jrn_id"))).Trim().ToUpper();
                                if (strCurrentJobRunStatus == "ABORTING")
                                {
                                    throw new System.Exception((9999).ToString() + ", Job aborted by other process.");
                                }
                            }
                        }
                        while (fPeekMsg);
                    }
                    else if (objStep.Name == "CASE")
                    {
                        m_strResult = FProcessSteps(strData, v_lngChannelID, objStep.SelectNodes("*"), v_objParams);
                        strData = m_strResult;
                    }
                    else
                    {
                        m_strResult = FProcessSingleStep(strData, v_lngChannelID, objStep, v_objParams);
                        strData = m_strResult;
                        //UPGRADE_WARNING: (1068) v_objParams.GetParam(__VALIDATE_ERROR) of type Variant is being forced to string.
                        if (Convert.ToString(v_objParams.GetParam("__VALIDATE_ERROR")) == "TRUE")
                        {
                            v_objParams.SetParam("__VALIDATE_ERROR", "FALSE");
                            break;
                        }
                    }
                }

                objStep = null;

                ContextUtil.SetComplete();
                return strData;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (objBooleanStep != null) ((IDisposable)objBooleanStep).Dispose();
            }
        }

        private void AddPrismaSettings(XmlNode v_objParentNode)
        {
            PrismaGeneral.IParamSource objSettings = null;
            PrismaGeneral.IParamSource objSettingsCopy = null;
            IsDnaXml.IXmlParamSource objXMLParam = null;

            try
            {
                XmlNode objSettingNode;

                objSettings = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));
                objSettingsCopy = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                objSettings.CopyParams(objSettingsCopy);
                objXMLParam = (IsDnaXml.IXmlParamSource)objSettingsCopy;

                XmlNode objPrismaSettingsNode = (XmlNode)v_objParentNode.OwnerDocument.CreateElement("PRISMA-SETTINGS");
                v_objParentNode.AppendChild(objPrismaSettingsNode);
                foreach (XmlNode objAttr in objXMLParam.FGetXmlNode().SelectNodes("@*"))
                {
                    objSettingNode = (XmlNode)v_objParentNode.OwnerDocument.CreateElement("SETTING");
                    modXMLSupport.FCreateAttribute(objSettingNode, "name", objAttr.Name);
                    objSettingNode.InnerText = objAttr.InnerText;
                    objPrismaSettingsNode.AppendChild(objSettingNode);
                }
                ContextUtil.SetComplete();
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (objSettings != null) ((IDisposable)objSettings).Dispose();
                if (objSettingsCopy != null) ((IDisposable)objSettingsCopy).Dispose();
            }
        }

        private string FProcessSingleStep(string v_strData, long v_lngChannelID, XmlNode v_objStep, PrismaGeneral.IParamSource v_objParams)
        {
            XmlNode objComponentData;
           
            IsDNAImportTypelib.IGenericStep objStep = null;
            IsDNAImportTypelib.IComponentDataSupplier objDynData = null;

            try
            {
                string strType = String.Empty;
                long lngStepNr = 0;
                string strProgID = String.Empty;
                XmlNode objComponentNode;
                XmlNode objNode;
                string strData = String.Empty;
                XmlNodeList objDynDataNodes;
                string strDataProgID = String.Empty;
                string strPath = String.Empty;
                //FileSystemObject objFS;

                //objFS = null;
                objComponentNode = v_objStep.SelectSingleNode("COMPONENT");

                lngStepNr = Int32.Parse(modXMLSupport.FGetNodeText(v_objStep, "@number"));
                strType = modXMLSupport.FGetNodeText(objComponentNode, "@type").Trim().ToLower();
                strProgID = modXMLSupport.FGetNodeText(objComponentNode, "@progid").Trim();

                objComponentData = objComponentNode.SelectSingleNode("COMPONENT-DATA");

                if (objComponentData != null)
                {
                    objDynDataNodes = objComponentData.SelectNodes("DYNAMIC-DATA");
                    foreach (XmlNode objDataNode in objDynDataNodes)
                    {
                        strDataProgID = modXMLSupport.FGetNodeText(objDataNode, "@progid");
                        if (strDataProgID == "")
                        {
                            throw new System.Exception((+9999).ToString() + ", IsDnaMsg, " + "There is no progid specified for a dynamic data component for step [" + lngStepNr.ToString() + "] in channel [" + v_lngChannelID.ToString() + "].");
                        }
                        objDynData = (IsDNAImportTypelib.IComponentDataSupplier)Activator.CreateInstance(Type.GetTypeFromProgID(strDataProgID));
                        objDynData.FGetComponentData(ref objComponentData, v_objParams);
                        
                        if (objDynData != null)
                        {
                            ((IDisposable)objDynData).Dispose();
                            objDynData = null;
                        }
                    }
                }
                else
                {
                    objComponentData = (XmlNode)v_objStep.OwnerDocument.CreateElement("COMPONENT-DATA");
                    objComponentNode.AppendChild(objComponentData);
                }

                // Adding prisma settings to component data
                AddPrismaSettings(objComponentData);

                //Add root directory for interfaces to Address node
                if (strType == "transport")
                {
                    objNode = objComponentData.SelectSingleNode("ADDRESS");
//                    if (objNode != null)
                    if (objNode != null && !String.IsNullOrEmpty(objNode.InnerText)) //Sarfaraz
                    {

                        //if (objFS.GetDriveName(objNode.Value).Length == 0) Avdhut Vaidya
                        //if (Path.GetPathRoot(objNode.Value).Length == 0) //Avdhut Vaidya //Sarfaraz
                        if (Path.GetPathRoot(objNode.InnerText).Length == 0) //Sarfaraz
                        {
                            strPath = Path.Combine(modXMLSupport.FGetNodeText(objComponentData, "PRISMA-SETTINGS/SETTING[@name='interface_root_path']"), objNode.InnerText);
                            //strPath = Replace(strPath, "\\", "\")
                            //MSXMLHelper.SetNodeTypedValue(objNode, strPath);
                            objNode.InnerText = strPath;
                            //Call App.LogEvent("Address: " & strPath)
                        }
                    }

                    objNode = objComponentData.SelectSingleNode("BACKUP-DIR");
                    if (objNode != null)
                    {

                        //if (objFS.GetDriveName(objNode.Value).Length == 0) Avdhut Vaidya
                        //if (Path.GetPathRoot(objNode.Value).Length == 0) //Avdhut Vaidya //Sarfaraz
                        if (Path.GetPathRoot(objNode.InnerText).Length == 0) //Sarfaraz
                        {
                            strPath = Path.Combine(modXMLSupport.FGetNodeText(objComponentData, "PRISMA-SETTINGS/SETTING[@name='interface_root_path']"), objNode.InnerText);
                            //strPath = Replace(strPath, "\\", "\")
                            //MSXMLHelper.SetNodeTypedValue(objNode, strPath);
                            objNode.InnerText = strPath;
                        }
                    }
                    //Call App.LogEvent("Backup: " & strPath)
                    //Call App.LogEvent("New address: " & fGetNodeText(objComponentData, "PRISMA-SETTINGS/SETTING[@name='interface_root_path']") & "\" & objNode.nodeTypedValue)
                }

                v_objParams.SetParam("step_nr", lngStepNr.ToString());

                if (strProgID == "")
                {
                    throw new System.Exception((9999).ToString() + ", IsDnaMsg, " + "There is no progid specified for step [" + lngStepNr.ToString() + "] in channel [" + v_lngChannelID.ToString() + "].");
                }

                objStep = (IsDNAImportTypelib.IGenericStep)Activator.CreateInstance(Type.GetTypeFromProgID(strProgID));

                if (strType == "process")
                {
                    FProcessRecords(v_strData, objStep, objComponentData, v_objParams);
                }
                else if (strType == "simple_process" || strType == "validate")
                {
                    m_strResult = FProcessMessageStep(objStep, v_strData, objComponentData, v_objParams);
                    strData = m_strResult;
                }
                else
                {
                    m_strResult = objStep.FProcessData(v_strData, v_objParams, objComponentData, m_objLogger);
                    strData = m_strResult;
                }

                ContextUtil.SetComplete();
                return strData;
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (objStep != null) ((IDisposable)objStep).Dispose();
                objComponentData = null;
            }
        }

        private void FProcessRecords(string v_strRecords, IsDNAImportTypelib.IGenericStep v_objStep, XmlNode v_objComponentData, PrismaGeneral.IParamSource v_objParams)
        {
            XmlNode objRecords;
            XmlNodeList objRecordNodes;

            try
            {
                objRecords = modXMLSupport.FCreateXmlDocumentFromString(v_strRecords);

                // For each top-level record a processor must be called
                objRecordNodes = objRecords.SelectNodes("RECORD");
                //Set objProcessor = m_objAbstrObjectContext.CreateInstance(v_strProgID)
                foreach (XmlNode objRecord in objRecordNodes)
                {
                    // Log information from record
                    FLogRecord(objRecord);
                    // Call the processor to process the record
                    FCallProcessor(v_objStep, objRecord.OuterXml, v_objComponentData, v_objParams);
                }

                objRecordNodes = null;
                objRecords = null;

                ContextUtil.SetComplete();
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
        }

        private void FCallProcessor(IsDNAImportTypelib.IGenericStep v_objStep, string v_strRecord, XmlNode v_objComponentData, PrismaGeneral.IParamSource v_objParams)
        {
            try
            {
                v_objStep.FProcessData(v_strRecord, v_objParams, v_objComponentData, m_objLogger);

                ContextUtil.SetComplete();
            }
            catch (System.Exception excep)
            {
                // save error object
                clsErrorHelper objErrorHelper = new clsErrorHelper();
                objErrorHelper.FSaveErrorObject(excep);

                // log in joblog
                //UPGRADE_WARNING: (1041) Err.Number has a new behavior.
                m_objLogger.FLog(Prismaconst.MsgCurrentJobRun, "Processing of record failed. The following error occured: [" + 0 + "] " + excep.Message);

                // restore original error
                objErrorHelper.FRestoreErrorObject(excep);

                // log in errorlog
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
            }
        }

        private string FProcessMessageStep(IsDNAImportTypelib.IGenericStep v_objStep, string v_strData, XmlNode v_objComponentData, PrismaGeneral.IParamSource v_objParams)
        {
            string result = String.Empty;
            try
            {
                result = v_objStep.FProcessData(v_strData, v_objParams, v_objComponentData, m_objLogger);

                ContextUtil.SetComplete();
                return result;
            }
            catch (System.Exception excep)
            {

                // save error object
                clsErrorHelper objErrorHelper = new clsErrorHelper();
                objErrorHelper.FSaveErrorObject(excep);

                // log in joblog
                //UPGRADE_WARNING: (1041) Err.Number has a new behavior.
                m_objLogger.FLog(Prismaconst.MsgCurrentJobRun, "Processing of Step failed. The following error occured: [" + 0 + "] " + excep.Message);

                // restore original error
                objErrorHelper.FRestoreErrorObject(excep);

                // log in errorlog
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                v_objParams.SetParam("__VALIDATE_ERROR", "TRUE");
                return result;
            }
        }

        private void FLogRecord(XmlNode v_objRecord)
        {

#if TRACE
					
					//UPGRADE_TODO: (1035) #If #EndIf block was not upgraded because the expression TRACE did not evaluate to True or was not evaluated.
					//* DEBUG *
					LogError ("[C93Control:clsStepProcessor:fLogRecord], START FUNCTION");
#endif
            XmlNode objLogInfo;

            try
            {
                XmlNode objField;
                string strLogMessage = String.Empty;

                strLogMessage = "";
                objLogInfo = v_objRecord.SelectSingleNode("LOG");
                if (objLogInfo != null)
                {
                    foreach (XmlNode objLogItem in objLogInfo.ChildNodes)
                    {
                        switch (objLogItem.Name)
                        {
                            case "LOGTEXT":
                                strLogMessage = strLogMessage + objLogInfo.InnerText;
                                break;
                            case "LOGVALUE":
                                objField = v_objRecord.SelectSingleNode("FIELD[@name='" + objLogItem.SelectSingleNode("@field").InnerText + "']");
                                if (objField != null)
                                {
                                    strLogMessage = strLogMessage + modXMLSupport.FGetNodeText(objLogItem, "@caption");
                                    strLogMessage = strLogMessage + objField.InnerText;
                                }
                                objField = null;
                                break;
                        }
                        strLogMessage = strLogMessage + " ";
                    }
                    m_objLogger.FLog(Prismaconst.MsgCurrentJobRun, strLogMessage);
                }

                objLogInfo = null;

                ContextUtil.SetComplete();
#if TRACE
							
							//UPGRADE_TODO: (1035) #If #EndIf block was not upgraded because the expression TRACE did not evaluate to True or was not evaluated.
							//* DEBUG *
							LogError ("[C93Control:clsStepProcessor:fLogRecord], END FUNCTION");
#endif
            }

            catch (Exception excep)
            {
#if TRACE
            						
						            //UPGRADE_TODO: (1035) #If #EndIf block was not upgraded because the expression TRACE did not evaluate to True or was not evaluated.
						            //* DEBUG *
						            LogError ("[C93Control:clsStepProcessor:fLogRecord], START FUNCTION");
#endif
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
        }

        private void LogError(string swritestring)
        {
            FileStream fs = null;
            try
            {
                fs = File.Open(Prismaconst.gStrTracepath, FileMode.Append, FileAccess.Write);
                byte[] info = new UTF8Encoding(true).GetBytes(swritestring);
                fs.Write(info, 0, info.Length);

            }
            catch(IOException)
            {
                try
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                }
                catch (IOException) { }
            }
            finally
            {
                fs = null;
            }
        }

        #region IStepProcessor Members

        void IsDNAImportTypelib.IStepProcessor.FProcessSteps(long v_lngChannelID, XmlNodeList v_objSteps, IParamSource v_objParams, IsDnaJobManagement.IJobLogger v_objLogger)
        {
            FProcessSteps(v_lngChannelID, v_objSteps, v_objParams, v_objLogger);
        }

        #endregion

        #region System.EnterpriseServices.ServicedComponent Members
        protected override void Activate()
        {
            base.Activate();
        }
        protected override bool CanBePooled()
        {
            return true;
        }
        protected override void Deactivate()
        {
            base.Deactivate();
        }
        #endregion

    }
}