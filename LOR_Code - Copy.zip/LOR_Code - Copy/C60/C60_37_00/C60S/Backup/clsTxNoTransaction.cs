using System;
using System.Runtime.InteropServices;
using System.Xml;
using System.Text;
using System.IO;
using System.EnterpriseServices;
using Common;
using PrismaGeneral;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace C93Control
{
    [Transaction(TransactionOption.NotSupported)]
    [JustInTimeActivation(true)]
    [EventTrackingEnabled(true)]
    [ProgId("C93Control.clsTxNoTransaction")]
    [ClassInterface(ClassInterfaceType.AutoDual)]

    public class clsTxNoTransaction
        : System.EnterpriseServices.ServicedComponent, IsDNAImportTypelib.IStepProcessor
    {
        private void FProcessSteps(long v_lngChannelID, XmlNodeList v_objSteps, PrismaGeneral.IParamSource v_objParams, IsDnaJobManagement.IJobLogger v_objLogger)
        {
            IsDNAImportTypelib.IStepProcessor objStepProcessor = null;
            try
            {

#if TRACE
							
							
							//* DEBUG *
							LogError ("[C93Control:clsTxNoTransaction:IStepProcessor_fProcessSteps], START FUNCTION");
#endif


#if TRACE
							
							
							//* DEBUG *
							LogError ("[C93Control:clsTxNoTransaction:IStepProcessor_fProcessSteps], START: create object objStepProcessor");
#endif
                objStepProcessor = (IsDNAImportTypelib.IStepProcessor)Activator.CreateInstance(Type.GetTypeFromProgID("C93Control.clsStepProcessor"));
#if TRACE
							
							
							//* DEBUG *
							LogError ("[C93Control:clsTxNoTransaction:IStepProcessor_fProcessSteps], END: create object objStepProcessor");
#endif

#if TRACE
							
							
							//* DEBUG *
							LogError ("[C93Control:clsTxNoTransaction:IStepProcessor_fProcessSteps], START: execute method fProcessSteps");
#endif
                objStepProcessor.FProcessSteps(v_lngChannelID, v_objSteps, v_objParams, v_objLogger);
#if TRACE
							
							
							//* DEBUG *
							LogError ("[C93Control:clsTxNoTransaction:IStepProcessor_fProcessSteps], END: execute method fProcessSteps");
#endif

                ContextUtil.SetComplete();

#if TRACE
							
							//* DEBUG *
							LogError ("[C93Control:clsTxNoTransaction:IStepProcessor_fProcessSteps], END FUNCTION");
#endif
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (objStepProcessor != null) ((IDisposable)objStepProcessor).Dispose();
            }
        }

        private void LogError(string swritestring)
        {
            FileStream fs = null;
            try
            {
                fs = File.Open(Prismaconst.gStrTracepath, FileMode.Append, FileAccess.Write);
                byte[] info = new UTF8Encoding(true).GetBytes(swritestring);
                fs.Write(info, 0, info.Length);
            }
            catch(IOException)
            {
                try 
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                }
                catch(IOException) { }
            }
            finally
            {
                fs = null;
            }
        }

        #region IStepProcessor Members

        void IsDNAImportTypelib.IStepProcessor.FProcessSteps(long v_lngChannelID, XmlNodeList v_objSteps, IParamSource v_objParams, IsDnaJobManagement.IJobLogger v_objLogger)
        {
            FProcessSteps(v_lngChannelID, v_objSteps, v_objParams, v_objLogger);
        }

        #endregion

        #region System.EnterpriseServices.ServicedComponent Members
        protected override void Activate()
        {
            base.Activate();
        }
        protected override bool CanBePooled()
        {
            return true;
        }
        protected override void Deactivate()
        {
            base.Deactivate();
        }
        #endregion

    }
}