using System; 
using System.Runtime.InteropServices; 
using System.Xml;
using System.EnterpriseServices;
using Common;
using PrismaGeneral;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.IO;
using System.Text;

namespace C93Control
{
    [Transaction(TransactionOption.RequiresNew)]
    [JustInTimeActivation(true)]
    [EventTrackingEnabled(true)]
    [ProgId("C93Control.clsTxTransaction")]
    [ClassInterface(ClassInterfaceType.AutoDual)]

    public class clsTxTransaction
        : System.EnterpriseServices.ServicedComponent, IsDNAImportTypelib.IStepProcessor
    {
        private void FProcessSteps(long v_lngChannelID, XmlNodeList v_objSteps, PrismaGeneral.IParamSource v_objParams, IsDnaJobManagement.IJobLogger v_objLogger)
        {
            IsDNAImportTypelib.IStepProcessor objStepProcessor = null;

            try
            {
                objStepProcessor = (IsDNAImportTypelib.IStepProcessor)new C93Control.clsStepProcessor();
                objStepProcessor.FProcessSteps(v_lngChannelID, v_objSteps, v_objParams, v_objLogger);

                ContextUtil.SetComplete();
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Prismaconst.LogOnlyPolicy);
                ContextUtil.SetAbort();
                throw;
            }
            finally
            {
                if (objStepProcessor != null) ((IDisposable)objStepProcessor).Dispose();
            }
        }

        private void LogError(string swritestring)
        {
            FileStream fs = null;
            try
            {
                fs = File.Open(Prismaconst.gStrTracepath, FileMode.Append, FileAccess.Write);
                byte[] info = new UTF8Encoding(true).GetBytes(swritestring);
                fs.Write(info, 0, info.Length);

            }
            catch(IOException)
            {
                try
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                }
                catch (IOException) { }
            }
            finally
            {
                fs = null;
            }
        }

        #region IStepProcessor Members

        void IsDNAImportTypelib.IStepProcessor.FProcessSteps(long v_lngChannelID, XmlNodeList v_objSteps, IParamSource v_objParams, IsDnaJobManagement.IJobLogger v_objLogger)
        {
            FProcessSteps(v_lngChannelID, v_objSteps, v_objParams, v_objLogger);
        }

        #endregion

        #region System.EnterpriseServices.ServicedComponent Members
        protected override void Activate()
        {
            base.Activate();
        }
        protected override bool CanBePooled()
        {
            return true;
        }
        protected override void Deactivate()
        {
            base.Deactivate();
        }
        #endregion

    }
}