﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using PRISMA.LOR2.FeedServiceFacade;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;
using System.Xml.XPath;
using PRISMA.LOR2.Common;

using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Configuration;
//using PRISMA.LOR2.Common.Interfaces;
using PrismaGeneral;
using PRISMA.LOR2.FeedServiceDefinition;
#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.BusinessFacade
{
    /// <summary>
    /// 
    /// </summary>
    public class BusinessFacade : IDisposable
    {
        #region Member variables
        #endregion Member variables

        #region Constructors

        public BusinessFacade()
        {
        }


        /// <summary>
        /// Gives a call to various FEEDs for a given Target Group
        /// </summary>
        /// <param name="objParamSource">
        /// The param source object should contain the following fields : jrn_id, job_id, publ_target_group_cd and optionally
        /// FeedNames list (FeedNames list - multiple entries should be seperated by pipe sign)
        /// </param>
        public BusinessFacade(IParamSource objParamSource)
        {
            //SQLHelper sql;

            DataSet dsLocales;
            DataSet dsTGnCHcode;
            DataSet dsLocaleCHcode;
            string[] feedNames;
            //Added by Arif for OEM and SPL catalog PR024
            string[] channelCodes = { "PROF", "OEM", "SPL" };



            FeedMessage feedMessage;
            feedMessage = new FeedMessage();

            feedMessage.JobRunID = Convert.ToInt32(objParamSource.GetParam("jrn_id"));
            feedMessage.JobID = new Guid(objParamSource.GetParam("job_id"));
            //feedMessage.TargetGroupCode = objParamSource.GetParam("publ_target_group_cd");

            //sql = new SQLHelper();
            dsLocales = ExecuteDataSet("sp_get_target_locales", "Prisma", objParamSource);
            //dsLocales = sql.ExecuteDataSet("sp_get_target_locales", objParamSource);
            dsTGnCHcode = ExecuteDataSet("sp_get_tg_channelcode", "Prisma", objParamSource);
            dsLocaleCHcode = ExecuteDataSet("sp_get_locale_channelcode", "Prisma", objParamSource);
            if (string.IsNullOrEmpty(objParamSource.GetParam("FeedName")))
            {

                feedNames = objParamSource.GetParam("FeedNames").Split(',');

                //if no feed name was passed from the paramsource, then take all feed names from config file
                if (objParamSource.GetParam("FeedNames") == "")
                {
                    feedNames = ConfigurationSettings.AppSettings[0].Split(',');
                }
            }
            else
                feedNames = objParamSource.GetParam("FeedName").Split(',');

            //Changed looping for solving categorisation double messages generation - Sarfaraz
            foreach (string feedName in feedNames)
            {
                feedMessage.FeedName = feedName.Trim();
                //Added if condition by Arif for OEM and SPL catalog PR024
                if ((feedMessage.FeedName == "Catalog") || (feedMessage.FeedName == "Categorisation"))
                {   
                    //foreach (DataRow drLocale in dsLocales.Tables[0].Rows)
                    foreach (DataRow drLocale in dsLocaleCHcode.Tables[0].Rows)
                    {

                            feedMessage.Locale = drLocale["Locale"].ToString();
                            feedMessage.ChannelCode = drLocale["channel_cd"].ToString().Trim();
                            feedMessage.TargetGroupCode = drLocale["publ_target_group_cd"].ToString();
                            feedMessage.Cmc_Locale = drLocale["cmc_Locale"].ToString(); //Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>
                            ProcessFeedRequest(feedMessage);

                    }
                }
                else
                {
                    foreach (DataRow drLocale in dsLocales.Tables[0].Rows)
                    {
                        feedMessage.Locale = drLocale["Locale"].ToString();
                        feedMessage.TargetGroupCode = objParamSource.GetParam("publ_target_group_cd");
                        feedMessage.Cmc_Locale = drLocale["cmc_Locale"].ToString(); //Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>
                        ProcessFeedRequest(feedMessage);

                    }
                }
            }


        }  
        

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods

        #region Avdhut : NOTE : The following function is not required it is handled directly by ProcessFeedRequest
        ///// <summary>
        ///// Processes the PMT feed request.
        ///// </summary>
        ///// <param name="feedNode">The feed node.</param>
        //private void ProcessPMTFeedRequest(XmlNode feedNode)
        //{
        //    FeedMessage feedMessage = new FeedMessage();
        //    feedMessage.FeedName = feedNode.SelectSingleNode("FeedName").InnerText;

        //    XmlNode locales = feedNode.SelectSingleNode("Locales");
        //    string[] localesArray = new string[locales.ChildNodes.Count];

        //    for (int childNodeCount = 0; childNodeCount < locales.ChildNodes.Count; childNodeCount++)
        //    {
        //        localesArray[childNodeCount] = locales.ChildNodes[childNodeCount].InnerText;
        //    }

        //    feedMessage.Locales = localesArray;
        //    serviceProxy.ProcessFeedMessage(feedMessage);
        //} 
        #endregion

        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Dispose managed resources
            }

            // Free native resources
        }

        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Processes the feed request.
        /// </summary>
        /// <param name="feedNode">The feed node.</param>
        public void ProcessFeedRequest(FeedMessage feedMessage)
        {
            string strFeedName;
            string tmpChannelCode;
            string tmpTargetGroup;
            IPMTFeedService serviceProxy;
            ICatFeedService catFeed;
            ICatFamFeedService catFamFeed;
            ICategFeedService categFeed;
            strFeedName = feedMessage.FeedName;
            //string[] strChannelCode = new string[] { "PROF", "OEM", "SPL" };
            IParamSource objParamSource = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
            DataSet dsTGnCHcode;
            dsTGnCHcode = ExecuteDataSet("sp_get_tg_channelcode", "Prisma", objParamSource);

            switch (strFeedName)
            {
                case "PMT":
                    serviceProxy = new PMTFeedServiceProxy(Constants.PMT_FEED_SERVICE_END_POINT);
                    serviceProxy.ProcessFeedMessage(feedMessage);
                    serviceProxy = null;
                    break;

                case "Asset":
                    //serviceProxy = new AssetFeedServiceProxy(Constants.ASSET_FEED_SERVICE_END_POINT);
                    //serviceProxy.ProcessFeedMessage(feedMessage);
                    break;

                ///////////////////////////////////////////////////////////////////////////////////////////
                case "Categorisation":
                    feedMessage.FeedName = Constants.FEEDNAME_CATEGORIZATION_WITH_PRODUCTS;
                    ProcessFeedRequest(feedMessage);
                    feedMessage.FeedName = Constants.FEEDNAME_CATEGORIZATION_WITHOUT_PRODUCTS;
                    ProcessFeedRequest(feedMessage);
                    break;
                case "CategorisationWithProducts":
                    categFeed = new CategFeedServiceProxy(Constants.CATEG_FEED_SERVICE_END_POINT);
                    tmpChannelCode = feedMessage.ChannelCode;
                    tmpTargetGroup = feedMessage.TargetGroupCode;
                    //foreach (string chcode in strChannelCode)
                    foreach (DataRow drChannelcode in dsTGnCHcode.Tables[0].Rows)
                    {
                        //feedMessage.ChannelCode = chcode;
                        feedMessage.ChannelCode = drChannelcode["channel_cd"].ToString().Trim();
                        feedMessage.TargetGroupCode = drChannelcode["actual_publ_target_group_cd"].ToString().Trim();
                        categFeed.ProcessFeedMessage(feedMessage);
                    }
                    feedMessage.ChannelCode = tmpChannelCode;
                    feedMessage.TargetGroupCode = tmpTargetGroup;
                    categFeed = null;
                    break;
                case "CategorisationWithoutProducts":
                    categFeed = new CategFeedServiceProxy(Constants.CATEG_FEED_SERVICE_END_POINT);
                    categFeed.ProcessFeedMessage(feedMessage);
                    categFeed = null;
                    break;
                ///////////////////////////////////////////////////////////////////////////////////////////
                case "Catalog":
                    catFeed = new CatFeedServiceProxy(Constants.CAT_FEED_SERVICE_END_POINT);
                    catFeed.ProcessFeedMessage(feedMessage);
                    catFeed = null;
                    break;

                case "CatFam":
                    System.Diagnostics.EventLog.WriteEntry(this.ToString(), "CATFam");
                    catFamFeed = new CatFamFeedServiceProxy(Constants.CATFAM_FEED_SERVICE_END_POINT);
                    catFamFeed.ProcessFeedMessage(feedMessage);
                    catFamFeed = null;
                    break;
                default:
                    break;
                    //throw new Exception("FEED TYPE NOT SUPPORTED");
            }
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        private DataSet ExecuteDataSet(string commandText, string RequiredDB, PrismaGeneral.IParamSource v_objParams)
        {
            SqlDatabase objExecSpFromPS = new SqlDatabase(RequiredDB);
            return objExecSpFromPS.ExecuteDataSet(commandText, v_objParams);
        }
        #endregion Public Methods
       
        #endregion Methods
    }
}
