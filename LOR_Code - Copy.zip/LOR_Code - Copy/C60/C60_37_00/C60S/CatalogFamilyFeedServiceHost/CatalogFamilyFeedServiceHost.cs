﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.ServiceModel;


using PRISMA.LOR2.Common;
using PRISMA.LOR2.Common.Logging.Logging;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;


namespace PRISMA.LOR2.CatalogFamilyFeedServiceHost
{
    public partial class CatalogFamilyFeedServiceHost : System.ServiceProcess.ServiceBase
    {
        private Logger logger;
        private ServiceHost catlogFamilyFeedServiceHost = null;

        //public CatalogFamilyFeedServiceHost()
        //{
        //    InitializeComponent();
        //}

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PMTFeedServiceHost"/> class.
        /// </summary>
        public CatalogFamilyFeedServiceHost()
        {
            InitializeComponent();
            logger = new Logger();
        }

        #endregion
        protected override void OnStart(string[] args)
        {
            try
            {
                logger.LogInfoMessage("CatalogFamilyFeedServiceHost - Start: void override void OnStart(string[] args).");

                if (catlogFamilyFeedServiceHost != null)
                {
                    catlogFamilyFeedServiceHost.Close();
                }

                //Create a ServiceHost for the PMTFeedService type and provide the base address.
                catlogFamilyFeedServiceHost = new ServiceHost(typeof(CatFamFeedService.CatFamFeedService));

                //Open the ServiceHostBase to create listeners and start listening for messages.
                catlogFamilyFeedServiceHost.Open();


                logger.LogInfoMessage("CatalogFamilyFeedServiceHost - End: void override void OnStart(string[] args).");
            }

            catch (Exception ex)
            {
                logger.LogErrorMessage(ex.Message + ":\r\n" + ex.StackTrace);
                catlogFamilyFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }
        }

        protected override void OnStop()
        {
            try
            {
                logger.LogInfoMessage("catlogFeedServiceHost - Start: void OnStop().");

                if (catlogFamilyFeedServiceHost != null)
                {
                    catlogFamilyFeedServiceHost.Close();
                    catlogFamilyFeedServiceHost = null;
                }

                logger.LogInfoMessage("catlogFeedServiceHost - End: void OnStop().");
            }

            catch (Exception ex)
            {
                catlogFamilyFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }

        }
    }
}