﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Xml;
using System.ServiceModel.MsmqIntegration;
using System.Threading;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using PrismaGeneral;
#endregion System

#region Custom
using PRISMA.LOR2.BLL;
using PRISMA.LOR2.Common;
using PRISMA.LOR2.FeedServiceDefinition;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;

using IsDnaJobManagement;
using IsDNAImportTypelib;
using System.Transactions;
using System.Collections;
using System.ServiceModel.Dispatcher;
using System.Messaging;
using System.Configuration;
using System.IO;
using System.Data;
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.CatFeedService
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class CatFeedService : FeedServiceBase.FeedServiceBase, ICatFeedService, IErrorHandler
    {
        static int iCounter;
        static Thread[] threads;
        static Thread threadHolder = null;
        static Stack<Thread> freeThreads = null;
        Dictionary<String, int> msgStatus = new Dictionary<String, int>();
        static Queue<FeedMessage> queCachedMessages;
        // PR021 Aman
        string strFullDestinationPathCatalog = string.Empty;
        // End
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        private delegate void CallCreateCatFeedXMLFile(IParamSource objParams);

        #endregion Member variables

        #region Constructors
        static CatFeedService()
        {
            try
            {
                queCachedMessages = new Queue<FeedMessage>();

                string maxThreads;
                maxThreads = ConfigurationManager.AppSettings["MaxThreads"];
                
                if (maxThreads == null)
                    maxThreads = "10";
                threads = new Thread[Convert.ToInt32(maxThreads)];
                
                freeThreads = new Stack<Thread>();

                foreach (Thread thread in threads)
                {
                    freeThreads.Push(thread);
                }
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                throw;
            }
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods

        /// <summary>
        /// Creates the PMT feed XML file.
        /// </summary>
        /// <param name="message">The message.</param>
        private string CreateCatFeedXMLFile(object feedMessage)
        {
            string strXMLFileName = "";
            string strXMLSchema = "";
            XmlNode objComponentData = null;
            IGenericStep xGen;
            IParamSource objParamSource = null;
            IParamSource objParamSettings = null;
            FeedMessage message = (FeedMessage)feedMessage;
            ComponentData compData = null;
            ICommonRead objLOR2Queries = null;
            DataSet dsCMCDetails = null;
            string strCountry = "";
            //Added by Arif for OEM and SPL catalog PR024
            string channel_cd = "";
            try
            {
                Logger.LogInfoMessage("START:CreateCatFeedXMLFile(FeedMessage message):TargetGroup:" + message.TargetGroupCode + " Locale:" + message.Locale);

                strXMLSchema = System.Configuration.ConfigurationManager.AppSettings["SchemaUrl"].ToString();

                objParamSource = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                objParamSettings = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));
                xGen = new PRISMA.LOR2.BLL.XMLGenerator();

                //country code will be characters after '_' eg en_GB - GB is Country
                //channel_cd added by Arif for OEM and SPL PR024
                try
                {
                    strCountry = message.Cmc_Locale.Split('_')[1];
                    //Added by Arif for OEM and SPL catalog
                    channel_cd = message.ChannelCode;
                }
                catch
                {
                    strCountry = "";
                }

                objParamSource.SetParam("xml_schema_name", strXMLSchema);
                objParamSource.SetParam("jrn_id", message.JobRunID.ToString());
                objParamSource.SetParam("locale", message.Locale);
                objParamSource.SetParam("publ_target_group_cd", message.TargetGroupCode);
                objParamSource.SetParam("FeedName", message.FeedName);
                objParamSource.SetParam("TargetGroupCode", message.TargetGroupCode);
                objParamSource.SetParam("cmc_locale", message.Cmc_Locale); //Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>

                //setting different possible values that can occur for variable name country
                objParamSource.SetParam("Country", strCountry);
                objParamSource.SetParam("CountryCd", strCountry);
                objParamSource.SetParam("Country_Cd", strCountry);
                objParamSource.SetParam("Country_Code", strCountry);
                //Added by Arif for OEM and SPL catalog PR024
                objParamSource.SetParam("channel_cd", channel_cd);
                objParamSource.SetParam("cmc_country_cd", strCountry);

                objLOR2Queries = new LOR2Queries();

                //log start time for the current job
                //objParamSource.SetParam("where", "log_locale_run_start_time");
                //objLOR2Queries.ReadFilter(objParamSource);
                //objParamSource.SetParam("where", "cmc-locale-details");
                //dsCMCDetails = objLOR2Queries.ReadFilter(objParamSource);
                //if (dsCMCDetails.Tables[0].Rows.Count < 1)
                //{
                //    objParamSource.SetParam("cmc_locale", message.Locale);
                //    objParamSource.SetParam("cmc_country_cd", strCountry);
                //}
                //else
                //{
                //    foreach (DataColumn dc in dsCMCDetails.Tables[0].Columns)
                //    {
                //        objParamSource.SetParam(dc.ColumnName, dsCMCDetails.Tables[0].Rows[0][dc].ToString());
                //    }
                //}//Commented by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>

                compData = new ComponentData(message.FeedName);
                compData.Create(ref objComponentData, objParamSource, 1);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress))
                {
                    strXMLFileName = xGen.FProcessData("", objParamSource, objComponentData, new clsJobLogger());
                }

                //get filesize
                long fileSize = FileHelper.FileSize(strXMLFileName);
                xGen = null;
                xGen = new BLL.clsXMLValidator();
                compData.Create(ref objComponentData, objParamSource, 2);
                strXMLFileName = xGen.FProcessData(strXMLFileName, objParamSource, objComponentData, new clsJobLogger());

                xGen = null;
                xGen = new BLL.BackupAndRestore();
                compData.Create(ref objComponentData, objParamSource, 3);
                xGen.FProcessData(strXMLFileName, objParamSource, objComponentData, new clsJobLogger());

                //log the file size of the extraction of the current locale run
                //long fileSize = FileHelper.FileSize(strXMLFileName);
                objParamSource.SetParam("file_size", fileSize.ToString());
                objParamSource.SetParam("where", "log_locale_run_file_size");
                objLOR2Queries.ReadFilter(objParamSource);

                //log end time for the current job
                objParamSource.SetParam("where", "log_locale_run_end_time");
                objLOR2Queries.ReadFilter(objParamSource);
                Logger.LogInfoMessage("END:CreateCatFeedXMLFile(FeedMessage message):TargetGroup:" + message.TargetGroupCode + " Locale:" + message.Locale);
            }
            catch (Exception excep)
            {
                objParamSource.SetParam("lrn_status", "FAILED");
                objParamSource.SetParam("where", "log_locale_run_status");
                objLOR2Queries.ReadFilter(objParamSource);
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                Logger.LogErrorMessage(excep.TargetSite.DeclaringType.ToString() + "." + excep.TargetSite.ToString() + ":" + excep.Message);
            }
            finally
            {
                if (objParamSource != null) ((IDisposable)objParamSource).Dispose();
                if (objParamSettings != null) ((IDisposable)objParamSettings).Dispose();
                compData = null;
            }

            return strXMLFileName;
        }


        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Processes the feed message.
        /// </summary>
        /// <param name="message">The message.</param>
        [OperationBehavior(TransactionScopeRequired = true)]
        public void ProcessFeedMessage(FeedMessage message)
        {
            Thread currThread = null;

            #region Issue PR021 - Aman

            string strDestinationPath = System.Configuration.ConfigurationManager.AppSettings["xml_destination_drive"].ToString();

            string strFileDestination = System.Configuration.ConfigurationManager.AppSettings["LOR2FolderStructure"].ToString();

            int count = strFileDestination.IndexOf("\"");

            int count1 = strFileDestination.IndexOf("\"", count + 1);

            string strLORFolderNameCatalog = strFileDestination.Substring(count + 1, count1 - count - 1);

            strFullDestinationPathCatalog = strDestinationPath + @"\" + strLORFolderNameCatalog + @"\" + message.TargetGroupCode + @"\" + message.FeedName;

            string strFileDestinationCatalog = strFullDestinationPathCatalog + @"\CONTENT-LOADED.xml";

            #endregion

            try
            {
                #region Threading Part

                if (freeThreads.Count > 0)
                {
                    currThread = freeThreads.Pop();
                }
                else
                {
                    //// if not vacant
                    queCachedMessages.Enqueue(message);
                    return;
                }

                // Changes for PR021 - Aman
                if (File.Exists(strFileDestinationCatalog))
                {
                    currThread = new Thread(new ParameterizedThreadStart(ThreadTask));
                    //start the thread.
                    currThread.Start(message);
                }
                #endregion //Threading Part
            }
            catch (Exception excep)
            {
                System.Diagnostics.Debug.Assert(excep.Message != "Maximum number of threads reached");
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                Logger.LogErrorMessage(excep.TargetSite.DeclaringType.ToString() + "." + excep.TargetSite.ToString() + ":" + excep.Message);
            }
        }
        private void ThreadTask(object feedMessage)
        {
            string strTempFileName;
            strTempFileName = CreateCatFeedXMLFile(feedMessage);

            while (queCachedMessages.Count > 0)
            {
                CreateCatFeedXMLFile(queCachedMessages.Dequeue());
            }

            freeThreads.Push(Thread.CurrentThread);

            #region Issue PR021 - Aman

            if (freeThreads.Count == Convert.ToInt32(ConfigurationManager.AppSettings["MaxThreads"]))
            {
                //string strFileDestination = System.Configuration.ConfigurationManager.AppSettings["Content_Ready_FileLocation"].ToString();

                //strFileDestination = strFileDestination + @"\CONTENT-READY.xml";

                string strFileDestination = strFullDestinationPathCatalog + @"\CONTENT-READY.xml";


                XmlDocument xDoc = new XmlDocument();

                // Create root node.   
                XmlElement xElemRoot = xDoc.CreateElement("CONTENT-READY");
                xElemRoot.InnerText = "The Feed is complete.";

                xDoc.AppendChild(xElemRoot);

                xDoc.Save(strFileDestination);

                string strFileDest = strFullDestinationPathCatalog + @"\CONTENT-LOADED.xml";

                if (File.Exists(strFileDest))
                {
                    File.Delete(strFileDest);
                }
            }

            #endregion

        }

        #endregion Public Methods

        #endregion Methods

        #region IErrorHandler Members

        public bool HandleError(Exception error)
        {
            throw new NotImplementedException();
        }

        public void ProvideFault(Exception error, System.ServiceModel.Channels.MessageVersion version, ref System.ServiceModel.Channels.Message fault)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
