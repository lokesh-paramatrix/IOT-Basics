﻿#region NAMESPACES
#region SYSTEM
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.ServiceModel;
#endregion //SYTEM

#region CUSTOM
using PRISMA.LOR2.Common;
using PRISMA.LOR2.Common.Logging.Logging;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
#endregion //CUSTOM
#endregion //NAMESPACES

namespace PRISMA.LOR2.CatalogFeedServiceHost
{
    public partial class CatalogFeedServiceHost : ServiceBase
    {
        private Logger logger;
        private ServiceHost catlogFeedServiceHost = null;

        //public CatalogFeedServiceHost()
        //{
        //    InitializeComponent();
        //}

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PMTFeedServiceHost"/> class.
        /// </summary>
        public CatalogFeedServiceHost()
        {
            InitializeComponent();
            logger = new Logger();
        }

#endregion
        protected override void OnStart(string[] args)
        {
            try
            {
                logger.LogInfoMessage("CatalogFeedServiceHost - Start: void override void OnStart(string[] args).");

                if (catlogFeedServiceHost != null)
                {
                    catlogFeedServiceHost.Close();
                }

                //Create a ServiceHost for the PMTFeedService type and provide the base address.
                catlogFeedServiceHost = new ServiceHost(typeof(CatFeedService.CatFeedService));

                //Open the ServiceHostBase to create listeners and start listening for messages.
                catlogFeedServiceHost.Open();


                logger.LogInfoMessage("CatalogFeedServiceHost - End: void override void OnStart(string[] args).");
            }

            catch (Exception ex)
            {
                logger.LogErrorMessage(ex.Message + ":\r\n" + ex.StackTrace);
                catlogFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }
        }

        protected override void OnStop()
        {
            try
            {
                logger.LogInfoMessage("catlogFeedServiceHost - Start: void OnStop().");

                if (catlogFeedServiceHost != null)
                {
                    catlogFeedServiceHost.Close();
                    catlogFeedServiceHost = null;
                }

                logger.LogInfoMessage("catlogFeedServiceHost - End: void OnStop().");
            }

            catch (Exception ex)
            {
                catlogFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }

        }
    }
}
