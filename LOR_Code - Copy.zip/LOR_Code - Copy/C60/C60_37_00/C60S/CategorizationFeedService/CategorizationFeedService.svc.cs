﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Xml;
using System.ServiceModel.MsmqIntegration;
using System.Threading;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using PrismaGeneral;
#endregion System

#region Custom
using PRISMA.LOR2.BLL;
using PRISMA.LOR2.Common;
using PRISMA.LOR2.FeedServiceDefinition;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;

using IsDnaJobManagement;
using IsDNAImportTypelib;
using System.Transactions;
using System.Collections;
using System.ServiceModel.Dispatcher;
using System.Messaging;
using System.Configuration;
using System.IO;
using System.Data;
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.CategorizationFeedService
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class CategorizationFeedService : FeedServiceBase.FeedServiceBase, ICategFeedService, IErrorHandler
    {
        static int iCounter;
        static Thread[] threads;
        static Thread threadHolder = null;
        static Stack<Thread> freeThreads = null;
        Dictionary<String, int> msgStatus = new Dictionary<String, int>();
        static Queue<FeedMessage> queCachedMessages;

        // PR021 Aman
        string strFullDestinationPathWith = string.Empty;
        string strFullDestinationPathWithout = string.Empty;
        // End

        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        private delegate void CallCreateCatFeedXMLFile(IParamSource objParams);
                
        #endregion Member variables

        #region Constructors
        static CategorizationFeedService()
        {
            try
            {
                queCachedMessages = new Queue<FeedMessage>();

                string maxThreads;
                maxThreads = ConfigurationManager.AppSettings["MaxThreads"];
                
                if (maxThreads == null)
                    maxThreads = "10";
                threads = new Thread[Convert.ToInt32(maxThreads)];
                
                freeThreads = new Stack<Thread>();

                foreach (Thread thread in threads)
                {
                    freeThreads.Push(thread);
                }
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                throw;
            }
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods

        /// <summary>
        /// Creates the PMT feed XML file.
        /// </summary>
        /// <param name="message">The message.</param>
        private string CreateCategFeedXMLFile(object feedMessage)
        {
            string strXMLFileName = "";
            string strXMLSchema = "";
            XmlNode objComponentData = null;
            IGenericStep xGen;
            IParamSource objParamSource = null;
            IParamSource objParamSettings = null;
            FeedMessage message = (FeedMessage)feedMessage;
            ComponentData compData = null;
            DataSet dsCMCDetails = null;
            ICommonRead objLOR2Queries = null;
            //Added by Arif for OEM and SPL catalog
            string channel_cd = "";         
            try
            {
                Logger.LogInfoMessage("START:CreateCategFeedXMLFile[" + message.FeedName + "](FeedMessage message):TargetGroup:" + message.TargetGroupCode + " Locale:" + message.Locale);
                if (message.FeedName == Constants.FEEDNAME_CATEGORIZATION_WITH_PRODUCTS)
                {
                    strXMLSchema = System.Configuration.ConfigurationManager.AppSettings["SchemaUrl_WithProducts"].ToString();
                }
                else if(message.FeedName == Constants.FEEDNAME_CATEGORIZATION_WITHOUT_PRODUCTS)
                {
                    strXMLSchema = System.Configuration.ConfigurationManager.AppSettings["SchemaUrl_WithoutProducts"].ToString();
                }

                objParamSource = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                objParamSettings = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));
                xGen = new PRISMA.LOR2.BLL.XMLGenerator();

                //Added by Arif for OEM and SPL catalog PR024
                channel_cd = message.ChannelCode;

                objParamSource.SetParam("xml_schema_name", strXMLSchema);
                objParamSource.SetParam("jrn_id", message.JobRunID.ToString());
                objParamSource.SetParam("locale", message.Locale);
                objParamSource.SetParam("publ_target_group_cd", message.TargetGroupCode);
                objParamSource.SetParam("FeedName", message.FeedName);
                objParamSource.SetParam("TargetGroupCode", message.TargetGroupCode);
                //Added by Arif for OEM and SPL catalog PR024
                objParamSource.SetParam("channel_cd", channel_cd);

                objParamSource.SetParam("cmc_locale", message.Cmc_Locale);//Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>

                objLOR2Queries = new LOR2Queries();
                //log start time for the current job
                //objParamSource.SetParam("where", "log_locale_run_start_time");
                //objLOR2Queries.ReadFilter(objParamSource);
                //objParamSource.SetParam("where", "cmc-locale-details");
                //dsCMCDetails = objLOR2Queries.ReadFilter(objParamSource);
                //if (dsCMCDetails.Tables[0].Rows.Count < 1)
                //{
                //    objParamSource.SetParam("cmc_locale", message.Locale);
                //}
                //else
                //{
                //    foreach (DataColumn dc in dsCMCDetails.Tables[0].Columns)
                //    {
                //        objParamSource.SetParam(dc.ColumnName, dsCMCDetails.Tables[0].Rows[0][dc].ToString());
                //    }
                //}//Commented by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>

                compData = new ComponentData(message.FeedName);
                compData.Create(ref objComponentData, objParamSource, 1, true);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress))
                {
                    strXMLFileName = xGen.FProcessData("", objParamSource, objComponentData, new clsJobLogger());
                    //Added by Kailash Alle 
                    #region Replacing Node1 with Node
                    StringBuilder data = new StringBuilder(File.ReadAllText(strXMLFileName, Encoding.UTF8));

                    data = data.Replace("<Node1", "<Node");
                    data = data.Replace("</Node1>", "</Node>");

                    File.WriteAllText(strXMLFileName, data.ToString(), Encoding.UTF8);
                    #endregion
                    //END
                }

                //get filesize
                long fileSize = FileHelper.FileSize(strXMLFileName);
                xGen = null;
                xGen = new BLL.clsXMLValidator();
                compData.Create(ref objComponentData, objParamSource, 2, true);
                strXMLFileName = xGen.FProcessData(strXMLFileName, objParamSource, objComponentData, new clsJobLogger());

                xGen = null;
                xGen = new BLL.BackupAndRestore();
                compData.Create(ref objComponentData, objParamSource, 3, true);
                objParamSource.SetParam("xmlFileLookupFormatStringKEY", "xmlFileNameFormatString" + objParamSource.GetParam("FeedName"));
                xGen.FProcessData(strXMLFileName, objParamSource, objComponentData, new clsJobLogger());

                //log the file size of the extraction of the current locale run
                //long fileSize = FileHelper.FileSize(strXMLFileName);
                objParamSource.SetParam("file_size", fileSize.ToString());
                objParamSource.SetParam("where", "log_locale_run_file_size");
                objLOR2Queries.ReadFilter(objParamSource);

                //log end time for the current job
                objParamSource.SetParam("where", "log_locale_run_end_time");
                objLOR2Queries.ReadFilter(objParamSource);
                Logger.LogInfoMessage("END:CreateCategFeedXMLFile[" + message.FeedName + "] (FeedMessage message):TargetGroup:" + message.TargetGroupCode + " Locale:" + message.Locale);
            }
            catch (Exception excep)
            {
                objParamSource.SetParam("lrn_status", "FAILED");
                objParamSource.SetParam("where", "log_locale_run_status");
                objLOR2Queries.ReadFilter(objParamSource);
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                Logger.LogErrorMessage(excep.TargetSite.DeclaringType.ToString() + "." + excep.TargetSite.ToString() + ":" + excep.Message);
            }
            finally
            {
                if (objParamSource != null) ((IDisposable)objParamSource).Dispose();
                if (objParamSettings != null) ((IDisposable)objParamSettings).Dispose();
                if (dsCMCDetails != null) dsCMCDetails.Dispose();
            }

            return strXMLFileName;
        }


        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Processes the feed message.
        /// </summary>
        /// <param name="message">The message.</param>
        [OperationBehavior(TransactionScopeRequired = true)]
        public void ProcessFeedMessage(FeedMessage message)
        {
            Thread currThread = null;

            #region PR021 - Aman

            string strFileDestinationWith = string.Empty;

            string strFileDestinationWithout = string.Empty;

            string strDestinationPath = System.Configuration.ConfigurationManager.AppSettings["xml_destination_drive"].ToString();

            //if (message.FeedName == Constants.FEEDNAME_CATEGORIZATION_WITH_PRODUCTS)
            //{

                strFileDestinationWith = System.Configuration.ConfigurationManager.AppSettings["LOR2FolderStructureCategorisationWithProducts"].ToString();

                int countWith = strFileDestinationWith.IndexOf("\"");

                int countWith1 = strFileDestinationWith.IndexOf("\"", countWith + 1);

                string strLORFolderNameWith = strFileDestinationWith.Substring(countWith + 1, countWith1 - countWith - 1);

                string strFeedFolderNameWith = System.Configuration.ConfigurationManager.AppSettings["LOR2FeedFolderNameWith"].ToString();

                //strFullDestinationPathWith = strDestinationPath + @"\" + strLORFolderNameWith + @"\" + message.TargetGroupCode + @"\" + strFeedFolderNameWith;
                strFullDestinationPathWith = strDestinationPath + @"\" + strLORFolderNameWith + @"\" + "ECATLIG" + @"\" + strFeedFolderNameWith;

            //}

            //if (message.FeedName == Constants.FEEDNAME_CATEGORIZATION_WITHOUT_PRODUCTS)
            //{

                strFileDestinationWithout = System.Configuration.ConfigurationManager.AppSettings["LOR2FolderStructureCategorisationWithoutProducts"].ToString();

                int countWithout = strFileDestinationWithout.IndexOf("\"");

                int countWithout1 = strFileDestinationWithout.IndexOf("\"", countWithout + 1);

                string strLORFolderNameWithout = strFileDestinationWithout.Substring(countWithout + 1, countWithout1 - countWithout - 1);

                string strFeedFolderNameWithout = System.Configuration.ConfigurationManager.AppSettings["LOR2FeedFolderNameWithout"].ToString();

                //strFullDestinationPathWithout = strDestinationPath + @"\" + strLORFolderNameWithout + @"\" + message.TargetGroupCode + @"\" + strFeedFolderNameWithout;
                strFullDestinationPathWithout = strDestinationPath + @"\" + strLORFolderNameWithout + @"\" + "ECATLIG" + @"\" + strFeedFolderNameWithout;


            //}

            string strFullFileDestinationPathWith = strFullDestinationPathWith + @"\CONTENT-LOADED.xml";

            string strFullFileDestinationPathWithout = strFullDestinationPathWithout + @"\CONTENT-LOADED.xml";

            #endregion

            try
            {
                #region Threading Part

                if (freeThreads.Count > 0)
                {
                    currThread = freeThreads.Pop();
                }
                else
                {
                    //// if not vacant
                    queCachedMessages.Enqueue(message);
                    return;
                }

                // Changes for PR021 - Aman
                if (File.Exists(strFullFileDestinationPathWith) && File.Exists(strFullFileDestinationPathWithout))
                {
                    currThread = new Thread(new ParameterizedThreadStart(ThreadTask));
                    //start the thread.
                    currThread.Start(message);
                }
                #endregion //Threading Part
            }
            catch (Exception excep)
            {
                System.Diagnostics.Debug.Assert(excep.Message != "Maximum number of threads reached");
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                Logger.LogErrorMessage(excep.TargetSite.DeclaringType.ToString() + "." + excep.TargetSite.ToString() + ":" + excep.Message);
            }
        }
        private void ThreadTask(object feedMessage)
        {
            string strTempFileName;
            strTempFileName = CreateCategFeedXMLFile(feedMessage);

            while (queCachedMessages.Count > 0)
            {
                CreateCategFeedXMLFile(queCachedMessages.Dequeue());
            }

            freeThreads.Push(Thread.CurrentThread);

            #region Issue PR021 - Aman

            //FeedMessage message = (FeedMessage)feedMessage;

            //string strFileDestinationWith = string.Empty;
            //string strFileDestinationWithout = string.Empty;
            if (freeThreads.Count == Convert.ToInt32(ConfigurationManager.AppSettings["MaxThreads"]))
            {

                //strFileDestinationWith = System.Configuration.ConfigurationManager.AppSettings["LOR2FolderStructureCategorisationWithProducts"].ToString();

                //strFileDestinationWith = strFileDestinationWith + "\\CONTENT-READY.xml";

                string strFullFileDestinationPathWith = strFullDestinationPathWith + @"\CONTENT-READY.xml";

                XmlDocument xDocWith = new XmlDocument();

                // Create root node.   
                XmlElement xElemRootWith = xDocWith.CreateElement("CONTENT-READY");
                xElemRootWith.InnerText = "The Feed is complete.";

                xDocWith.AppendChild(xElemRootWith);

                //strFileDestinationWithout = System.Configuration.ConfigurationManager.AppSettings["LOR2FolderStructureCategorisationWithoutProducts"].ToString();
                
                //strFileDestinationWithout = strFileDestinationWithout + "\\CONTENT-READY.xml";

                string strFullFileDestinationPathWithout = strFullDestinationPathWithout + @"\CONTENT-READY.xml";


                XmlDocument xDocWithout = new XmlDocument();

                // Create root node.   
                XmlElement xElemRootWithout = xDocWithout.CreateElement("CONTENT-READY");
                xElemRootWithout.InnerText = "The Feed is complete.";

                xDocWithout.AppendChild(xElemRootWithout);

                xDocWithout.Save(strFullFileDestinationPathWithout);

                xDocWith.Save(strFullFileDestinationPathWith);
                                
                //string strFileDest = System.Configuration.ConfigurationManager.AppSettings["Content_Ready_FileLocation"].ToString();

                string strFileDestWith = strFullDestinationPathWith + @"\CONTENT-LOADED.xml";

                if (File.Exists(strFileDestWith))
                {
                    File.Delete(strFileDestWith);
                }

                //string strFileDest1 = System.Configuration.ConfigurationManager.AppSettings["Content_Ready_FileLocation1"].ToString();

                string strFileDestWithout = strFullDestinationPathWithout + @"\CONTENT-LOADED.xml";

                if (File.Exists(strFileDestWithout))
                {
                    File.Delete(strFileDestWithout);
                }
            }

            #endregion
        }

        #endregion Public Methods

        #endregion Methods

        #region IErrorHandler Members

        public bool HandleError(Exception error)
        {
            throw new NotImplementedException();
        }

        public void ProvideFault(Exception error, System.ServiceModel.Channels.MessageVersion version, ref System.ServiceModel.Channels.Message fault)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}

