using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;


namespace PRISMA.LOR2.CategorizationFeedServiceHost
{
    [RunInstaller(true)]
    public partial class CategorizationFeedServiceHostInstaller : Installer
    {
        public CategorizationFeedServiceHostInstaller()
        {
            InitializeComponent();
        }

        private void serviceInstaller_AfterInstall(object sender, InstallEventArgs e)
        {

        }

        private void processInstaller_AfterInstall(object sender, InstallEventArgs e)
        {

        }
    }
}
