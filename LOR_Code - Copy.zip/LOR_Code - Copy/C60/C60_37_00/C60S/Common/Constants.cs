﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common
{
    /// <summary>
    /// 
    /// </summary>
    public static class Constants
    {
        #region Exception handling policy constants

        /// <summary>
        /// Represents exception handling policy - Log Only Policy
        /// </summary>
        public static readonly string LOG_ONLY_POLICY = "Log Only Policy";
        
        #endregion Exception handling policy constants

        #region Exception message constants

        /// <summary>
        /// Represents exception message: The value cannot be null.
        /// </summary>
        public static readonly string EXCEPTION_INVALID_VALUE = "EXCEPTION_INVALID_VALUE";

        #endregion Exception message constants

        #region Feed Service constants

        /// <summary>
        /// 
        /// </summary>
        public static readonly string PMT_FEED_SERVICE_OPERATION_BEHAVIOR = "ProcessFeedMessage";
        public static readonly string ASSET_FEED_SERVICE_OPERATION_BEHAVIOR = "ProcessFeedMessage";
        public static readonly string CAT_FEED_SERVICE_OPERATION_BEHAVIOR= "ProcessFeedMessage";
        public static readonly string CATEG_FEED_SERVICE_OPERATION_BEHAVIOR = "ProcessFeedMessage";

        /// <summary>
        /// 
        /// </summary>
        public static readonly string PMT_FEED_SERVICE_END_POINT = "PRISMA.LOR2.PMTFeedService.PMTFeedService";
        public static readonly string ASSET_FEED_SERVICE_END_POINT = "PRISMA.LOR2.AssetFeedService.AssetFeedService";
        public static readonly string CAT_FEED_SERVICE_END_POINT = "PRISMA.LOR2.CatFeedService.CatFeedService";
        public static readonly string CATFAM_FEED_SERVICE_END_POINT = "PRISMA.LOR2.CatFamFeedService.CatFamFeedService";
        public static readonly string CATEG_FEED_SERVICE_END_POINT = "PRISMA.LOR2.CategFeedService.CategFeedService";


        public const string FEEDNAME_CATEGORIZATION_WITH_PRODUCTS = "CategorisationWithProducts";
        public const string FEEDNAME_CATEGORIZATION_WITHOUT_PRODUCTS = "CategorisationWithoutProducts";
        #region Thread constants

        /// <summary>
        /// 
        /// </summary>
        public static readonly string NO_OF_PMT_FEED_SERVICE_THREADS = ConfigurationSettings.AppSettings["NoOfPMTFeedServiceThreads"];

        #endregion Thread constants

        #endregion Feed Service constants

        #region File Path constsnts

        /// <summary>
        /// 
        /// </summary>
        public static readonly string PMT_FEED_XML_FILE_PATH = ConfigurationSettings.AppSettings["PMTFeedXmlFilePath"];

        #endregion File Path constsnts

        #region File Name constants

        /// <summary>
        /// 
        /// </summary>
        public static readonly string PMT_FEED_XML_FILE_NAME = "PMTFeed";

        #endregion File Name constants      

        //Copied from DAL Constants 
        #region Database User Authentication Tokens

        /// <summary>
        /// 
        /// </summary>
        public static readonly string VALID_USER_ID_TOKENS = "User id,uid";

        /// <summary>
        /// 
        /// </summary>
        public static readonly string VALID_PASSWORD_TOKENS = "Password,pwd";

        #endregion Database User Authentication Tokens

        #region Stored Procedure constants

        /// <summary>
        /// 
        /// </summary>
        public static string DATABASE_CONNECTION_STRING
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
            }
        }
        

        #endregion Stored Procedure constants

        #region Stored Procedure constants
        #endregion Stored Procedure constants

        #region Stored Procedure Parameters constants

        /// <summary>
        /// 
        /// </summary>
        public static readonly string SP_RETURN_VALUE = "@RETURN_VALUE";

        #endregion Stored Procedure Parameters constants

        #region Exception message constants

        /// <summary>
        /// Represents exception message: The command must be a SqlCommand.
        /// </summary>
        public static readonly string EXCEPTION_NOT_SQL_COMMAND = "EXCEPTION_NOT_SQL_COMMAND";

        /// <summary>
        /// Represents exception message: Failed to update row.
        /// </summary>
        public static readonly string EXCEPTION_UPDATE_DATASET_ROW = "EXCEPTION_UPDATE_DATASET_ROW";

        #endregion Exception message constants


        //CREATE INDIVIDUAL REGIONS FOR INDIVIDUAL PROJECTS AND DEFINE THE CONSTANTS IN THE RESPECTIVE REGIONS

        #region LOR2.BLL CONSTANTS
        //LOR2Queries.cs:
        public const string DEFAULT_LOCAL_QUERY_LOOKUP_COMPONENT = "LOR2.BLL.LOR2Queries";
        #endregion //LOR2.BLL CONSTANTS

        #region LOR2.BusinessFacade CONSTANTS

        #endregion //LOR2.BusinessFacade CONSTANTS

        #region LOR2.DAL CONSTANTS

        public const string DB_JOBMGR = "JOB_MGR";
        public const string DB_MAIN = "PRISMA";
        public const string DB_XML = "PRISMA_XML";
        #endregion //LOR2.DAL CONSTANTS
    }
}
