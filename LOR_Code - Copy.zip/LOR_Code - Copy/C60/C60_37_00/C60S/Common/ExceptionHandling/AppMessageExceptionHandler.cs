#region Namespaces

#region System

using System;
using System.IO;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using System.Collections.Specialized;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common.ExceptionHandling
{
	/// <summary>
	/// Summary description for GlobalPolicyExceptionHandler.
	/// </summary>
    [ConfigurationElementType(typeof(CustomHandlerData))]
    public class AppMessageExceptionHandler : IExceptionHandler
	{
        #region Member variables
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AppMessageExceptionHandler"/> class.
        /// </summary>
        /// <param name="ignore">The ignore.</param>
        public AppMessageExceptionHandler(NameValueCollection ignore)
        {
        }
        
        #endregion Constructors

        #region Properties
        #endregion Properties        

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="handlingInstanceId">The handling instance id.</param>
        /// <returns></returns>
        public Exception HandleException(Exception exception, Guid handlingInstanceId)
        {
            return exception;
        }

        #endregion Public Methods

        #endregion Methods
	}
}
