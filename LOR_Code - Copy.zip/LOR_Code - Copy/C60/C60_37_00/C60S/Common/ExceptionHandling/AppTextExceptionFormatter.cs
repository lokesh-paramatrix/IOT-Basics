#region Namespaces

#region System

using System;
using System.IO;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common.ExceptionHandling
{
	/// <summary>
	/// Summary description for AppTextExceptionFormatter.
	/// </summary>	
	public class AppTextExceptionFormatter : TextExceptionFormatter
    {
        #region Member variables
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AppTextExceptionFormatter"/> class.
        /// </summary>
        /// <param name="writer">The writer.</param>
        /// <param name="exception">The exception.</param>
        public AppTextExceptionFormatter(TextWriter writer, Exception exception) : base(writer, exception)
        {
        }

        #endregion Constructors

        #region Properties
        #endregion Properties        

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// Writes the stack trace.
        /// </summary>
        /// <param name="stackTrace">The stack trace.</param>
        protected override void WriteStackTrace(string stackTrace)
        {

        }

        /// <summary>
        /// Writes the type of the exception.
        /// </summary>
        /// <param name="exceptionType">Type of the exception.</param>
        protected override void WriteExceptionType(Type exceptionType)
        {
            base.Indent();
            base.Writer.WriteLine("Type : {0}", exceptionType.FullName);
        }

        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
	}
}
