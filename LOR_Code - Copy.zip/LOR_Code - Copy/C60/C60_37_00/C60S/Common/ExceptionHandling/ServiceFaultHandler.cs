﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling.Configuration;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling.Properties;
using System.ServiceModel;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common.ExceptionHandling
{
    /// <summary>
    /// Replaces the current exception in the handling chain with a System.ServiceModel.FaultException with detail exception of a specified type.
    /// </summary>
    [ConfigurationElementType(typeof(ServiceFaultHandlerData))]
    public class ServiceFaultHandler : IExceptionHandler
    {
        #region Member variables

        private readonly string _exceptionMessage;
        private readonly Type _detailExceptionType;

        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceFaultHandler"/> class.
        /// </summary>
        /// <param name="exceptionMessage">The exception message.</param>
        /// <param name="detailExceptionType">Type of the detail exception.</param>
        public ServiceFaultHandler(string exceptionMessage, Type detailExceptionType)
        {
            if (detailExceptionType == null)
            {
                throw new ArgumentNullException("detailExceptionType");
            }

            if (!typeof(Exception).IsAssignableFrom(detailExceptionType))
            {
                throw new ArgumentException("This is not an exception type", "detailExceptionType");
            }

            this._exceptionMessage = exceptionMessage;
            this._detailExceptionType = detailExceptionType;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// <para>Gets the <see cref="Type"/> of exception to replace the original exception with.</para>
        /// </summary>
        /// <value>
        /// <para>The <see cref="Type"/> of exception to replace the original exception with.</para>
        /// </value>
        public Type DetailExceptionType
        {
            get
            {
                return _detailExceptionType;
            }
        }

        /// <summary>
        /// <para>Gets the message of the replaced exception.</para>
        /// </summary>
        /// <value>
        /// <para>The message of the replaced exception.</para>
        /// </value>
        public string DetailExceptionMessage
        {
            get
            {
                return _exceptionMessage;
            }
        }

        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// <para>Replaces the <see cref="Exception"/> with the configuration exception type.</para>
        /// </summary>
        /// <param name="exception"><para>The exception to handle.</para></param>        
        /// <param name="handlingInstanceId">
        /// <para>The unique ID attached to the handling chain for this handling instance.</para>
        /// </param>
        /// <returns><para>Modified exception to pass to the next exceptionHandlerData in the chain.</para></returns>        
        public Exception HandleException(Exception exception, Guid handlingInstanceId)
        {
            return WrapException(exception, ExceptionUtility.FormatExceptionMessage(DetailExceptionMessage, handlingInstanceId));
        }

        /// <summary>
        /// Wraps the original exception with FaultException.
        /// </summary>
        /// <param name="originalException"></param>
        /// <param name="detailsExceptionMessage"></param>
        /// <returns></returns>
        private Exception WrapException(Exception originalException, string detailsExceptionMessage)
        {
            // Create the detail exception
            object[] extraParameters = new object[] { detailsExceptionMessage };
            Exception detail = (Exception)Activator.CreateInstance(DetailExceptionType, extraParameters);

            Type faultExceptionType = typeof(FaultException<>);
            Type faultBindedExceptionType = faultExceptionType.MakeGenericType(DetailExceptionType);

            // Create a meaningful fault reason
            FaultReason reason = new FaultReason(originalException.Message);

            // Construct a new fualtException with generic type
            extraParameters = new object[] { detail, reason };
            Exception detail2 = (Exception)Activator.CreateInstance(faultBindedExceptionType, extraParameters);
            return detail2;
        }

        #endregion Public Methods

        #endregion Methods
    }
}