﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling.Configuration;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common.ExceptionHandling
{
    /// <summary>
    /// This type supports the Enterprise Library infrastructure and is not intended to be used directly from your code.
    /// Represents the process to build a <see cref="ServiceFaultHandler"/> described by a <see cref="ServiceFaultHandlerData"/> configuration object.
    /// </summary>
    /// <remarks>This type is linked to the <see cref="ServiceFaultHandlerData"/> type and it is used by the <see cref="ExceptionHandlerCustomFactory"/> 
    /// to build the specific <see cref="IExceptionHandler"/> object represented by the configuration object.
    /// </remarks>
    public class ServiceFaultHandlerAssembler : IAssembler<IExceptionHandler, ExceptionHandlerData>
    {
        #region Member variables
        #endregion Member variables

        #region Constructors
        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// This method supports the Enterprise Library infrastructure and is not intended to be used directly from your code.
        /// Builds a <see cref="ServiceFaultHandler"/> based on an instance of <see cref="WrapHandlerData"/>.
        /// </summary>
        /// <seealso cref="ExceptionHandlerCustomFactory"/>
        /// <param name="context">The <see cref="IBuilderContext"/> that represents the current building process.</param>
        /// <param name="objectConfiguration">The configuration object that describes the object to build. Must be an instance of <see cref="ServiceFaultHandlerData"/>.</param>
        /// <param name="configurationSource">The source for configuration objects.</param>
        /// <param name="reflectionCache">The cache to use retrieving reflection information.</param>
        /// <returns>A fully initialized instance of <see cref="ServiceFaultHandler"/>.</returns>
        public IExceptionHandler Assemble(IBuilderContext context, ExceptionHandlerData objectConfiguration, IConfigurationSource configurationSource, ConfigurationReflectionCache reflectionCache)
        {
            ServiceFaultHandlerData castedObjectConfiguration = (ServiceFaultHandlerData)objectConfiguration;
            ServiceFaultHandler createdObject = new ServiceFaultHandler(castedObjectConfiguration.ExceptionMessage, castedObjectConfiguration.DetailExceptionType);
            return createdObject;
        }

        #endregion Public Methods

        #endregion Methods

        #region IAssembler<IExceptionHandler,ExceptionHandlerData> Members

        IExceptionHandler IAssembler<IExceptionHandler, ExceptionHandlerData>.Assemble(Microsoft.Practices.ObjectBuilder.IBuilderContext context, ExceptionHandlerData objectConfiguration, IConfigurationSource configurationSource, ConfigurationReflectionCache reflectionCache)
        {
            return Assemble(context, objectConfiguration, configurationSource, reflectionCache);
        }

        #endregion
    }
}
