﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using System.Configuration;
using System.ComponentModel;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling.Configuration;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common.ExceptionHandling
{
    /// <summary>
    /// Represents the configuration data for a <see cref="ServiceFaultHandlerData"/>.
    /// </summary>	
    [Assembler(typeof(ServiceFaultHandlerAssembler))]
    public class ServiceFaultHandlerData : ExceptionHandlerData
    {
        #region Member variables

        private const string exceptionMessageProperty = "exceptionMessage";
        private const string detailExceptionTypeProperty = "detailsExceptionType";

        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceFaultHandlerData"/> class.
        /// </summary>
        public ServiceFaultHandlerData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceFaultHandlerData"/> class with a name, an exception message, and the fully qualified assembly name of the type of the wrapping exception.
        /// </summary>
        /// <param name="name">
        /// The name of the <see cref="ServiceFaultHandlerData"/>.
        /// </param>
        /// <param name="exceptionMessage">
        /// The exception message replacement.
        /// </param>
        /// <param name="detailsExceptionType">
        /// The fully qualified assembly name of type of the wrapping exception
        /// </param>
        public ServiceFaultHandlerData(string name, string exceptionMessage, Type detailsExceptionType) : base(name, typeof(ServiceFaultHandler))
        {
            this.ExceptionMessage = exceptionMessage;
            this.DetailExceptionType = detailsExceptionType;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the message for the replacement exception.
        /// </summary>
        [ConfigurationProperty(exceptionMessageProperty, IsRequired = true)]
        public string ExceptionMessage
        {
            get
            {
                return (string)this[exceptionMessageProperty];
            }
            
            set
            {
                this[exceptionMessageProperty] = value;
            }
        }

        /// <summary>
        /// Gets or sets the fully qualified type name of the replacement exception.
        /// </summary>
        [ConfigurationProperty(detailExceptionTypeProperty, IsRequired = true)]
        [TypeConverter(typeof(AssemblyQualifiedTypeNameConverter))]
        [SubclassTypeValidator(typeof(Exception))]
        public Type DetailExceptionType
        {
            get
            {
                return (Type)this[detailExceptionTypeProperty];
            }
            
            set
            {
                this[detailExceptionTypeProperty] = value;
            }
        }		

        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
    }
}
