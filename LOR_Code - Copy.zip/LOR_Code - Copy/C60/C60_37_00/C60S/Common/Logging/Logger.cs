#region Namespaces

#region System

using System;
using System.Diagnostics;
using System.IO;
using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Logging;
using IsDnaJobManagement;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common.Logging.Logging
{
    /// <summary>
    /// Summary description for Logger.
    /// </summary>
    public sealed class Logger : IJobLogger
    {   
        #region Member variables
        #endregion Member variables

        #region Constructors
        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Logs the error message.
        /// </summary>
        /// <param name="message">The message.</param>
        public void LogErrorMessage(string message)
        {
            try
            {
                LogEntry logEntry = new LogEntry();
                logEntry.Categories.Clear();
                logEntry.Categories.Add("Trace");
                logEntry.TimeStamp = DateTime.Now;
                logEntry.Priority = 5;
                logEntry.Severity = TraceEventType.Error;
                logEntry.Message = "Exception: " + message;                

                // Writes the log entry.
                Microsoft.Practices.EnterpriseLibrary.Logging.Logger.Write(logEntry);                
            }

            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Logs the info message.
        /// </summary>
        /// <param name="message">The message.</param>
        public void LogInfoMessage(string message)
        {
            try
            {
                LogEntry logEntry = new LogEntry();
                logEntry.Categories.Clear();
                logEntry.Categories.Add("Trace");
                logEntry.TimeStamp = DateTime.Now;
                logEntry.Severity = TraceEventType.Information;
                logEntry.Message = "Info: " + message;

                // Writes the log entry.
                Microsoft.Practices.EnterpriseLibrary.Logging.Logger.Write(logEntry);
            }

            catch
            {
                throw;
            }
        }

        #endregion Public Methods

        #endregion Methods

        #region IJobLogger Members

        void IJobLogger.FIncreaseCounter(long vLngRunID, long vLngCounterID, long vLngAmount)
        {
            throw new NotImplementedException();
        }

        void IJobLogger.FLog(long vLngRunID, string vStrLogMsg)
        {
            LogInfoMessage(vStrLogMsg);
        }

        void IJobLogger.FSetCounter(long vLngRunID, long vLngCounterID, long vLngValue)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
