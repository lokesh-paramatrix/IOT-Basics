﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Common
{
    /// <summary>
    /// 
    /// </summary>
    public class ThreadHelper
    {
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        private int paramLimit = 60;

        /// <summary>
        /// 
        /// </summary>
        private string error;

        /// <summary>
        /// 
        /// </summary>
        private bool isDone;

        /// <summary>
        /// 
        /// </summary>
        private int paramCount;

        /// <summary>
        /// 
        /// </summary>
        private Object[] parameters;

        /// <summary>
        /// 
        /// </summary>
        private Object output;

        /// <summary>
        /// 
        /// </summary>
        private Delegate methodCall;

        /// <summary>
        /// 
        /// </summary>
        private Thread workerThread;

        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ThreadHelper"/> class.
        /// </summary>
        public ThreadHelper()
        {
            error = string.Empty;
            isDone = false;
            paramCount = 0;
            methodCall = null;
            output = null;
            parameters = new Object[paramLimit + 1];
            workerThread = null;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Sets the method to call.
        /// </summary>
        /// <value>The method to call.</value>
        public Delegate MethodToCall
        {
            set
            {
                methodCall = value;
            }
            get
            {
                return methodCall;
            }
        }

        /// <summary>
        /// Gets the method output.
        /// </summary>
        /// <value>The method output.</value>
        public Object MethodOutput
        {
            get
            {
                return output;
            }
        }

        /// <summary>
        /// Gets the error message.
        /// </summary>
        /// <value>The error message.</value>
        public string ErrorMessage
        {
            get
            {
                return error;
            }
        }

        #endregion Properties

        #region Methods

        #region Private Methods

        /// <summary>
        /// Methods the call thread.
        /// </summary>
        private void MethodCallThread()
        {
            try
            {
                if (methodCall != null)
                {
                    Object[] methodParams = null;

                    if (paramCount > 0)
                    {
                        methodParams = new Object[paramCount];
                        
                        for (int i = 0; i < paramCount; i++)
                        {
                            methodParams[i] = parameters[i];
                        }
                    }

                    output = methodCall.DynamicInvoke(methodParams);
                }

                else
                {
                    error = "Method to be executed not set properly";
                }
            }

            catch (MemberAccessException exception)
            {
                error = exception.Message;
            }

            finally
            {
                isDone = true;
            }
        }

        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Sets the parameter.
        /// </summary>
        /// <param name="value">The value.</param>
        public void SetParameter(Object value)
        {
            if (paramCount > paramLimit)
            {
                throw new Exception("Too many parameters");
            }

            parameters[paramCount] = value;
            paramCount++;
        }

        /// <summary>
        /// Starts the thread.
        /// </summary>
        /// <returns></returns>
        public bool StartThread()
        {
            try
            {
                error = string.Empty;
                ThreadStart myThreadStart = new ThreadStart(this.MethodCallThread);
                workerThread = new Thread(myThreadStart);
                workerThread.Start();
                return true;
            }

            //catch (Exception exception)
            catch (ThreadStateException exception)
            {
                error = exception.Message;
                
                try
                {
                    workerThread.Abort();
                }
                
                catch (ThreadAbortException)
                { 
                }
                
                workerThread = null;
                return false;
            }
        }

        /// <summary>
        /// Waits for thread.
        /// </summary>
        public void WaitForThread()
        {
            while (isDone == false)
            {
                Thread.Sleep(100);
                
                if (workerThread == null)
                {
                    break;
                }
            }
        }

        /// <summary>
        /// Resets this instance.
        /// </summary>
        public void Reset()
        {
            error = string.Empty;
            isDone = false;
            paramCount = 0;
            methodCall = null;
            output = null;
            parameters = new Object[paramLimit + 1];
            workerThread = null;
        }
                
        #endregion Public Methods

        #endregion Methods
    }
}
