#region Namespaces

#region System

using System;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Reflection;
using System.Collections;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Instrumentation;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using Microsoft.Practices.EnterpriseLibrary.Common.Instrumentation;

#endregion System

#region Custom

using PRISMA.LOR2.Resources;
using PrismaGeneral;
using PRISMA.LOR2.Common;
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.DAL
{
	/// <summary>
	/// Represents an abstract database that commands can be run against. 
	/// </summary>
	/// <remarks>
	/// The <see cref="Database"/> class leverages the provider factory model from ADO.NET. A database instance holds 
	/// a reference to a concrete <see cref="DbProviderFactory"/> object to which it forwards the creation of ADO.NET objects.
	/// </remarks>
	[ConfigurationNameMapper(typeof(DatabaseMapper))]
	[CustomFactory(typeof(DatabaseCustomFactory))]
	public abstract class SlDatabase : Microsoft.Practices.EnterpriseLibrary.Data.Database
    {
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
		private DbProviderFactory dbProviderFactory;

        /// <summary>
        /// The <see cref="DataInstrumentationProvider"/> instance that defines the logical events used to instrument this <see cref="Database"/> instance.
        /// </summary>
        protected static ParameterCache parameterCache = new ParameterCache();

        /// <summary>
        /// 
        /// </summary>
        private UserMessages userMessages;

        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Database"/> class with a connection string and a <see cref="DbProviderFactory"/>.
        /// </summary>
        /// <param name="connectionString">The connection string for the database.</param>
        /// <param name="dbProviderFactory">A <see cref="DbProviderFactory"/> object.</param>
        protected SlDatabase(string connectionString, DbProviderFactory dbProviderFactory): base(connectionString, dbProviderFactory)
        {
            this.dbProviderFactory = dbProviderFactory;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the user messages.
        /// </summary>
        /// <value>The user messages.</value>
        protected UserMessages UserMessages
        {
            get
            {
                if (userMessages == null)
                {
                    userMessages = new UserMessages();
                }

                return userMessages;
            }
        }

        /// <summary>
        /// <para>Gets the DbProviderFactory used by the database instance.</para>
        /// </summary>
        /// <seealso cref="DbProviderFactory"/>
        protected DbProviderFactory DbProviderFactory
        {
            get
            {
                return this.dbProviderFactory;
            }
        }

        #endregion Properties

        #region Methods

        #region Private Methods

        /// <summary>
        /// Assigns the parameter values.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <param name="values">The values.</param>
        private void AssignParameterValues(DbCommand command, IParamSource values)
        {
            foreach (DbParameter iterateparam in command.Parameters)
            {
                if (iterateparam.ParameterName.ToString().ToUpper() != Constants.SP_RETURN_VALUE && iterateparam.Direction != ParameterDirection.Output)
                {
                    if (values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower().ToString()) != "")
                    {
                        if (Type.Equals(((System.Data.SqlClient.SqlParameter)iterateparam).SqlDbType, SqlDbType.Bit))
                        {
                            if (values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower().ToString()) == "1")
                            {
                                SetParameterValue(command, iterateparam.ParameterName, (object)true);
                            }
                            
                            else
                            {
                                SetParameterValue(command, iterateparam.ParameterName, (object)false);
                            }
                        }

                        else if (Type.Equals(((System.Data.SqlClient.SqlParameter)iterateparam).SqlDbType, SqlDbType.UniqueIdentifier))
                        {
                            SetParameterValue(command, iterateparam.ParameterName, (object)new Guid(values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower().ToString())));
                        }
                        
                        else
                        {
                            SetParameterValue(command, iterateparam.ParameterName, (object)values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower().ToString()));
                        }
                    }

                    else
                    {
                        SetParameterValue(command, iterateparam.ParameterName, null);
                    }
                }
            }
        }

        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// Does the load data table.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <returns></returns>
        private DataTable DoLoadDataTable(DbCommand command)
        {
            using (DbDataAdapter adapter = GetDataAdapter(UpdateBehavior.Standard))
            {
                ((IDbDataAdapter)adapter).SelectCommand = command;
                DataTable dt = new DataTable();

                try
                {
                    adapter.Fill(dt);
                    return dt;
                }
                
                catch
                {
                    throw;
                }
                
                finally
                {
                    if (dt != null)
                    {
                        dt.Dispose();
                    }
                }
            }
        }

        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public virtual DataTable LoadDataTable(DbCommand command)
        {
            using (DbConnection connection = CreateConnection())
            {
                PrepareCommand(command, connection);
                return DoLoadDataTable(command);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public virtual DataTable ExecuteDataTable(DbCommand command)
        {
            return LoadDataTable(command);
        }

        /// <summary>
        /// <para>Executes the <paramref name="storedProcedureName"/> using the given <paramref name="parameterValues" /> and returns the number of rows affected.</para>
        /// </summary>
        /// <param name="storedProcedureName">
        /// <para>The name of the stored procedure to execute.</para>
        /// </param>
        /// <param name="parameterValues">
        /// <para>An array of paramters to pass to the stored procedure. The parameter values must be in call order as they appear in the stored procedure.</para>
        /// </param>
        /// <returns>
        /// <para>The number of rows affected</para>
        /// </returns>
        /// <seealso cref="IDbCommand.ExecuteScalar"/>
        public virtual int ExecuteNonQuery(string storedProcedureName, IParamSource parameters)
        {
            using (DbCommand command = GetStoredProcCommand(storedProcedureName, parameters))
            {
                int retVal = ExecuteNonQuery(command);
                
                foreach (DbParameter objParam in command.Parameters)
                {
                    if (objParam.Direction == ParameterDirection.Output || objParam.Direction == ParameterDirection.InputOutput)
                    {
                        parameters.SetParam(objParam.ParameterName.Replace("@", "").ToLower().ToString(), objParam.Value.ToString().Trim());
                    }
                }

                return retVal;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="storedProcedureName"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual DataTable ExecuteDataTable(string storedProcedureName, IParamSource parameters)
        {
            using (DbCommand command = GetStoredProcCommand(storedProcedureName, parameters))
            {
                return ExecuteDataTable(command);
            }
        }

        /// <summary>
        /// <para>Executes the <paramref name="storedProcedureName"/> with <paramref name="parameterValues" /> and returns the results in a new <see cref="DataSet"/>.</para>
        /// </summary>
        /// <param name="storedProcedureName">
        /// <para>The stored procedure to execute.</para>
        /// </param>
        /// <param name="objParam">
        /// <para>An array of paramters to pass to the stored procedure. The parameter values must be in call order as they appear in the stored procedure.</para>
        /// </param>
        /// <returns>
        /// <para>A <see cref="DataSet"/> with the results of the <paramref name="storedProcedureName"/>.</para>
        /// </returns>
        public virtual DataSet ExecuteDataSet(string storedProcedureName, IParamSource parameters)
        {
            using (DbCommand command = GetStoredProcCommand(storedProcedureName, parameters))
            {
                return ExecuteDataSet(command);
            }
        }

        /// <summary>
        /// The <see cref="DataInstrumentationProvider"/> instance that defines the logical events used to instrument this <see cref="Database"/> instance.
        /// </summary>
        public virtual DbCommand CreateCommandByCommandType(CommandType commandType, string commandText)
        {
            DbCommand command = dbProviderFactory.CreateCommand();
            command.CommandType = commandType;
            command.CommandText = commandText;
            command.CommandTimeout = 1800;

            return command;
        }

        /// <summary>
        /// <para>Creates a <see cref="DbCommand"/> for a stored procedure.</para>
        /// </summary>
        /// <param name="storedProcedureName"><para>The name of the stored procedure.</para></param>
        /// <param name="parameterValues"><para>The list of parameters for the procedure.</para></param>
        /// <returns><para>The <see cref="DbCommand"/> for the stored procedure.</para></returns>
        /// <remarks>
        /// <para>The parameters for the stored procedure will be discovered and the values are assigned in positional order.</para>
        /// </remarks>        
        public virtual DbCommand GetStoredProcCommand(string storedProcedureName, IParamSource parameters)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
            {
                throw new ArgumentException(UserMessages.GetResourceText(Common.Constants.EXCEPTION_INVALID_VALUE), "storedProcedureName");
            }

            DbCommand command = CreateCommandByCommandType(CommandType.StoredProcedure, storedProcedureName);
            parameterCache.SetParameters(command, this);
            AssignParameterValues(command, parameters);
            return command;
        }

        /// <summary>
        /// Clears the parameter cache. Since there is only one parameter cache that is shared by all instances
        /// of this class, this clears all parameters cached for all databases.
        /// </summary>
        //public static void ClearParameterCache()
        //{
        //    PRISMA.LOR2.DAL.Database.parameterCache.Clear();
        //}

        #endregion Public Methods

        #endregion Methods
    }
}
