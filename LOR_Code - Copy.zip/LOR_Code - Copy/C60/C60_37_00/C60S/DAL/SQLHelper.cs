﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Xml;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Security.Permissions;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Configuration;

#endregion System

#region Custom


using PRISMA.LOR2.Resources;
using PRISMA.LOR2.Common;
using PrismaGeneral;
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.DAL
{
    /// <summary>
    /// 
    /// </summary>
    [SqlClientPermission(SecurityAction.Demand)]
    [DatabaseAssembler(typeof(SqlDatabaseAssembler))]
    public class SQLHelper : SlDatabase
    {
        #region Member variables
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SQLHelper"/> class.
        /// </summary>
        public SQLHelper() : base(Constants.DATABASE_CONNECTION_STRING.ToString(), SqlClientFactory.Instance)
		{
            
        }

        #endregion Constructors

        #region Properties
                
        /// <summary>
        /// Gets the parameter token.
        /// </summary>
        /// <value>The parameter token.</value>
        protected char ParameterToken
        {
            get
            {
                return '@';
            }
        }

        #endregion Properties

        #region Methods

        #region Private Methods

        /// <summary>
        /// Does the execute non query.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <returns></returns>
        private int DoExecuteNonQuery(SqlCommand command)
        {
            try
            {
                DateTime startTime = DateTime.Now;
                int rowsAffected = command.ExecuteNonQuery();
                instrumentationProvider.FireCommandExecutedEvent(startTime);
                return rowsAffected;
            }

            catch (Exception exception)
            {
                instrumentationProvider.FireCommandFailedEvent(command.CommandText, ConnectionStringNoCredentials, exception);
                throw;
            }
        }

        /// <devdoc>
        /// Execute the actual XML Reader call.
        /// </devdoc>        
        private XmlReader DoExecuteXmlReader(SqlCommand sqlCommand)
        {
            try
            {
                DateTime startTime = DateTime.Now;
                XmlReader reader = sqlCommand.ExecuteXmlReader();
                instrumentationProvider.FireCommandExecutedEvent(startTime);
                return reader;
            }

            catch (Exception exception)
            {
                instrumentationProvider.FireCommandFailedEvent(sqlCommand.CommandText, ConnectionStringNoCredentials, exception);
                throw;
            }
        }

        /// <summary>
        /// Checks if SQL command.
        /// </summary>
        /// <param name="command">The command.</param>
        /// <returns></returns>
        private SqlCommand CheckIfSqlCommand(DbCommand command)
        {
            SqlCommand sqlCommand = command as SqlCommand;

            if (sqlCommand == null)
            {
                throw new ArgumentException(this.UserMessages.GetResourceText(Constants.EXCEPTION_NOT_SQL_COMMAND));
            }

            return sqlCommand;
        }

        /// <devdoc>
        /// Listens for the RowUpdate event on a dataadapter to support UpdateBehavior.Continue
        /// </devdoc>
        private void OnSqlRowUpdated(object sender, SqlRowUpdatedEventArgs rowThatCouldNotBeWritten)
        {
            if (rowThatCouldNotBeWritten.RecordsAffected == 0)
            {
                if (rowThatCouldNotBeWritten.Errors != null)
                {
                    rowThatCouldNotBeWritten.Row.RowError = UserMessages.GetResourceText(Constants.EXCEPTION_UPDATE_DATASET_ROW);
                    rowThatCouldNotBeWritten.Status = UpdateStatus.SkipCurrentRow;
                }
            }
        }

        /// <summary>
        /// The <see cref="DataInstrumentationProvider"/> instance that defines the logical events used to instrument this <see cref="Database"/> instance.
        /// </summary>
        private void AssignParameterValues(SqlCommand command, IParamSource values)
        {
            foreach (SqlParameter iterateparam in command.Parameters)
            {
                if (iterateparam.ParameterName.ToString().ToUpper() != Constants.SP_RETURN_VALUE && iterateparam.Direction != ParameterDirection.Output)
                {
                    if (values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower().ToString()) != "")
                    {
                        if (Type.Equals(iterateparam.SqlDbType, SqlDbType.Bit))
                        {
                            if (values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower().ToString()) == "1")
                            {
                                SetParameterValue(command, iterateparam.ParameterName, (object)true);
                            }

                            else
                            {
                                SetParameterValue(command, iterateparam.ParameterName, (object)false);
                            }
                        }

                        else if (Type.Equals(iterateparam.SqlDbType, SqlDbType.UniqueIdentifier))
                        {
                            SetParameterValue(command, iterateparam.ParameterName, (object)new Guid(values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower().ToString())));
                        }

                        else
                        {
                            SetParameterValue(command, iterateparam.ParameterName, (object)values.GetParam(iterateparam.ParameterName.Replace("@", "").ToLower()));
                        }
                    }

                    else
                    {
                        SetParameterValue(command, iterateparam.ParameterName, null);
                    }
                }
            }
        }

        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// Retrieves parameter information from the stored procedure specified in the <see cref="DbCommand"/> and populates the Parameters collection of the specified <see cref="DbCommand"/> object. 
        /// </summary>
        /// <param name="discoveryCommand">The <see cref="DbCommand"/> to do the discovery.</param>
        /// <remarks>The <see cref="DbCommand"/> must be a <see cref="SqlCommand"/> instance.</remarks>
        protected override void DeriveParameters(DbCommand discoveryCommand)
        {
            SqlCommandBuilder.DeriveParameters((SqlCommand)discoveryCommand);
        }

        /// <summary>
        /// Returns the starting index for parameters in a command.
        /// </summary>
        /// <returns>The starting index for parameters in a command.</returns>
        protected override int UserParametersStartIndex()
        {
            return 1;
        }

        /// <summary>
        /// Sets the RowUpdated event for the data adapter.
        /// </summary>
        /// <param name="adapter">The <see cref="DbDataAdapter"/> to set the event.</param>
        protected override void SetUpRowUpdatedEvent(DbDataAdapter adapter)
        {
            ((SqlDataAdapter)adapter).RowUpdated += new SqlRowUpdatedEventHandler(OnSqlRowUpdated);
        }

        /// <summary>
        /// Determines if the number of parameters in the command matches the array of parameter values.
        /// </summary>
        /// <param name="command">The <see cref="DbCommand"/> containing the parameters.</param>
        /// <param name="values">The array of parameter values.</param>
        /// <returns><see langword="true"/> if the number of parameters and values match; otherwise, <see langword="false"/>.</returns>
        protected override bool SameNumberOfParametersAndValues(DbCommand command, object[] values)
        {
            int returnParameterCount = 1;
            int numberOfParametersToStoredProcedure = command.Parameters.Count - returnParameterCount;
            int numberOfValuesProvidedForStoredProcedure = values.Length;
            return numberOfParametersToStoredProcedure == numberOfValuesProvidedForStoredProcedure;
        }

        /// <summary>
        /// <para>Adds a new instance of a <see cref="DbParameter"/> object.</para>
        /// </summary>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="DbType"/> values.</para></param>
        /// <param name="size"><para>The maximum size of the data within the column.</para></param>
        /// <param name="direction"><para>One of the <see cref="ParameterDirection"/> values.</para></param>
        /// <param name="nullable"><para>A value indicating whether the parameter accepts <see langword="null"/> (<b>Nothing</b> in Visual Basic) values.</para></param>
        /// <param name="precision"><para>The maximum number of digits used to represent the <paramref name="value"/>.</para></param>
        /// <param name="scale"><para>The number of decimal places to which <paramref name="value"/> is resolved.</para></param>
        /// <param name="sourceColumn"><para>The name of the source column mapped to the DataSet and used for loading or returning the <paramref name="value"/>.</para></param>
        /// <param name="sourceVersion"><para>One of the <see cref="DataRowVersion"/> values.</para></param>
        /// <param name="value"><para>The value of the parameter.</para></param>  
        protected DbParameter CreateParameter(string name, SqlDbType dbType, int size, ParameterDirection direction, bool nullable, byte precision, byte scale, string sourceColumn, DataRowVersion sourceVersion, object value)
        {
            SqlParameter param = CreateParameter(name) as SqlParameter;
            ConfigureParameter(param, name, dbType, size, direction, nullable, precision, scale, sourceColumn, sourceVersion, value);
            return param;
        }

        /// <summary>
        /// Configures a given <see cref="DbParameter"/>.
        /// </summary>
        /// <param name="param">The <see cref="DbParameter"/> to configure.</param>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="SqlDbType"/> values.</para></param>
        /// <param name="size"><para>The maximum size of the data within the column.</para></param>
        /// <param name="direction"><para>One of the <see cref="ParameterDirection"/> values.</para></param>
        /// <param name="nullable"><para>A value indicating whether the parameter accepts <see langword="null"/> (<b>Nothing</b> in Visual Basic) values.</para></param>
        /// <param name="precision"><para>The maximum number of digits used to represent the <paramref name="value"/>.</para></param>
        /// <param name="scale"><para>The number of decimal places to which <paramref name="value"/> is resolved.</para></param>
        /// <param name="sourceColumn"><para>The name of the source column mapped to the DataSet and used for loading or returning the <paramref name="value"/>.</para></param>
        /// <param name="sourceVersion"><para>One of the <see cref="DataRowVersion"/> values.</para></param>
        /// <param name="value"><para>The value of the parameter.</para></param>  
        protected virtual void ConfigureParameter(SqlParameter param, string name, SqlDbType dbType, int size, ParameterDirection direction, bool nullable, byte precision, byte scale, string sourceColumn, DataRowVersion sourceVersion, object value)
        {
            param.SqlDbType = dbType;
            param.Size = size;
            
            if (param.SqlDbType == SqlDbType.Bit)
            {
                if (param.Value.ToString().Trim() == "1")
                {
                    value = (object)true;
                }

                else
                {
                    value = (object)false;
                }
            }

            param.Value = (value == null) ? DBNull.Value : value;
            param.Direction = direction;
            param.IsNullable = nullable;
            param.SourceColumn = sourceColumn;
            param.SourceVersion = sourceVersion;
        }

        /// <summary>
        /// <para>Assigns a <paramref name="connection"/> to the <paramref name="command"/> and discovers parameters if needed.</para>
        /// </summary>
        /// <param name="command"><para>The command that contains the query to prepare.</para></param>
        /// <param name="connection">The connection to assign to the command.</param>
        protected static void PrepareCommand(SqlCommand command, SqlConnection connection)
        {
            if (command == null)
            {
                throw new ArgumentNullException("command");
            }

            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }

            command.Connection = connection;
        }        

        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// <para>Executes the <see cref="SqlCommand"/> and returns a new <see cref="XmlReader"/>.</para>
        /// </summary>
        /// <param name="command">
        /// <para>The <see cref="SqlCommand"/> to execute.</para>
        /// </param>
        /// <returns>
        /// <para>An <see cref="XmlReader"/> object.</para>
        /// </returns>
        public XmlReader ExecuteXmlReader(DbCommand command)
        {
            SqlCommand sqlCommand = CheckIfSqlCommand(command);
            DbConnection connection = OpenConnection();
            PrepareCommand(command, connection);
            return DoExecuteXmlReader(sqlCommand);
        }

        /// <summary>
        /// <para>Executes the <see cref="SqlCommand"/> in a transaction and returns a new <see cref="XmlReader"/>.</para>
        /// </summary>
        /// <param name="command">
        /// <para>The <see cref="SqlCommand"/> to execute.</para>
        /// </param>
        /// <param name="transaction">
        /// <para>The <see cref="IDbTransaction"/> to execute the command within.</para>
        /// </param>
        /// <returns>
        /// <para>An <see cref="XmlReader"/> object.</para>
        /// </returns>
        public XmlReader ExecuteXmlReader(DbCommand command, DbTransaction transaction)
        {
            SqlCommand sqlCommand = this.CheckIfSqlCommand(command);
            PrepareCommand(sqlCommand, transaction);
            return DoExecuteXmlReader(sqlCommand);
        }

        /// <summary>
        /// Builds a value parameter name for the current database.
        /// </summary>
        /// <param name="name">The name of the parameter.</param>
        /// <returns>A correctly formated parameter name.</returns>
        public override string BuildParameterName(string name)
        {
            if (name[0] != this.ParameterToken)
            {
                return name.Insert(0, new string(this.ParameterToken, 1));
            }

            return name;
        }

        /// <summary>
        /// <para>Adds a new instance of a <see cref="DbParameter"/> object to the command.</para>
        /// </summary>
        /// <param name="command">The command to add the parameter.</param>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="DbType"/> values.</para></param>
        /// <param name="size"><para>The maximum size of the data within the column.</para></param>
        /// <param name="direction"><para>One of the <see cref="ParameterDirection"/> values.</para></param>
        /// <param name="nullable"><para>A value indicating whether the parameter accepts <see langword="null"/> (<b>Nothing</b> in Visual Basic) values.</para></param>
        /// <param name="precision"><para>The maximum number of digits used to represent the <paramref name="value"/>.</para></param>
        /// <param name="scale"><para>The number of decimal places to which <paramref name="value"/> is resolved.</para></param>
        /// <param name="sourceColumn"><para>The name of the source column mapped to the DataSet and used for loading or returning the <paramref name="value"/>.</para></param>
        /// <param name="sourceVersion"><para>One of the <see cref="DataRowVersion"/> values.</para></param>
        /// <param name="value"><para>The value of the parameter.</para></param>       
        public virtual void AddParameter(DbCommand command, string name, SqlDbType dbType, int size, ParameterDirection direction, bool nullable, byte precision, byte scale, string sourceColumn, DataRowVersion sourceVersion, object value)
        {
            DbParameter parameter = this.CreateParameter(name, dbType, size, direction, nullable, precision, scale, sourceColumn, sourceVersion, value);
            command.Parameters.Add(parameter);
        }

        /// <summary>
        /// <para>Adds a new instance of a <see cref="DbParameter"/> object to the command.</para>
        /// </summary>
        /// <param name="command">The command to add the parameter.</param>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="SqlDbType"/> values.</para></param>        
        /// <param name="direction"><para>One of the <see cref="ParameterDirection"/> values.</para></param>                
        /// <param name="sourceColumn"><para>The name of the source column mapped to the DataSet and used for loading or returning the <paramref name="value"/>.</para></param>
        /// <param name="sourceVersion"><para>One of the <see cref="DataRowVersion"/> values.</para></param>
        /// <param name="value"><para>The value of the parameter.</para></param>    
        public void AddParameter(DbCommand command, string name, SqlDbType dbType, ParameterDirection direction, string sourceColumn, DataRowVersion sourceVersion, object value)
        {
            this.AddParameter(command, name, dbType, 0, direction, false, 0, 0, sourceColumn, sourceVersion, value);
        }

        /// <summary>
        /// Adds a new Out <see cref="DbParameter"/> object to the given <paramref name="command"/>.
        /// </summary>
        /// <param name="command">The command to add the out parameter.</param>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="SqlDbType"/> values.</para></param>        
        /// <param name="size"><para>The maximum size of the data within the column.</para></param>        
        public void AddOutParameter(DbCommand command, string name, SqlDbType dbType, int size)
        {
            this.AddParameter(command, name, dbType, size, ParameterDirection.Output, true, 0, 0, String.Empty, DataRowVersion.Default, DBNull.Value);
        }

        /// <summary>
        /// Adds a new In <see cref="DbParameter"/> object to the given <paramref name="command"/>.
        /// </summary>
        /// <param name="command">The command to add the in parameter.</param>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="SqlDbType"/> values.</para></param>                
        /// <remarks>
        /// <para>This version of the method is used when you can have the same parameter object multiple times with different values.</para>
        /// </remarks>        
        public void AddInParameter(DbCommand command, string name, SqlDbType dbType)
        {
            this.AddParameter(command, name, dbType, ParameterDirection.Input, String.Empty, DataRowVersion.Default, null);
        }

        /// <summary>
        /// Adds a new In <see cref="DbParameter"/> object to the given <paramref name="command"/>.
        /// </summary>
        /// <param name="command">The commmand to add the parameter.</param>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="SqlDbType"/> values.</para></param>                
        /// <param name="value"><para>The value of the parameter.</para></param>      
        public void AddInParameter(DbCommand command, string name, SqlDbType dbType, object value)
        {
            this.AddParameter(command, name, dbType, ParameterDirection.Input, String.Empty, DataRowVersion.Default, value);
        }

        /// <summary>
        /// Adds a new In <see cref="DbParameter"/> object to the given <paramref name="command"/>.
        /// </summary>
        /// <param name="command">The command to add the parameter.</param>
        /// <param name="name"><para>The name of the parameter.</para></param>
        /// <param name="dbType"><para>One of the <see cref="SqlDbType"/> values.</para></param>                
        /// <param name="sourceColumn"><para>The name of the source column mapped to the DataSet and used for loading or returning the value.</para></param>
        /// <param name="sourceVersion"><para>One of the <see cref="DataRowVersion"/> values.</para></param>
        public void AddInParameter(DbCommand command, string name, SqlDbType dbType, string sourceColumn, DataRowVersion sourceVersion)
        {
            this.AddParameter(command, name, dbType, 0, ParameterDirection.Input, true, 0, 0, sourceColumn, sourceVersion, null);
        }

        /// <summary>
        /// The <see cref="DataInstrumentationProvider"/> instance that defines the logical events used to instrument this <see cref="Database"/> instance.
        /// </summary>
        public new SqlCommand GetStoredProcCommand(string storedProcedureName, IParamSource parameterValues)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
            {
                throw new ArgumentException(UserMessages.GetResourceText(PRISMA.LOR2.Common.Constants.EXCEPTION_INVALID_VALUE));
            }

            SqlCommand command = (SqlCommand)CreateCommandByCommandType(CommandType.StoredProcedure, storedProcedureName);

            parameterCache.SetParameters(command, this);

            AssignParameterValues(command, parameterValues);
            return command;
        }

        /// <summary>
        /// The <see cref="DataInstrumentationProvider"/> instance that defines the logical events used to instrument this <see cref="Database"/> instance.
        /// </summary>
        public virtual void DiscoverParameters(SqlCommand command)
        {
            using (SqlConnection discoveryConnection = (SqlConnection)OpenConnection())
            {
                using (SqlCommand discoveryCommand = (SqlCommand)CreateCommandByCommandType(command.CommandType, command.CommandText))
                {
                    discoveryCommand.Connection = discoveryConnection;
                    DeriveParameters(discoveryCommand);

                    foreach (IDataParameter parameter in discoveryCommand.Parameters)
                    {
                        //Added By G.P.P for parameter to be compared in lower case in C#.
                        parameter.ParameterName = parameter.ParameterName.ToLower();

                        if (parameter.Direction == ParameterDirection.InputOutput)
                        {
                            parameter.Direction = ParameterDirection.Output;
                        }
                        SqlParameter cloneParameter = (SqlParameter)((ICloneable)parameter).Clone();
                        command.Parameters.Add(cloneParameter);
                    }
                }
            }
        }

        /// <summary>
        /// Sets a parameter value.
        /// </summary>
        /// <param name="command">The command with the parameter.</param>
        /// <param name="parameterName">The parameter name.</param>
        /// <param name="value">The parameter value.</param>
        public void SetParameterValue(SqlCommand command, string parameterName, object value)
        {
            if (value == null)
            {
                command.Parameters[BuildParameterName(parameterName)].Value = DBNull.Value;
            }
            else if (value.ToString().Trim() == "")
            {
                command.Parameters[BuildParameterName(parameterName)].Value = DBNull.Value;
            }
            else
            {
                command.Parameters[BuildParameterName(parameterName)].Value = value;
            }
        }

        /// <summary>
        /// <para>Executes the <paramref name="storedProcedureName"/> using the given <paramref name="parameterValues" /> and returns the number of rows affected.</para>
        /// </summary>
        /// <param name="storedProcedureName">
        /// <para>The name of the stored procedure to execute.</para>
        /// </param>
        /// <param name="parameterValues">
        /// <para>An array of paramters to pass to the stored procedure. The parameter values must be in call order as they appear in the stored procedure.</para>
        /// </param>
        /// <returns>
        /// <para>The number of rows affected</para>
        /// </returns>
        /// <seealso cref="IDbCommand.ExecuteScalar"/>
        /// 
        public override int ExecuteNonQuery(string storedProcedureName, IParamSource parameterValues)
        {
            using (DbCommand command = GetStoredProcCommand(storedProcedureName, parameterValues))
            {
                int retVal = ExecuteNonQuery(command);
                
                foreach (DbParameter sqlParam in command.Parameters)
                {
                    if (sqlParam.Direction == ParameterDirection.Output || sqlParam.Direction == ParameterDirection.InputOutput)
                    {
                        parameterValues.SetParam(sqlParam.ParameterName.Replace("@", "").ToLower().ToString(), sqlParam.Value.ToString().Trim());
                    }
                }

                return retVal;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="storedProcedureName"></param>
        /// <param name="objParam"></param>
        /// <returns></returns>
        public override DataTable ExecuteDataTable(string storedProcedureName, IParamSource objParam)
        {
            using (SqlCommand command = GetStoredProcCommand(storedProcedureName, objParam))
            {
                return ExecuteDataTable(command);
            }
        }

        /// <summary>
        /// <para>Executes the <paramref name="storedProcedureName"/> using the given <paramref name="objParams" /> and returns the Dataset</para>
        /// </summary>
        /// <param name="storedProcedureName"></param>
        /// <param name="objParams"></param>
        /// <returns></returns>
        public override DataSet ExecuteDataSet(string storedProcedureName, IParamSource objParams)
        {
            using (SqlCommand command = GetStoredProcCommand(storedProcedureName, objParams))
            {
                return ExecuteDataSet(command);
            }
        }

        /// <summary>
        /// <para>Executes the <paramref name="command"/> and returns the number of rows affected.</para>
        /// </summary>
        /// <param name="command">
        /// <para>The command that contains the query to execute.</para>
        /// </param>       
        /// <seealso cref="IDbCommand.ExecuteScalar"/>
        public int ExecuteNonQuery(SqlCommand command)
        {
            using (SqlConnection discoveryConnection = (SqlConnection)OpenConnection())
            {
                PrepareCommand(command, discoveryConnection);
                return DoExecuteNonQuery(command);
            }
        }
        
        #endregion Public Methods
        
        #endregion Methods
    }
}
