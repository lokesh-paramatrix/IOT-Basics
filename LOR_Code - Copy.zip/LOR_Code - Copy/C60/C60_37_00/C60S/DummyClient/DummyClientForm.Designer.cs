﻿namespace PRISMA.LOR2.DummyClient
{
    partial class DummyClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtJobID = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtCmcLocales = new System.Windows.Forms.TextBox();
            this.chkLocale = new System.Windows.Forms.CheckBox();
            this.cmbFeedName = new System.Windows.Forms.ComboBox();
            this.txtLocales = new System.Windows.Forms.TextBox();
            this.lblTargetGroupCode = new System.Windows.Forms.Label();
            this.txtTargetGroupCode = new System.Windows.Forms.TextBox();
            this.lblFeedName = new System.Windows.Forms.Label();
            this.lblJobRunID = new System.Windows.Forms.Label();
            this.txtJobRunID = new System.Windows.Forms.TextBox();
            this.lblJobID = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblPrismaLocales = new System.Windows.Forms.Label();
            this.lblCmcLocales = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtJobID
            // 
            this.txtJobID.Location = new System.Drawing.Point(185, 18);
            this.txtJobID.Name = "txtJobID";
            this.txtJobID.Size = new System.Drawing.Size(212, 20);
            this.txtJobID.TabIndex = 2;
            this.txtJobID.Text = "A1F8502B-1497-41DD-BE71-6A6B93FF35AF";
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(249, 186);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 7;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.sendButton_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(19, 21);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(424, 241);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblCmcLocales);
            this.tabPage1.Controls.Add(this.lblPrismaLocales);
            this.tabPage1.Controls.Add(this.txtCmcLocales);
            this.tabPage1.Controls.Add(this.chkLocale);
            this.tabPage1.Controls.Add(this.cmbFeedName);
            this.tabPage1.Controls.Add(this.txtLocales);
            this.tabPage1.Controls.Add(this.lblTargetGroupCode);
            this.tabPage1.Controls.Add(this.txtTargetGroupCode);
            this.tabPage1.Controls.Add(this.lblFeedName);
            this.tabPage1.Controls.Add(this.lblJobRunID);
            this.tabPage1.Controls.Add(this.txtJobRunID);
            this.tabPage1.Controls.Add(this.lblJobID);
            this.tabPage1.Controls.Add(this.txtJobID);
            this.tabPage1.Controls.Add(this.btnSend);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(416, 215);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "PMT Feed";
            this.tabPage1.UseVisualStyleBackColor = true;
            
            // 
            // txtCmcLocales
            // 
            this.txtCmcLocales.Location = new System.Drawing.Point(185, 148);
            this.txtCmcLocales.Name = "txtCmcLocales";
            this.txtCmcLocales.Size = new System.Drawing.Size(212, 20);
            this.txtCmcLocales.TabIndex = 9;
            // 
            // chkLocale
            // 
            this.chkLocale.AutoSize = true;
            this.chkLocale.Location = new System.Drawing.Point(10, 124);
            this.chkLocale.Name = "chkLocale";
            this.chkLocale.Size = new System.Drawing.Size(69, 17);
            this.chkLocale.TabIndex = 8;
            this.chkLocale.Text = "Locale(s)";
            this.chkLocale.UseVisualStyleBackColor = true;
            // 
            // cmbFeedName
            // 
            this.cmbFeedName.FormattingEnabled = true;
            this.cmbFeedName.Items.AddRange(new object[] {
            "PMT",
            "CatFam",
            "Asset",
            "Catalog",
            "Categorisation"});
            this.cmbFeedName.Location = new System.Drawing.Point(185, 70);
            this.cmbFeedName.Name = "cmbFeedName";
            this.cmbFeedName.Size = new System.Drawing.Size(212, 21);
            this.cmbFeedName.TabIndex = 4;
            // 
            // txtLocales
            // 
            this.txtLocales.Location = new System.Drawing.Point(185, 122);
            this.txtLocales.Name = "txtLocales";
            this.txtLocales.Size = new System.Drawing.Size(212, 20);
            this.txtLocales.TabIndex = 7;
            
            // 
            // lblTargetGroupCode
            // 
            this.lblTargetGroupCode.AutoSize = true;
            this.lblTargetGroupCode.Location = new System.Drawing.Point(8, 98);
            this.lblTargetGroupCode.Name = "lblTargetGroupCode";
            this.lblTargetGroupCode.Size = new System.Drawing.Size(104, 13);
            this.lblTargetGroupCode.TabIndex = 0;
            this.lblTargetGroupCode.Text = "Target Group Code: ";
            // 
            // txtTargetGroupCode
            // 
            this.txtTargetGroupCode.Location = new System.Drawing.Point(185, 95);
            this.txtTargetGroupCode.Name = "txtTargetGroupCode";
            this.txtTargetGroupCode.Size = new System.Drawing.Size(212, 20);
            this.txtTargetGroupCode.TabIndex = 5;
            this.txtTargetGroupCode.Text = "EurTotal";
            
            // 
            // lblFeedName
            // 
            this.lblFeedName.AutoSize = true;
            this.lblFeedName.Location = new System.Drawing.Point(8, 73);
            this.lblFeedName.Name = "lblFeedName";
            this.lblFeedName.Size = new System.Drawing.Size(68, 13);
            this.lblFeedName.TabIndex = 0;
            this.lblFeedName.Text = "Feed Name: ";
            // 
            // lblJobRunID
            // 
            this.lblJobRunID.AutoSize = true;
            this.lblJobRunID.Location = new System.Drawing.Point(7, 49);
            this.lblJobRunID.Name = "lblJobRunID";
            this.lblJobRunID.Size = new System.Drawing.Size(67, 13);
            this.lblJobRunID.TabIndex = 0;
            this.lblJobRunID.Text = "Job Run ID: ";
            // 
            // txtJobRunID
            // 
            this.txtJobRunID.Location = new System.Drawing.Point(185, 44);
            this.txtJobRunID.Name = "txtJobRunID";
            this.txtJobRunID.Size = new System.Drawing.Size(212, 20);
            this.txtJobRunID.TabIndex = 3;
            this.txtJobRunID.Text = "32";
            // 
            // lblJobID
            // 
            this.lblJobID.AutoSize = true;
            this.lblJobID.Location = new System.Drawing.Point(7, 25);
            this.lblJobID.Name = "lblJobID";
            this.lblJobID.Size = new System.Drawing.Size(44, 13);
            this.lblJobID.TabIndex = 0;
            this.lblJobID.Text = "Job ID: ";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 277);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(455, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblPrismaLocales
            // 
            this.lblPrismaLocales.AutoSize = true;
            this.lblPrismaLocales.Location = new System.Drawing.Point(85, 125);
            this.lblPrismaLocales.Name = "lblPrismaLocales";
            this.lblPrismaLocales.Size = new System.Drawing.Size(97, 13);
            this.lblPrismaLocales.TabIndex = 10;
            this.lblPrismaLocales.Text = "PRISMA_Locale(s)";
            
            // 
            // lblCmcLocales
            // 
            this.lblCmcLocales.AutoSize = true;
            this.lblCmcLocales.Location = new System.Drawing.Point(85, 151);
            this.lblCmcLocales.Name = "lblCmcLocales";
            this.lblCmcLocales.Size = new System.Drawing.Size(79, 13);
            this.lblCmcLocales.TabIndex = 11;
            this.lblCmcLocales.Text = "CMC_Locale(s)";
            // 
            // DummyClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 299);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Name = "DummyClientForm";
            this.Text = "MSMQ Client";
            this.Load += new System.EventHandler(this.DummyClientForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtJobID;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label lblJobRunID;
        private System.Windows.Forms.TextBox txtJobRunID;
        private System.Windows.Forms.Label lblJobID;
        private System.Windows.Forms.Label lblTargetGroupCode;
        private System.Windows.Forms.TextBox txtTargetGroupCode;
        private System.Windows.Forms.Label lblFeedName;
        private System.Windows.Forms.TextBox txtLocales;
        private System.Windows.Forms.ComboBox cmbFeedName;
        private System.Windows.Forms.CheckBox chkLocale;
        private System.Windows.Forms.TextBox txtCmcLocales;
        private System.Windows.Forms.Label lblPrismaLocales;
        private System.Windows.Forms.Label lblCmcLocales;
    }
}

