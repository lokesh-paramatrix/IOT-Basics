﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.Xml;
using PrismaGeneral;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;

namespace PRISMA.LOR2.DummyClient
{
    public partial class DummyClientForm : Form
    {
        BusinessFacade.BusinessFacade businessFacade = new PRISMA.LOR2.BusinessFacade.BusinessFacade();

        public DummyClientForm()
        {
            InitializeComponent();
        }

        private void sendButton_Click(object sender, EventArgs e)
        {
           
            IParamSource objParamSource = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));

            FeedMessage feedMessage;
            DataSet dsLocales = null;
            DataSet dsTGnCHcode;
            DataSet dsLocaleCHcode;
            BusinessFacade.BusinessFacade BSF = new BusinessFacade.BusinessFacade();

            feedMessage = new FeedMessage();
            feedMessage.JobID = new Guid(txtJobID.Text);
            feedMessage.JobRunID = Convert.ToInt32(txtJobRunID.Text);
            //feedMessage.TargetGroupCode = txtTargetGroupCode.Text;
            feedMessage.FeedName = cmbFeedName.SelectedItem.ToString();
            dsTGnCHcode = ExecuteDataSet("sp_get_tg_channelcode", "Prisma", objParamSource);
            dsLocaleCHcode = ExecuteDataSet("sp_get_locale_channelcode", "Prisma", objParamSource);

            if (chkLocale.Checked == true)
            {
                string[] arrCmcLocales = txtCmcLocales.Text.Split(',');   //  
                int i = 0;                                               //Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>
                string strCmcLocale;                                    //
                foreach (string strLocale in txtLocales.Text.Split(','))
                {
                    //Added if condition by Arif for OEM and SPL catalog PR024
                    if ((feedMessage.FeedName == "Catalog") || (feedMessage.FeedName == "Categorisation") || (feedMessage.FeedName == "CategorisationWithoutProducts"))
                    {
                        //foreach (DataRow drLocale in dsLocales.Tables[0].Rows)
                        //{
                        strCmcLocale = arrCmcLocales[i++];    //Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'

                            //foreach (DataRow drChannelcode in dsTGnCHcode.Tables[0].Rows)
                            foreach (DataRow drChannelcode in dsLocaleCHcode.Tables[0].Rows)
                            {    
                                string tmpLocale = drChannelcode["locale"].ToString();
                                if (string.Equals(tmpLocale, strLocale, StringComparison.OrdinalIgnoreCase))
                                { //feedMessage.Locale = drLocale["Locale"].ToString();
                                    feedMessage.Locale = strLocale;
                                    feedMessage.Cmc_Locale = strCmcLocale;  //Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>
                                    
                                    feedMessage.ChannelCode = drChannelcode["channel_cd"].ToString().Trim();
                                    feedMessage.TargetGroupCode = drChannelcode["publ_target_group_cd"].ToString().Trim();
                                    BSF.ProcessFeedRequest(feedMessage);
                                }
                            }

                    }
                    else
                    {

                            feedMessage.Locale = strLocale;
                            feedMessage.TargetGroupCode = txtTargetGroupCode.Text;
                            feedMessage.Cmc_Locale = arrCmcLocales[i++];  //Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>
                            BSF.ProcessFeedRequest(feedMessage);

                    }

                }
            }
            else
            {
                objParamSource.SetParam("job_id", txtJobID.Text);
                objParamSource.SetParam("jrn_id", txtJobRunID.Text);
                objParamSource.SetParam("FeedName", cmbFeedName.SelectedItem.ToString());
                objParamSource.SetParam("tg_cd", txtTargetGroupCode.Text);
                objParamSource.SetParam("publ_target_group_cd", txtTargetGroupCode.Text);
                objParamSource.SetParam("locales", txtLocales.Text.Trim());

                //Commented by Arif for OEM and SPL catalog
                //dsLocales = ExecuteDataSet("sp_get_target_locales", "Prisma", objParamSource);

                //foreach (DataRow drLocale in dsLocales.Tables[0].Rows)
                //{
                //    feedMessage.Locale = drLocale["Locale"].ToString();
                //    BSF.ProcessFeedRequest(feedMessage);
                //}
                //Added by Arif for OEM and SPL catalog PR024
                BSF = new BusinessFacade.BusinessFacade(objParamSource);
                
            }
            
            MessageBox.Show("Message sent to the Queue.");
        }

        private DataSet ExecuteDataSet(string commandText, string RequiredDB, IParamSource v_objParams)
        {
            SqlDatabase objExecSpFromPS = new SqlDatabase(RequiredDB);
            return objExecSpFromPS.ExecuteDataSet(commandText, v_objParams);
        }

        private void DummyClientForm_Load(object sender, EventArgs e)
        {
            cmbFeedName.SelectedIndex = 0;
        }

                
    }
}
