﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Xml;
using PrismaGeneral;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Configuration;
using System.IO;

namespace LOR2.FeedMessageGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            string job_id;
            string jrn_id;
            string publ_target_group_cd;
            string feedName;


            job_id = System.Configuration.ConfigurationManager.AppSettings["job_id"].ToString();
            jrn_id = System.Configuration.ConfigurationManager.AppSettings["jrn_id"].ToString();
            publ_target_group_cd = System.Configuration.ConfigurationManager.AppSettings["publ_target_group_cd"].ToString();
            feedName = System.Configuration.ConfigurationManager.AppSettings["AllFeedNames"].ToString();

            PRISMA.LOR2.BusinessFacade.BusinessFacade businessFacade = new PRISMA.LOR2.BusinessFacade.BusinessFacade();

            IParamSource objParamSource = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));

            PRISMA.LOR2.BusinessFacade.BusinessFacade BSF = new PRISMA.LOR2.BusinessFacade.BusinessFacade();



            objParamSource.SetParam("job_id", job_id);
            objParamSource.SetParam("jrn_id",jrn_id);
            objParamSource.SetParam("FeedName",feedName);
            objParamSource.SetParam("tg_cd",publ_target_group_cd);
            objParamSource.SetParam("publ_target_group_cd", publ_target_group_cd);

            BSF = new PRISMA.LOR2.BusinessFacade.BusinessFacade(objParamSource);

            Console.WriteLine("Messages sent successfully");

            

        }

        private DataSet ExecuteDataSet(string commandText, string RequiredDB, IParamSource v_objParams)
        {
            SqlDatabase objExecSpFromPS = new SqlDatabase(RequiredDB);
            return objExecSpFromPS.ExecuteDataSet(commandText, v_objParams);
        }
    }
}
