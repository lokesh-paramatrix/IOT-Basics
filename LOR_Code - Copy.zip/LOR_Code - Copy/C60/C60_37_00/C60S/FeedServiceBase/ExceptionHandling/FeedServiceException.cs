﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceBase.ExceptionHandling
{
    /// <summary>
    /// Exception class for all feed services
    /// </summary>
    [Serializable]
    public class FeedServiceException : Exception
    {
        #region Member variables
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Creates a new instance of ServiceException class
        /// </summary>
        public FeedServiceException()
        {
        }

        /// <summary>
        /// Creates a new instance of ServiceException class
        /// </summary>
        public FeedServiceException(string message) : base(message)
        {
        }

        /// <summary>
        /// Creates a new instance of ServiceException class
        /// </summary>
        public FeedServiceException(string message, Exception inner) : base(message, inner)
        {
        }

        /// <summary>
        /// Creates a new instance of ServiceException class
        /// </summary>
        public FeedServiceException(Exception inner) : base(inner.Message, inner)
        {
        }

        /// <summary>
        /// Creates a new instance of ServiceException class
        /// </summary>
        protected FeedServiceException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context) : base(info, context)
        {
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
    }
}
