﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

#endregion System

#region Custom
using Common;
using PRISMA.LOR2.FeedServiceDefinition;
using PRISMA.LOR2.Common.Logging.Logging;

#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceBase
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class FeedServiceBase : IFeedServiceBase
    {
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        private Logger logger;

        #endregion Member variables
        
        #region Properties

        /// <summary>
        /// Gets the logger.
        /// </summary>
        /// <value>The logger.</value>
        protected Logger Logger
        {
            get
            {
                if (logger == null)
                {
                    logger = new Logger();
                }

                return logger;
            }
        }

        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
    }
}
