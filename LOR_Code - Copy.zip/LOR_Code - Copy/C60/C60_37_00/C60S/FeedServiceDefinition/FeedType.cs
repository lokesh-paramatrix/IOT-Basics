﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceDefinition
{
    /// <summary>
    /// 
    /// </summary>
    public enum FeedType
    {
        /// <summary>
        /// 
        /// </summary>
        PMTFeed,

        /// <summary>
        /// 
        /// </summary>
        CatalogFamilyFeed,

        /// <summary>
        /// 
        /// </summary>
        CatalogFeed,

        /// <summary>
        /// 
        /// </summary>
        CategorizationFeed
    }
}
