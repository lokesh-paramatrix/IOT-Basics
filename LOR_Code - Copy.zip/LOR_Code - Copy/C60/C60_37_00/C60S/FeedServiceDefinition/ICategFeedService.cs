﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

#endregion System

#region Custom

using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;
using System.ServiceModel.MsmqIntegration;

#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceDefinition
{
    /// <summary>
    /// service contract.  
    /// </summary>
    [ServiceContract]
    //[FaultContract(typeof(FeedServiceException))]
    public interface ICategFeedService : IFeedServiceBase
    {
        /// <summary>
        /// Processes the feed message.
        /// </summary>
        /// <param name="message">The message.</param>
        [OperationContract(IsOneWay = true)]
        void ProcessFeedMessage(FeedMessage message);
    }
}
