﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceDefinition
{
    /// <summary>
    /// NOTE: If you change the interface name "IFeedServiceBase" here, you must also update the reference to "IFeedServiceBase" in App.config.
    /// </summary>
    [ServiceContract]
    public interface IFeedServiceBase
    {
        
    }
}
