﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceDefinition.MessageTypes
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class FeedMessage
    {
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        private Guid jobID;

        /// <summary>
        /// 
        /// </summary>
	    private int jobRunID;

        /// <summary>
        /// 
        /// </summary>
	    private string feedName;

        /// <summary>
        /// 
        /// </summary>
	    private string targetGroupCode;

        /// <summary>
        /// 
        /// </summary>
        private string locale;

        #endregion Member variables

        #region Constructors
        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the job ID.
        /// </summary>
        /// <value>The job ID.</value>
        [DataMember]
        public Guid JobID
        {
            get
            {
                return jobID;
            }

            set
            {
                jobID = value;
            }
        }

        /// <summary>
        /// Gets or sets the job run ID.
        /// </summary>
        /// <value>The job run ID.</value>
        [DataMember]
        public int JobRunID
        {
            get
            {
                return jobRunID;
            }

            set
            {
                jobRunID = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the feed.
        /// </summary>
        /// <value>The name of the feed.</value>
        [DataMember]
        public string FeedName
        {
            get
            {
                return feedName;
            }
            
            set
            {
                feedName = value;
            }
        }

        /// <summary>
        /// Gets or sets the target group code.
        /// </summary>
        /// <value>The target group code.</value>
        [DataMember]
        public string TargetGroupCode
        {
            get
            {
                return targetGroupCode;
            }

            set
            {
                targetGroupCode = value;
            }
        }

        /// <summary>
        /// Gets or sets the locales.
        /// </summary>
        /// <value>The locales.</value>
        [DataMember]
        public string Locale
        {
            get
            {
                return locale;
            }

            set
            {
                locale = value;
            }
        }

        #endregion Properties
    }
}
