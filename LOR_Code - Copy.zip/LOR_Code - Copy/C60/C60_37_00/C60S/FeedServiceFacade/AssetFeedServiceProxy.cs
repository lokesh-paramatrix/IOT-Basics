﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

#endregion System

#region Custom

using PRISMA.LOR2.FeedServiceDefinition;
using PRISMA.LOR2.FeedServiceFacade;
using PRISMA.LOR2.Common;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;
using PRISMA.LOR2.FeedServiceFacade.Queueing;

#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceFacade
{
    /// <summary>
    /// 
    /// </summary>
    public class AssetFeedServiceProxy : FeedServiceProxyBase<IAssetFeedService>, IAssetFeedService
    {
        #region Member variables
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AssetFeedServiceProxy"/> class.
        /// </summary>
        /// <param name="endpoint">The endpoint.</param>
        public AssetFeedServiceProxy(string endpoint)
            : base(endpoint)
        {
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Processes the feed message.
        /// </summary>
        /// <param name="message">The message.</param>
        public void ProcessFeedMessage(FeedMessage message)
        {
            base.Enqueue(Constants.ASSET_FEED_SERVICE_OPERATION_BEHAVIOR, message);
        }

        #endregion Public Methods

        #endregion Methods
    }
}
