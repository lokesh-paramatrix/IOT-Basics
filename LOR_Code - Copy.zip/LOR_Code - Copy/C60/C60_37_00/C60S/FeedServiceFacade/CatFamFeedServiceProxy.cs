﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PRISMA.LOR2.FeedServiceFacade.Queueing;
using PRISMA.LOR2.FeedServiceDefinition;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;

namespace PRISMA.LOR2.FeedServiceFacade
{
    public class CatFamFeedServiceProxy : FeedServiceProxyBase<ICatFamFeedService>, ICatFamFeedService
    {
        #region Member variables
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CatFeedServiceProxy"/> class.
        /// </summary>
        /// <param name="endpoint">The endpoint.</param>
        public CatFamFeedServiceProxy(string endpoint)
            : base(endpoint)
        {
        
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Processes the feed message.
        /// </summary>
        /// <param name="message">The message.</param>
        public void ProcessFeedMessage(FeedMessage message)
        {
            base.Enqueue("ProcessFeedMessage", message);
        }

        #endregion Public Methods

        #endregion Methods
    }
}
