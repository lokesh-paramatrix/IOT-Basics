﻿#region Namespaces

#region System

using System;
using System.ServiceModel;
using System.Reflection;
using System.Diagnostics;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceFacade.Queueing
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class FeedServiceProxyBase<T> : ClientBase<T> where T : class
    {
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        //public readonly string ResponseAddress;
        internal readonly string ResponseAddress;

        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseClientBase&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        public FeedServiceProxyBase(string responseAddress)
        {
            ResponseAddress = responseAddress;
            QueuedServiceHelper.VerifyQueue(Endpoint);
            Debug.Assert(Endpoint.Binding is NetMsmqBinding);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseClientBase&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        /// <param name="endpointName">Name of the endpoint.</param>
        public FeedServiceProxyBase(string responseAddress, string endpointName)
            : base(endpointName)
        {
            ResponseAddress = responseAddress;
            QueuedServiceHelper.VerifyQueue(Endpoint);
            Debug.Assert(Endpoint.Binding is NetMsmqBinding);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseClientBase&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        /// <param name="endpointName">Name of the endpoint.</param>
        /// <param name="remoteAddress">The remote address.</param>
        public FeedServiceProxyBase(string responseAddress, string endpointName, string remoteAddress)
            : base(endpointName, remoteAddress)
        {
            ResponseAddress = responseAddress;
            QueuedServiceHelper.VerifyQueue(Endpoint);
            Debug.Assert(Endpoint.Binding is NetMsmqBinding);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseClientBase&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        /// <param name="endpointName">Name of the endpoint.</param>
        /// <param name="remoteAddress">The remote address.</param>
        public FeedServiceProxyBase(string responseAddress, string endpointName, EndpointAddress remoteAddress)
            : base(endpointName, remoteAddress)
        {
            ResponseAddress = responseAddress;
            QueuedServiceHelper.VerifyQueue(Endpoint);
            Debug.Assert(Endpoint.Binding is NetMsmqBinding);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseClientBase&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        /// <param name="binding">The binding.</param>
        /// <param name="remoteAddress">The remote address.</param>
        public FeedServiceProxyBase(string responseAddress, NetMsmqBinding binding, EndpointAddress remoteAddress)
            : base(binding, remoteAddress)
        {
            ResponseAddress = responseAddress;
            QueuedServiceHelper.VerifyQueue(Endpoint);
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// Enqueues the specified operation.
        /// </summary>
        /// <param name="operation">The operation.</param>
        /// <param name="args">The args.</param>
        /// <returns></returns>
        protected string Enqueue(string operation, params object[] args)
        {
            using (OperationContextScope contextScope = new OperationContextScope(InnerChannel))
            {
                string methodId = GenerateMethodId();
                FeedServiceProxyContext responseContext = new FeedServiceProxyContext(ResponseAddress, methodId);
                FeedServiceProxyContext.Current = responseContext;

                Type contract = typeof(T);
                MethodInfo methodInfo = contract.GetMethod(operation);
                methodInfo.Invoke(Channel, args);

                return responseContext.MethodId;
            }
        }

        /// <summary>
        /// Generates the method id.
        /// </summary>
        /// <returns></returns>
        protected virtual string GenerateMethodId()
        {
            return Guid.NewGuid().ToString();
        }

        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
    }
}
