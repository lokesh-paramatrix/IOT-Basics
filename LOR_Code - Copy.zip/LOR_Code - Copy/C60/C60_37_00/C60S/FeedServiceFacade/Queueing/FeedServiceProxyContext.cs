﻿#region Namespaces

#region System

using System;
using System.Messaging;
using System.ServiceModel;
using System.Diagnostics;
using System.Threading;
using System.Runtime.Serialization;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.FeedServiceFacade.Queueing
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class FeedServiceProxyContext
    {
        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        //public readonly string ResponseAddress;
        internal readonly string ResponseAddress;

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        //public readonly string FaultAddress;
        internal readonly string FaultAddress;

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        //public readonly string MethodId;
        internal readonly string MethodId;

        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseContext"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        /// <param name="methodId">The method id.</param>
        public FeedServiceProxyContext(string responseAddress, string methodId)
            : this(responseAddress, methodId, null)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseContext"/> class.
        /// </summary>
        /// <param name="responseContext">The response context.</param>
        public FeedServiceProxyContext(FeedServiceProxyContext responseContext)
            : this(responseContext.ResponseAddress, responseContext.MethodId, responseContext.FaultAddress)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseContext"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        public FeedServiceProxyContext(string responseAddress)
            : this(responseAddress, Guid.NewGuid().ToString())
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResponseContext"/> class.
        /// </summary>
        /// <param name="responseAddress">The response address.</param>
        /// <param name="methodId">The method id.</param>
        /// <param name="faultAddress">The fault address.</param>
        public FeedServiceProxyContext(string responseAddress, string methodId, string faultAddress)
        {
            ResponseAddress = responseAddress;
            MethodId = methodId;
            FaultAddress = faultAddress;
        }

        #endregion Constructors

        #region Properties
        
        /// <summary>
        /// Gets or sets the current.
        /// </summary>
        /// <value>The current.</value>
        public static FeedServiceProxyContext Current
        {
            get
            {
                OperationContext context = OperationContext.Current;
                if (context == null)
                {
                    return null;
                }
                try
                {
                    return context.IncomingMessageHeaders.GetHeader<FeedServiceProxyContext>("ResponseContext", "ServiceModelEx");
                }
                catch (MessageHeaderException exception)
                {
                    Debug.Assert(exception.Message == "There is not a header with name ResponseContext and namespace ServiceModelEx in the message.");
                    return null;
                }
                catch (Exception excep)
                {
                    throw;
                }
            }
            set
            {
                OperationContext context = OperationContext.Current;
                Debug.Assert(context != null);
                //Having multiple ResponseContext headers is an error
                bool headerExists = false;
                try
                {
                    context.OutgoingMessageHeaders.GetHeader<FeedServiceProxyContext>("ResponseContext", "ServiceModelEx");
                    headerExists = true;
                }
                catch (MessageHeaderException exception)
                {
                    Debug.Assert(exception.Message == "There is not a header with name ResponseContext and namespace ServiceModelEx in the message.");
                }
                if (headerExists)
                {
                    throw new InvalidOperationException("A header with name ResponseContext and namespace ServiceModelEx already exists in the message.");
                }
                MessageHeader<FeedServiceProxyContext> responseHeader = new MessageHeader<FeedServiceProxyContext>(value);
                context.OutgoingMessageHeaders.Add(responseHeader.GetUntypedHeader("ResponseContext", "ServiceModelEx"));
            }
        }

        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
    }
}





