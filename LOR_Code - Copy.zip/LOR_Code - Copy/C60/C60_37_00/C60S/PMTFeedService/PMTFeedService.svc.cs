﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Xml;
using System.ServiceModel.MsmqIntegration;
using System.Threading;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using PrismaGeneral;
#endregion System

#region Custom
using PRISMA.LOR2.BLL;
using PRISMA.LOR2.Common;
using PRISMA.LOR2.FeedServiceDefinition;
using PRISMA.LOR2.FeedServiceDefinition.MessageTypes;

using IsDnaJobManagement;
using IsDNAImportTypelib;
using System.Transactions;
using System.Collections;
using System.ServiceModel.Dispatcher;
using System.Messaging;
using System.Configuration;
using System.IO;
using System.Data;
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.PMTFeedService
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single,
        TransactionTimeout="01:00:00")]
    public class PMTFeedService : FeedServiceBase.FeedServiceBase, IPMTFeedService, IErrorHandler
    {
        static int iCounter;
        static Thread[] threads;
        static Thread threadHolder = null;
        static Stack<Thread> freeThreads = null;
        Dictionary<String, int> msgStatus = new Dictionary<String, int>();
        static Thread t1 = null;
        static string prevMessageID = "";
        static Queue<FeedMessage> queCachedMessages;

        // PR021 Aman
        string strFullDestinationPathPMT = string.Empty;
        
        // End

        #region Member variables

        /// <summary>
        /// 
        /// </summary>
        private delegate void CallCreatePMTFeedXMLFile(IParamSource objParams);

        #endregion Member variables

        #region Constructors
        static PMTFeedService()
        {
            try
            {
                queCachedMessages = new Queue<FeedMessage>();
                string maxThreads;
                maxThreads = ConfigurationManager.AppSettings["MaxThreads"];

                if (maxThreads == null)
                    maxThreads = "10";
                threads = new Thread[Convert.ToInt32(maxThreads)];

                freeThreads = new Stack<Thread>();

                foreach (Thread thread in threads)
                {
                    freeThreads.Push(thread);
                }
            }
            catch (Exception excep)
            {
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                throw;
            }
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        private TextWriter Tw; //Added for KBA
        /// <summary>
        /// Creates the PMT feed XML file.
        /// </summary>
        /// <param name="message">The message.</param>
        private void CreatePMTFeedXMLFile(object feedMessage)
        {
            string strXMLFileName = "";
            string strXMLFileNamewoext = "";
            string strXMLSchema = "";
            XmlNode objComponentData = null;
            IGenericStep xGen;
            IParamSource objParamSource = null;
            IParamSource objParamSettings = null;
            FeedMessage message = (FeedMessage)feedMessage;
            ComponentData compData;
            DataSet dsCMCDetails = null;
            ICommonRead objLOR2Queries = null;
            try
            {
                Logger.LogInfoMessage("START:CreatePMTFeedXMLFile(FeedMessage message):TargetGroup:" + message.TargetGroupCode + " Locale:" + message.Locale);

                strXMLSchema = System.Configuration.ConfigurationManager.AppSettings["SchemaUrl"].ToString();

                objParamSource = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC08Cll.C08clsStateContainerVB"));
                objParamSettings = (PrismaGeneral.IParamSource)Activator.CreateInstance(Type.GetTypeFromProgID("PrismaC07Settings.C07clsSettings"));
                xGen = new PRISMA.LOR2.BLL.XMLGenerator();

                objParamSource.SetParam("xml_schema_name", strXMLSchema);
                objParamSource.SetParam("jrn_id", message.JobRunID.ToString());
                objParamSource.SetParam("locale", message.Locale);
                objParamSource.SetParam("publ_target_group_cd", message.TargetGroupCode);
                objParamSource.SetParam("FeedName", message.FeedName);
                objParamSource.SetParam("TargetGroupCode", message.TargetGroupCode);
                objParamSource.SetParam("cmc_locale", message.Cmc_Locale);//Added by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>
                objLOR2Queries = new LOR2Queries();

                //log start time for the current job
                objParamSource.SetParam("where", "log_locale_run_start_time");
                objLOR2Queries.ReadFilter(objParamSource);

                //objParamSource.SetParam("where", "cmc-locale-details");
                //dsCMCDetails = objLOR2Queries.ReadFilter(objParamSource);
                //if (dsCMCDetails.Tables[0].Rows.Count < 1)
                //{
                //    objParamSource.SetParam("cmc_locale", message.Locale);
                //}
                //else
                //{
                //    foreach (DataColumn dc in dsCMCDetails.Tables[0].Columns)
                //    {
                //        objParamSource.SetParam(dc.ColumnName, dsCMCDetails.Tables[0].Rows[0][dc].ToString());
                //    }
                //}//Commented by Rahul Mulchandani for 'Multiple Cmc locale for single prisma locale'<PR029>

                compData = new ComponentData(message.FeedName);
                compData.Create(ref objComponentData, objParamSource, 1);
                //CreateComponentData(ref objComponentData, objParamSource, 1);


                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress))
                {
                    strXMLFileName = xGen.FProcessData("", objParamSource, objComponentData, new clsJobLogger());

                    #region Removing keyBenefitAreas
                   //StringBuilder data = new StringBuilder(File.ReadAllText(strXMLFileName, Encoding.UTF8));

                    //data = data.Replace("<KeyBenefitAreas>", String.Empty);
                    //data = data.Replace("</KeyBenefitAreas>", String.Empty);

                    //File.WriteAllText(strXMLFileName, data.ToString(), Encoding.UTF8);
                    #endregion


                    #region New Code added for replacing <KeyBebefitAreas> Tag

                    FileInfo readfileSize = new FileInfo(strXMLFileName);
                    long maxFileSize = long.Parse(System.Configuration.ConfigurationManager.AppSettings["FileSize"].ToString());

                    if (readfileSize.Length < maxFileSize) //if file size is < 400 MB directly replace
                    {
                        StringBuilder data = new StringBuilder(File.ReadAllText(strXMLFileName, Encoding.UTF8));

                        data = data.Replace("<KeyBenefitAreas>", String.Empty);
                        data = data.Replace("</KeyBenefitAreas>", String.Empty);

                        File.WriteAllText(strXMLFileName, data.ToString(), Encoding.UTF8);
                    }
                    else
                    {
                        StringBuilder str1;
                        String strSubFileName;
                        int blockSize = 1000;
                        TextWriter w = null;
                        TextReader r = null;
                        char[] charArray = new char[blockSize];
                        char[] prevCharArray = new char[blockSize];
                        int prevCharArray_VALID_DATA = blockSize;
                        int charArray_VALID_DATA = blockSize;

                        int length = strXMLFileName.Length;
                        strSubFileName = strXMLFileName.Substring(0, (length - 4));
                        strXMLFileNamewoext = strSubFileName;
                        try
                        {   //
                            // File.Move(strXMLFileName, strXMLFileNamewoext + "_new.xml");
                            // r = new StreamReader(File.Open(strXMLFileName + "_new", FileMode.Open, FileAccess.Read));
                            // w = new StreamWriter(File.Open(strXMLFileName, FileMode.Create));

                            // r = new StreamReader(File.Open(strXMLFileNamewoext + "_new.xml", FileMode.Open, FileAccess.Read));
                            r = new StreamReader(File.Open(strXMLFileName, FileMode.Open, FileAccess.Read));
                            w = new StreamWriter(File.Open(strXMLFileNamewoext + "_new.xml", FileMode.Create));


                            int currIndex = 0;
                            str1 = new StringBuilder(blockSize * 2);


                            do
                            {
                                str1.Insert(0, prevCharArray, 0, prevCharArray_VALID_DATA);
                                currIndex = r.ReadBlock(charArray, 0, blockSize);

                                // str1.Insert(str1.Length, charArray, 0, prevCharArray_VALID_DATA + currIndex);
                                str1.Append(charArray);
                                str1.Remove(prevCharArray_VALID_DATA + currIndex, str1.Length - (prevCharArray_VALID_DATA + currIndex));

                                str1 = str1.Replace("<KeyBenefitAreas>", "");
                                str1 = str1.Replace("</KeyBenefitAreas>", "");
                                if (currIndex == blockSize)
                                {
                                    if (str1.Length > blockSize + "</KeyBenifitAreas>".Length)
                                    {
                                        charArray_VALID_DATA = blockSize;
                                        prevCharArray_VALID_DATA = str1.Length - blockSize;
                                    }
                                    else
                                    {
                                        prevCharArray_VALID_DATA = "</KeyBenefitAreas>".Length;
                                        charArray_VALID_DATA = str1.Length - prevCharArray_VALID_DATA;
                                    }

                                    str1.CopyTo(0, charArray, 0, charArray_VALID_DATA);
                                    str1.CopyTo(charArray_VALID_DATA, prevCharArray, 0, prevCharArray_VALID_DATA);

                                    str1.Remove(0, str1.Length);


                                    if (charArray[0] != '\0')
                                        w.Write(charArray, 0, charArray_VALID_DATA);
                                }
                            } while (currIndex == blockSize);

                            w.Write(prevCharArray, 0, prevCharArray_VALID_DATA);
                            w.Write(charArray, 0, currIndex);

                        }

                        finally
                        {
                            if (w != null)
                                w.Close();
                            if (r != null)
                                r.Close();
                            File.Delete(strXMLFileName);
                            File.Move(strXMLFileNamewoext + "_new.xml", strXMLFileName);
                        }

                        

                        // START -  New code for replacing KBA's
                        //XmlReaderSettings settings = new XmlReaderSettings();
                        //settings.IgnoreWhitespace = true;

                        //File.Move(strXMLFileName, strXMLFileName + "_new");

                        //XmlReader xR = XmlReader.Create(strXMLFileName + "_new", settings);
                        //XmlWriter xW = XmlWriter.Create(strXMLFileName);

                        //while (xR.Read())
                        //{
                        //    switch (xR.NodeType)
                        //    {
                        //        case XmlNodeType.Element:
                        //            if (xR.Name == "KeyBenefitAreas")
                        //            {
                        //                KBA(xR.ReadSubtree(), xW);
                        //            }
                        //            else
                        //            {
                        //                xW.WriteStartElement(xR.Name);
                        //                while (xR.MoveToNextAttribute())
                        //                    xW.WriteAttributes(xR, false);
                        //            }
                        //            break;
                        //        case XmlNodeType.Text:
                        //            xW.WriteString(xR.Value);
                        //            break;
                        //        case XmlNodeType.CDATA:
                        //            break;
                        //        case XmlNodeType.ProcessingInstruction:
                        //            xW.WriteProcessingInstruction(xR.Name, xR.Value);
                        //            break;
                        //        case XmlNodeType.Comment:
                        //            xW.WriteComment(xR.Value);
                        //            break;
                        //        case XmlNodeType.Whitespace:
                        //            xW.WriteWhitespace(xR.Value);
                        //            break;
                        //        case XmlNodeType.SignificantWhitespace:
                        //            break;
                        //        case XmlNodeType.EndElement:
                        //            if (xR.Name != "KeyBenefitAreas")
                        //            {
                        //                xW.WriteEndElement();
                        //            }
                        //            break;
                        //    }
                        //}
                        //xW.Close();
                        ////END - New Code for replacing KBA's

                    }//ELSE END TAG
                    #endregion

                }

                xGen = null;
                xGen = new BLL.clsXMLValidator();
                compData.Create(ref objComponentData, objParamSource, 2);
                strXMLFileName = xGen.FProcessData(strXMLFileName, objParamSource, objComponentData, new clsJobLogger());

                xGen = null;
                xGen = new BLL.BackupAndRestore();
                compData.Create(ref objComponentData, objParamSource, 3);
                strXMLFileName = xGen.FProcessData(strXMLFileName, objParamSource, objComponentData, new clsJobLogger());

                //log the file size of the extraction of the current locale run
                long fileSize = FileHelper.FileSize(strXMLFileName);
                objParamSource.SetParam("file_size", fileSize.ToString());
                objParamSource.SetParam("where", "log_locale_run_file_size");
                objLOR2Queries.ReadFilter(objParamSource);

                //log end time for the current job
                objParamSource.SetParam("where", "log_locale_run_end_time");
                objLOR2Queries.ReadFilter(objParamSource);
                


                Logger.LogInfoMessage("END:CreatePMTFeedXMLFile(FeedMessage message):TargetGroup:" + message.TargetGroupCode + " Locale:" + message.Locale);
            }
            catch (Exception excep)
            {
                objParamSource.SetParam("lrn_status", "FAILED");
                objParamSource.SetParam("where", "log_locale_run_status");
                objLOR2Queries.ReadFilter(objParamSource);
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                Logger.LogErrorMessage(excep.TargetSite.DeclaringType.ToString() + "." + excep.TargetSite.ToString() + ":" + excep.Message);
            }
            finally
            {
                if (objParamSource != null) ((IDisposable)objParamSource).Dispose();
                if (objParamSettings != null) ((IDisposable)objParamSettings).Dispose();
                if (dsCMCDetails != null) dsCMCDetails.Dispose();
                objLOR2Queries = null;

                compData = null;
            }
        }
        // Added for replacing KeyBenefit Areas
        private void KBA(XmlReader xmlrd, XmlWriter xW)
        {
            while (xmlrd.Read())
            {
                if (xmlrd.Name != "KeyBenefitAreas")
                {
                    switch (xmlrd.NodeType)
                    {
                        case XmlNodeType.Element:
                            xW.WriteStartElement(xmlrd.Name);
                            while (xmlrd.MoveToNextAttribute())
                                xW.WriteAttributes(xmlrd, false);
                            break;
                        case XmlNodeType.Text:
                            xW.WriteString(xmlrd.Value);
                            break;
                        case XmlNodeType.EndElement:
                            xW.WriteEndElement();
                            break;
                    }
                }
            }
        }

        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Processes the feed message.
        /// </summary>
        /// <param name="message">The message.</param>
        [OperationBehavior(TransactionScopeRequired = true)]
        public void ProcessFeedMessage(FeedMessage message)
        {
            Thread currThread = null;

            #region PR021 - Aman

            string strDestinationPath = System.Configuration.ConfigurationManager.AppSettings["xml_destination_drive"].ToString();

            string strFileDestination = System.Configuration.ConfigurationManager.AppSettings["LOR2FolderStructure"].ToString();

            int count = strFileDestination.IndexOf("\"");

            int count1 = strFileDestination.IndexOf("\"", count + 1);

            string strLORFolderNamePMT = strFileDestination.Substring(count + 1, count1 - count - 1);

            strFullDestinationPathPMT = strDestinationPath + @"\" + strLORFolderNamePMT + @"\" + message.TargetGroupCode + @"\" + message.FeedName;

            strFileDestination = strFullDestinationPathPMT + @"\CONTENT-LOADED.xml";

            # endregion 

            
            try
            {
                #region Threading Part

                if (freeThreads.Count > 0)
                {
                    currThread = freeThreads.Pop();
                }
                else
                {
                    //// if not vacant
                    queCachedMessages.Enqueue(message);
                    return;
                }

                //For Issue PR021 - Aman
                if (File.Exists(strFileDestination))
                {
                    currThread = new Thread(new ParameterizedThreadStart(ThreadTask));
                    //start the thread
                    currThread.Start(message);
                }
                #endregion //Threading Part
            }
            catch (Exception excep)
            {
                System.Diagnostics.Debug.Assert(excep.Message != "Maximum number of threads reached");
                ExceptionPolicy.HandleException(excep, Constants.LOG_ONLY_POLICY);
                Logger.LogErrorMessage(excep.TargetSite.DeclaringType.ToString() + "." + excep.TargetSite.ToString() + ":" + excep.Message);
            }
        }
        private void ThreadTask(object feedMessage)
        {
            string strTempFileName;
            CreatePMTFeedXMLFile(feedMessage);

            while (queCachedMessages.Count > 0)
            {
                CreatePMTFeedXMLFile(queCachedMessages.Dequeue());
            }

            freeThreads.Push(Thread.CurrentThread);

            #region PR021 - Aman

            if (freeThreads.Count == Convert.ToInt32(ConfigurationManager.AppSettings["MaxThreads"]))
            {
                //string strFileDestination = System.Configuration.ConfigurationManager.AppSettings["Content_Ready_FileLocation"].ToString();

                //strFileDestination = strFileDestination + @"\CONTENT-READY.xml";

                string strFileDestination = strFullDestinationPathPMT + @"\CONTENT-READY.xml";

                XmlDocument xDoc = new XmlDocument();

                // Create root node.   
                XmlElement xElemRoot = xDoc.CreateElement("CONTENT-READY");
                xElemRoot.InnerText = "The Feed is complete.";

                xDoc.AppendChild(xElemRoot);

                xDoc.Save(strFileDestination);

                string strFileDest = strFullDestinationPathPMT + @"\CONTENT-LOADED.xml";

                if (File.Exists(strFileDest))
                {
                    File.Delete(strFileDest);
                }
            }

            # endregion
        }

        #endregion Public Methods

        #endregion Methods

        #region IErrorHandler Members

        public bool HandleError(Exception error)
        {
            throw new NotImplementedException();
        }

        public void ProvideFault(Exception error, System.ServiceModel.Channels.MessageVersion version, ref System.ServiceModel.Channels.Message fault)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
