﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.ServiceModel;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using PRISMA.LOR2.Common.Logging.Logging;
using PRISMA.LOR2.Common;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.PMTFeedServiceHost
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PMTFeedServiceHost : System.ServiceProcess.ServiceBase
    {
        #region Member variables

        private Logger logger;
        private ServiceHost pmtFeedServiceHost = null;
        
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PMTFeedServiceHost"/> class.
        /// </summary>
        public PMTFeedServiceHost()
        {
            InitializeComponent();
            logger = new Logger();
        }

        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods

        /// <summary>
        /// When implemented in a derived class, executes when a Start command is sent to the service by the Service Control Manager (SCM) or when the operating system starts (for a service that starts automatically). Specifies actions to take when the service starts.
        /// </summary>
        /// <param name="args">Data passed by the start command.</param>
        protected override void OnStart(string[] args)
        {
            try
            {
                logger.LogInfoMessage("PMTFeedServiceHost - Start: void override void OnStart(string[] args).");

                if (pmtFeedServiceHost != null)
                {
                    pmtFeedServiceHost.Close();
                }

                //Create a ServiceHost for the PMTFeedService type and provide the base address.
                pmtFeedServiceHost = new ServiceHost(typeof(PMTFeedService.PMTFeedService));
                
                //Open the ServiceHostBase to create listeners and start listening for messages.
                pmtFeedServiceHost.Open();
                

                logger.LogInfoMessage("PMTFeedServiceHost - End: void override void OnStart(string[] args).");
            }

            catch (Exception ex)
            {
                logger.LogErrorMessage(ex.Message + ":\r\n" + ex.StackTrace);
                pmtFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// When implemented in a derived class, executes when a Stop command is sent to the service by the Service Control Manager (SCM). Specifies actions to take when a service stops running.
        /// </summary>
        protected override void OnStop()
        {
            try
            {
                logger.LogInfoMessage("PMTFeedServiceHost - Start: void OnStop().");
                    
                if (pmtFeedServiceHost != null)
                {
                    pmtFeedServiceHost.Close();
                    pmtFeedServiceHost = null;
                }

                logger.LogInfoMessage("PMTFeedServiceHost - End: void OnStop().");
            }

            catch (Exception ex)
            {
                pmtFeedServiceHost = null;
                bool rethrow = ExceptionPolicy.HandleException(ex, Constants.LOG_ONLY_POLICY);

                if (rethrow)
                {
                    throw;
                }
            }
        }

        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods
    }
}