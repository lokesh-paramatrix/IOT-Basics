﻿#region Namespaces

#region System

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.PMTFeedServiceHost
{
    /// <summary>
    /// 
    /// </summary>
    [RunInstaller(true)]
    public partial class PMTFeedServiceHostInstaller : Installer
    {
        #region Member variables
        #endregion Member variables

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PMTFeedServiceHostInstaller"/> class.
        /// </summary>
        public PMTFeedServiceHostInstaller()
        {
            InitializeComponent();
        }

        #endregion Constructors        

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods
        #endregion Public Methods

        #endregion Methods

        #region Event handlers
        #endregion Event handlers
    }
}
