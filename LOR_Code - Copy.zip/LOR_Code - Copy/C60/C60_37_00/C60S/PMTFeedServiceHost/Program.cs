﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.ServiceProcess;
using System.Text;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.PMTFeedServiceHost
{
    /// <summary>
    /// 
    /// </summary>
    static class Program
    {
        #region Member variables
        #endregion Member variables

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Protected/Overriden Methods
        #endregion Protected/Overriden Methods

        #region Public Methods

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            System.ServiceProcess.ServiceBase[] ServicesToRun;
            ServicesToRun = new System.ServiceProcess.ServiceBase[] 
			{ 
				new PRISMA.LOR2.PMTFeedServiceHost.PMTFeedServiceHost() 
			};
            System.ServiceProcess.ServiceBase.Run(ServicesToRun);
        }

        #endregion Public Methods

        #endregion Methods
    }
}
