using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using System.Text;
using Html2Rtb;

namespace Html_2_Rtb
{
    /**
     * Method Name : AssetCaptionTextProcessing
     * Method Description : Handles transformation of asset captions
     * Creation Date : 25/11/2009
     * Creator : Siddharth Naik
     * History :
     *      Version     Date            Author              Remarks
     *      1           25/11/2009      Siddharth Naik      First creation         
     */
    abstract class AssetCaptionTextProcessing_ctn
    {
        /**
         * Method Name : Transform
         * Method Description : Adds the assest caption texts.
         * Creation Date : 25/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           25/11/2009      Siddharth Naik      First creation
         */
        public static void Transform(DataTable srcTable, String vis_type_cd, String CTNvalue, String comfamcd, String bucd, String brandcd, String dim_richtext, String dim_table_seq_nr, String cmcTextBlockType)
        {
            srcTable.Columns.Add("CTN");
            srcTable.Columns.Add("locale");
            srcTable.Columns.Add("caption_text");

            SqlConnection con = new SqlConnection(Transformer.GetConnectionString());

            SqlCommand selectCommand = new SqlCommand(Transformer.assetCaptionTextStoredProcs.Get("AllAssetCaptionTexts_ctn"), con);
            selectCommand.CommandType = CommandType.StoredProcedure;
            selectCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;

            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = selectCommand;

            DataSet allCaptionTexts = new DataSet();
            allCaptionTexts.Locale = Program.CultureInfo;

            sda.Fill(allCaptionTexts);

            DataView allCaptionTextsDV = new DataView(allCaptionTexts.Tables[0], String.Empty, "CTN, locale", DataViewRowState.OriginalRows);

            for (int rowIndex = 0; rowIndex < allCaptionTextsDV.Count; rowIndex++)
            {
                DataRow dr = allCaptionTextsDV[rowIndex].Row;

                String CTN = Convert.ToString(dr["CTN"], Program.CultureInfo).Trim();
                String lan_id = Convert.ToString(dr["locale"], Program.CultureInfo).Trim();

                DataRowView[] captionTexts = allCaptionTextsDV.FindRows(new Object[] { CTN, lan_id });

                rowIndex = rowIndex + captionTexts.Length - 1;

                XmlDocument cmcContentDoc = new XmlDocument();
                XmlElement richTextBlock = cmcContentDoc.CreateElement("RichText");
                richTextBlock.Attributes.Append(cmcContentDoc.CreateAttribute("type"));
                richTextBlock.Attributes[0].Value = cmcTextBlockType.Trim(); ;

                // every drv is 1 item
                int rankCounter = 0;
                int intdoctypecount = 0; //Added by NB
                List<String> usedDocTypeWithSubTypes = new List<String>(); //Added by NB

                foreach (DataRowView drv in captionTexts)
                {
                    //<<START>> ORIGINAL CODE
                    //XmlElement itemNode = cmcContentDoc.CreateElement("Item");
                    //itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                    //itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("docType"));

                    ////itemNode.Attributes[0].Value = "1";
                    //itemNode.Attributes[0].Value = ((int)(++rankCounter)).ToString(Program.CultureInfo);
                    //itemNode.Attributes[1].Value = Convert.ToString(drv["cmc_doc_type"], Program.CultureInfo).Trim();

                    //XmlElement labelNode = cmcContentDoc.CreateElement("Head");
                    //labelNode.InnerText = Convert.ToString(drv["caption_text"], Program.CultureInfo).Trim();
                    //itemNode.AppendChild(labelNode);

                    //richTextBlock.AppendChild(itemNode);
                    //<<END>> ORIGINAL CODE


                    //<<START>> Added by NB

                    XmlElement itemNode = cmcContentDoc.CreateElement("Item");
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("rank"));
                    itemNode.Attributes.Append(cmcContentDoc.CreateAttribute("docType"));

                    //itemNode.Attributes[0].Value = "1";
                    itemNode.Attributes[0].Value = ((int)(++rankCounter)).ToString(Program.CultureInfo);

                    if (string.IsNullOrEmpty(Convert.ToString(drv["sub_type"])))
                    {
                        itemNode.Attributes[1].Value = Convert.ToString(drv["cmc_doc_type"], Program.CultureInfo).Trim();
                        intdoctypecount = 0; 
                    }
                    else
                    {
                        if (!usedDocTypeWithSubTypes.Contains(drv["vis_type_cd"].ToString().Trim()))
                        {
                            usedDocTypeWithSubTypes.Add(drv["vis_type_cd"].ToString().Trim());
                            intdoctypecount = 0;
                        }

                        if (intdoctypecount == 0)
                        {
                            itemNode.Attributes[1].Value = Convert.ToString(drv["cmc_doc_type"], Program.CultureInfo).Trim();
                            intdoctypecount++;
                        }
                        else
                        {
                            itemNode.Attributes[1].Value = (drv["sub_type"].ToString().Trim().Substring(0, 1) + Convert.ToString(intdoctypecount) + "_");
                            intdoctypecount++;
                        }
                    }
                    XmlElement labelNode = cmcContentDoc.CreateElement("Head");
                    labelNode.InnerText = Convert.ToString(drv["caption_text"], Program.CultureInfo).Trim();
                    itemNode.AppendChild(labelNode);

                    richTextBlock.AppendChild(itemNode);
                    //<<END>> 
                }

                if (richTextBlock.HasChildNodes)
                {
                    cmcContentDoc.AppendChild(richTextBlock);
                }

                DataRow newRow = srcTable.NewRow();

                newRow["CTN"] = dr["CTN"];
                newRow["locale"] = dr["locale"];
                newRow["caption_text"] = cmcContentDoc.OuterXml;
                srcTable.Rows.Add(newRow);

            }
        }
    }
}
