using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Win32;
using System.Collections.Specialized;
using System.Text;
using System.IO;
using Html_2_Rtb;

namespace Html2Rtb
{
    /**
    * Class Name : Transformer
    * Class Description : Gets the data to be transformed. Maps the vis_type_cd to structure.
    * Creation Date : 16/11/2009
    * Creator : Siddharth Naik
    * History :
    *      Version     Date            Author              Remarks
    *      1           16/11/2009      Siddharth Naik      First creation
    *      2           25/11/2009      Siddharth Naik      Added Dimension Diagrams & Photometric Data.  
    *      3           30/06/2010      Arif Shaikh         Changed VarChar to NVarChar for dim_richtext in the function UpdateTransformationEOC
    */
    abstract class Transformer
    {
        private static NameValueCollection textTypeMapping;
        private static NameValueCollection structureMapping;
        private static NameValueCollection richTextTypeValues;
        public static NameValueCollection dimensionTableStoredProcs;
        public static NameValueCollection photometricProductStoredProcs;
        public static NameValueCollection assetCaptionTextStoredProcs;

        private static String[] cmcUnUsed;

        /**
         * Method Name : Transform
         * Method Description : Iterates over each data row and transforms the text within it.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation         
         */
        public static void Transform(String tableName, String vis_type_cd, String CTN, String com_fam_cd, String bu_cd, String brand_cd, String dim_richtext, String dim_table_seq_nr, String logFilePath)
        {
            StringBuilder unMappedVisTypeCd = new StringBuilder();

            try
            {
                ReadConfigurationFile();                
                
                DataSet source = new DataSet();
                source.Tables.Add();
                DataTable srcTable = source.Tables[0] ;
                
                //Added By Naresh Bohra
               // DimensionDiagramEOC.Transform(srcTable, vis_type_cd, CTN, com_fam_cd, bu_cd, brand_cd, dim_richtext, dim_table_seq_nr, richTextTypeValues.Get("DimensionDiagramTable"));
                //Console.WriteLine("\n STEP 3 / 3 : Updating Database for Dimension drawing...");
                //UpdateTransformationEOC(source);

                PhotometricProductCTN.Transform(srcTable, vis_type_cd, CTN, com_fam_cd, bu_cd, brand_cd, dim_richtext, dim_table_seq_nr, richTextTypeValues.Get("PhotometricProduct"));
                Console.WriteLine("\n STEP 3 / 3 : Updating Database for Photometric Product...");
                UpdateTransformationPhotom(source);

                //AssetCaptionTextProcessing_ctn.Transform(srcTable, vis_type_cd, CTN, com_fam_cd, bu_cd, brand_cd, dim_richtext, dim_table_seq_nr, richTextTypeValues.Get("AssetCaption"));
                //Console.WriteLine("\n STEP 3 / 3 : Updating Database for AssetCaption...");
                //UpdateTransformationAssetcaption(source);

                // LOG THE ERRORS
                String fileNamePath = logFilePath + "\\CMCTextTypeMappingLog.txt";
                if (File.Exists(fileNamePath))
                {
                    File.Delete(fileNamePath);
                }
                StreamWriter sw = File.CreateText(fileNamePath);
                sw.WriteLine(DateTime.Now.ToString());
                sw.WriteLine(" * * * UN MAPPED VIS_TYPE_CD * * *");
                sw.WriteLine(unMappedVisTypeCd.ToString());                
                sw.Flush();
                sw.Close();
            }
            catch (Exception excep)
            {
                Console.WriteLine(" ERROR OCCURED. SEE LOG. ");
                File.WriteAllText(logFilePath + "\\CMCTextTypeMappingLog-ERROR.txt", excep.Message + " :: " + excep.StackTrace);
                throw;
            }
        }
                
        /**
         * Method Name : GetConnectionString
         * Method Description : Gets the connection string from the registry.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        public static String GetConnectionString()
        {
            try
            {
                RegistryKey objReg = Registry.LocalMachine.CreateSubKey("SOFTWARE\\InfoSupport\\IsDNADBModule\\PRISMA");
                return Convert.ToString(objReg.GetValue("ConnectionString", ""), Program.CultureInfo );
            }
            catch
            {
                throw;
            }
        }

        /**
         * Method Name : UpdateTransformation
         * Method Description : Updates the transformed text back to the database.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         *      2           30/06/2010      Arif Shaikh         Changed VarChar to NVarChar for dim_richtext
         */


        private static void UpdateTransformationEOC(DataSet result)
        {
            
            DataSet temp = new DataSet();
            temp.Tables.Add();
            temp.Tables[0].Columns.Add("publ_target_group_cd");
            temp.Tables[0].Columns.Add("dic_id");
            temp.Tables[0].Columns.Add("eop_full_eoc");
            temp.Tables[0].Columns.Add("tpd_nc10");
            temp.Tables[0].Columns.Add("lpd_nc12");
            temp.Tables[0].Columns.Add("CTN");
            temp.Tables[0].Columns.Add("lan_id");
            temp.Tables[0].Columns.Add("com_fam_cd");
            temp.Tables[0].Columns.Add("brand_cd");
            temp.Tables[0].Columns.Add("cmc_com_fam_cd");
            temp.Tables[0].Columns.Add("vis_elem_nr");
            temp.Tables[0].Columns.Add("vis_elem_descr");
            temp.Tables[0].Columns.Add("dim_table_seq_nr");
            temp.Tables[0].Columns.Add("vis_type_cd");
            temp.Tables[0].Columns.Add("fam_cd");
            temp.Tables[0].Columns.Add("bu_cd");
            temp.Tables[0].Columns.Add("vem_brand_cd");
            temp.Tables[0].Columns.Add("vis_elem_file_seq_nr");
            temp.Tables[0].Columns.Add("use_lang_brand");
            temp.Tables[0].Columns.Add("dim_richtext");
            temp.Tables[0].Columns.Add("vis_class_cd");
            temp.Tables[0].Columns.Add("dim_table");
           
            for(int index = 0; index < result.Tables[0].Rows.Count; index++)
            {
                DataRow dr = temp.Tables[0].NewRow();
                
                dr["publ_target_group_cd"] = "ecatlig";
                dr["dic_id"] = "ecatlig";
                dr["eop_full_eoc"] = "ecatlig";
                dr["tpd_nc10"] = result.Tables[0].Rows[index]["tpd_nc10"].ToString().Trim();
                dr["lpd_nc12"] = "ecatlig";
                dr["CTN"] = "ecatlig";
                dr["lan_id"] = "ecatlig";
                dr["com_fam_cd"] = "ecatlig";
                dr["brand_cd"] = "ecatlig";
                dr["cmc_com_fam_cd"] = "ecatlig";
                dr["vis_elem_nr"] = result.Tables[0].Rows[index]["vis_elem_nr"].ToString().Trim();
                dr["vis_elem_descr"] = "ecatlig";
                dr["dim_table_seq_nr"] = "ecatlig";
                dr["vis_type_cd"] = result.Tables[0].Rows[index]["vis_type_cd"].ToString().Trim();
                dr["fam_cd"] = "ecatlig";
                dr["bu_cd"] = "ecatlig";
                dr["vem_brand_cd"] = "ecatlig";
                dr["vis_elem_file_seq_nr"] = "ecatlig";
                dr["use_lang_brand"] = "ecatlig";
                dr["dim_richtext"] = result.Tables[0].Rows[index]["dim_richtext"].ToString().Trim();
                dr["vis_class_cd"] = result.Tables[0].Rows[index]["vis_class_cd"].ToString().Trim();
                dr["dim_table"] = result.Tables[0].Rows[index]["dim_table"].ToString().Trim();
                temp.Tables[0].Rows.Add(dr);
             }

              SqlConnection con = new SqlConnection(GetConnectionString());
              SqlCommand updateCommand = new SqlCommand
                ("UPDATE rt_dim_table SET dim_richtext=@dim_richtext WHERE tpd_nc10=@tpd_nc10 and vis_class_cd=@vis_class_cd and dim_table=@dim_table and vis_type_cd=@vis_type_cd and vis_elem_nr=@vis_elem_nr", con);
               // ("UPDATE " + tableName +
               //        " SET " + textColName + "=@dim_richtext" + " WHERE " + textID + "=@CTN", con);
              //Changed VarChar to NVarChar by Arif
                updateCommand.Parameters.Add("@dim_richtext", SqlDbType.NVarChar, 1073741823, "dim_richtext");
                updateCommand.Parameters.Add("@tpd_nc10", SqlDbType.VarChar, 50, "tpd_nc10");
                updateCommand.Parameters.Add("@vis_class_cd", SqlDbType.VarChar, 1, "vis_class_cd");
                updateCommand.Parameters.Add("@dim_table", SqlDbType.VarChar, 1, "dim_table");
                updateCommand.Parameters.Add("@vis_type_cd", SqlDbType.VarChar, 10, "vis_type_cd");
                updateCommand.Parameters.Add("@vis_elem_nr", SqlDbType.VarChar, 10, "vis_elem_nr");

              SqlDataAdapter sda = new SqlDataAdapter();
              //sda.UpdateCommand = updateCommand;
              sda.InsertCommand = updateCommand;
              //sda.UpdateCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;
               sda.InsertCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;
              // sda.Update(result);
              sda.Update(temp.Tables[0]);
              updateCommand.Dispose();
        }

        private static void UpdateTransformationPhotom(DataSet result)
        {
            SqlConnection con = new SqlConnection(GetConnectionString());

            string tableName = "rt_photom_prod_ctn";
            string CTN = "CTN";
            string lan_id = "lan_id";
            string photom_richtext = "photom_richtext";

            SqlCommand insertCommand = new SqlCommand
            ("INSERT INTO " + tableName + " (" + CTN + ", " + lan_id + ", " + photom_richtext + ") VALUES ( @CTN, @lan_id, @photom_richtext)", con);

            insertCommand.Parameters.Add("@CTN", SqlDbType.NChar, 23, CTN);
            insertCommand.Parameters.Add("@lan_id", SqlDbType.NVarChar, 4, lan_id);
            //Changed VarChar to NVarChar by Arif
            insertCommand.Parameters.Add("@photom_richtext", SqlDbType.NVarChar, 1073741823, photom_richtext);

            SqlDataAdapter sda = new SqlDataAdapter();

            sda.InsertCommand = insertCommand;
            sda.InsertCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;
            sda.Update(result.Tables[0]);

            insertCommand.Dispose();
        }

        private static void UpdateTransformationAssetcaption(DataSet result)
        {
            SqlConnection con = new SqlConnection(GetConnectionString());

            string tableName = "rt_naming_string_ctn";
            string CTN = "CTN";
            string locale = "locale";
            string caption_text = "caption_text";

            SqlCommand insertCommand = new SqlCommand
            ("INSERT INTO " + tableName + " (" + CTN + ", " + locale + ", " + caption_text + ") VALUES ( @CTN, @locale, @caption_text)", con);

            insertCommand.Parameters.Add("@CTN", SqlDbType.NChar, 23, CTN);
            insertCommand.Parameters.Add("@locale", SqlDbType.NVarChar, 7, locale);
            insertCommand.Parameters.Add("@caption_text", SqlDbType.NVarChar, 1073741823, caption_text);

            SqlDataAdapter sda = new SqlDataAdapter();

            sda.InsertCommand = insertCommand;
            sda.InsertCommand.CommandTimeout = Program.SqlCommandTimeoutPeriod;
            sda.Update(result.Tables[0]);

            insertCommand.Dispose();
        }

        /**
         * Method Name : GetTextFromDB
         * Method Description : Gets the text data from the database.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static DataSet GetTextFromDB(String tableName, String textID, String textTypeColName, String richTextTypeColName, String textColName, String lanIDColName, String comFamCdColName, String buCdColName, String brandCdColName)
        {
            SqlConnection con = new SqlConnection(GetConnectionString());

            SqlCommand selectCmd = new SqlCommand("SELECT " + textID + ", " + textTypeColName + ", " + richTextTypeColName + ", " + textColName + ", " + lanIDColName + ", " + comFamCdColName + ", " + buCdColName + ", " + brandCdColName + " FROM " + tableName, con);
            selectCmd.CommandTimeout = Program.SqlCommandTimeoutPeriod;

            SqlDataAdapter sda = new SqlDataAdapter(selectCmd);
            
            DataSet result = new DataSet();
            result.Locale = Program.CultureInfo;

            sda.Fill(result);

            return result;
        }

        /**
         * Method Name : ApplyTransformation
         * Method Description : Applies the transformation to the passed html content as per the structure.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static String ApplyTransformation(int textDefID, String textTypeBlockName, String htmlContent)
        {

            String result = String.Empty;
                        
            // determine the structure for this text block
            String structureName = GetTextBlockStructureName(textTypeBlockName);

            switch (structureName)
            {
                case ("HeaderBody"):
                    {
                        result = HeaderBodyProcessing.Transform(htmlContent);
                    } break;

                case ("Bullets"):
                    {
                        result = BulletProcessing.Transform(textDefID, htmlContent, richTextTypeValues.Get(textTypeBlockName));
                    } break;

                case ("LabelBulletSubBullet"):
                    {
                        result = LabelBulletSubBulletProcessing.Transform(textDefID, htmlContent, richTextTypeValues.Get(textTypeBlockName));
                    } break;

                case ("KeyBenefitAreaStructure"):
                    {
                        result = KeyBenefitAreaProcessing.Transform(htmlContent);
                    } break;

                default:
                    {
                        throw new System.FormatException();
                    }
            }
            return result;
        }

        /**
         * Method Name : IsTextTypeCmcUNUnsed
         * Method Description : Determine if the vis_type_cd matchs to a structure.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static bool IsTextTypeCmcUNUnsed(String textType)
        {
            for (int index = 0; index < cmcUnUsed.Length; index++)
            {
                if (cmcUnUsed[index].Equals(textType))
                {
                    return true;
                }

                if (cmcUnUsed[index][0].Equals('.'))
                {
                    if (cmcUnUsed[index].Substring(1).Equals(textType.Substring(1)))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * Method Name : GetTextBlockStructureName
         * Method Description : Determine the structure for a given CMC text type.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static String GetTextBlockStructureName(String textTypeBlockName)
        {
            int keyIndex;
            int valueIndex;

            for (keyIndex = 0; keyIndex < Transformer.structureMapping.Count; keyIndex++)
            {
                String keyName = Transformer.structureMapping.Keys[keyIndex];
                String[] keyValues = Transformer.structureMapping.GetValues(keyIndex)[0].Split(',');

                for (valueIndex = 0; valueIndex < keyValues.Length; valueIndex++)
                {
                    if (keyValues[valueIndex].Equals(textTypeBlockName))
                    {
                        break;
                    }
                }

                if (valueIndex < keyValues.Length)
                {
                    return keyName;
                }
            }

            return String.Empty;
        }

        /**
         * Method Name : GetTextBlockName
         * Method Description : Determine CMC text type name.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static String GetTextBlockName(String textType)
        {
            int keyIndex;
            int valueIndex;

            for (keyIndex = 0; keyIndex < Transformer.textTypeMapping.Count; keyIndex++)
            {
                String keyName = Transformer.textTypeMapping.Keys[keyIndex];
                String[] keyValues = Transformer.textTypeMapping.GetValues(keyIndex)[0].Split(',');

                for (valueIndex = 0; valueIndex < keyValues.Length; valueIndex++)
                {
                    if (textType.Equals(keyValues[valueIndex]))
                    {
                        break;
                    }

                    if (keyValues[valueIndex][0].Equals('.'))
                    {
                        if (textType.Substring(1).Equals(keyValues[valueIndex].Substring(1)))
                        {
                            break;
                        }
                    }
                }

                if (valueIndex < keyValues.Length)
                {
                    return keyName;
                }
            }

            return String.Empty;
        }

        /**
         * Method Name : ReadConfigurationFile
         * Method Description : Read the configuration file to get the structure, text type mapping to be used.
         * Creation Date : 16/11/2009
         * Creator : Siddharth Naik
         * History :
         *      Version     Date            Author              Remarks
         *      1           16/11/2009      Siddharth Naik      First creation
         */
        private static void ReadConfigurationFile()
        {
            // 1. Get Text Type Mapping            
            Transformer.textTypeMapping = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("TextTypeMapping");

            // 2. Get Structure Mapping
            Transformer.structureMapping = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("StructureMapping");

            // 3. Get Un used CMC types
            NameValueCollection nvc = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("CmcUnUsedTextType");

            // 4. Get richTextTypeValues
            Transformer.richTextTypeValues = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("RichTextTypeValue");

            // 5. Get un used values.
            Transformer.cmcUnUsed = nvc.GetValues(0)[0].Split(',');

            // 6. Get Dimension Drawing stored procs
            Transformer.dimensionTableStoredProcs = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("DimensionDiagramTableStoreProc");

            // 7. Get Photometric Stored procs
            Transformer.photometricProductStoredProcs = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("PhotometricProductStoreProc");
            
            // 8. Get Asset caption text Stored procs
            Transformer.assetCaptionTextStoredProcs = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("AssetCaptionTextStoreProc");            
        }
    }
}
