﻿#region Namespaces

#region System

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Resources;
using System.Reflection;

#endregion System

#region Custom
#endregion Custom

#endregion Namespaces

namespace PRISMA.LOR2.Resources
{
    /// <summary>
    /// 
    /// </summary>
    public class UserMessages
    {
        #region Member Variables
        #endregion Memeber Variables

        #region Constructors
        #endregion Constructors

        #region Properties
        #endregion Properties

        #region Methods

        #region Private Methods
        #endregion Private Methods

        #region Proetcted/Overriden Methods
        #endregion Proetcted/Overriden Methods

        #region Public Methods

        /// <summary>
        /// Gets the resource text.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        public string GetResourceText(string key)
        {
            try
            {
                ResourceManager resourceManager = new ResourceManager("PRISMA.LOR2.Resources.Messages", Assembly.GetExecutingAssembly());
                return resourceManager.GetString(key);
            }

            catch
            {
                throw;
            }
        }

        #endregion Public Methods

        #endregion Methods
    }
}
